from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess,sys,time
root=Path('/home/administrator/projects/hexalith/tenants')
log=Path(sys.argv[1]);args=sys.argv[2:]
common=['.github/workflows/source-reference.yml','src/Hexalith.Tenants.AppHost/Hexalith.Tenants.AppHost.csproj']
if any('Contracts.Tests.csproj' in a for a in args):
 sources=common+['tests/Hexalith.Tenants.Contracts.Tests/Hexalith.Tenants.Contracts.Tests.csproj','tests/Hexalith.Tenants.Contracts.Tests/PackageGovernanceTests.cs','tests/Hexalith.Tenants.Contracts.Tests/SourceReferenceWorkflowGovernanceTests.cs'];assembly=root/'tests/Hexalith.Tenants.Contracts.Tests/bin/Debug/net10.0/Hexalith.Tenants.Contracts.Tests.dll'
elif any('IntegrationTests.csproj' in a for a in args):
 sources=common+['tests/Hexalith.Tenants.IntegrationTests/TenantsApiGeneratedControllerTests.cs'];assembly=root/'tests/Hexalith.Tenants.IntegrationTests/bin/Debug/net10.0/Hexalith.Tenants.IntegrationTests.dll'
else:
 sources=common+['tests/Hexalith.Tenants.AppHost.Tests/MemoriesSecretStoreResourceGraphTests.cs'];assembly=root/'tests/Hexalith.Tenants.AppHost.Tests/bin/Debug/net10.0/Hexalith.Tenants.AppHost.Tests.dll'
def digest(path):
 return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
snapshot={p:{'sha256':digest(root/p),'normalized_lf_sha256':hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest()} for p in sources}
started=datetime.now(timezone.utc).isoformat();start=time.monotonic();binary_before=digest(assembly)
with log.open('wb') as output:
 r=subprocess.run(args,cwd=root,stdout=output,stderr=subprocess.STDOUT)
result={'command':args,'cwd':str(root),'started_utc':started,'duration_seconds':round(time.monotonic()-start,3),'exit_code':r.returncode,'tested_sources':snapshot,'assembly':str(assembly.relative_to(root)),'assembly_sha256_before':binary_before,'assembly_sha256_after':digest(assembly),'log_sha256':digest(log)}
log.with_suffix('.run.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'log':str(log),'exit_code':r.returncode,'duration_seconds':result['duration_seconds']}))
sys.exit(r.returncode)
