from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path.cwd()
def trx(path):
 r=ET.parse(path).getroot()
 ns={'t':r.tag.split('}')[0][1:]}
 counters=r.find('.//t:Counters',ns).attrib
 cases=r.findall('.//t:UnitTestResult',ns)
 return counters,Counter(n.get('testName') for n in cases),cases
fc,fn,_=trx('/tmp/tenants-five-reviewed-focused.trx')
ac,an,results=trx('/tmp/tenants-five-reviewed-full/results.trx')
assert int(fc['total'])==42 and int(fc['passed'])==42,fc
assert int(ac['total'])==7324 and int(ac['passed'])==7324,ac
assert all(n.get('outcome')=='Passed' for n in results)
assert not (fn-an),list((fn-an).elements())
print(json.dumps({'focused':fc,'full':ac,'all_42_dedicated_cases_pass_in_full':True},indent=2))
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
paths=sorted({p for p in changed+untracked if p.startswith(('src/','tests/'))})
paths+=['src/Hexalith.Tenants.UI/bin/Debug/net10.0/Hexalith.Tenants.UI.dll','tests/Hexalith.Tenants.UI.Tests/bin/Debug/net10.0/Hexalith.Tenants.UI.Tests.dll']
manifest={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
Path('/tmp/tenants-five-source-and-assembly-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
x=json.loads(Path('/tmp/tenants-five-baseline-aspire.json').read_text())
Path('/tmp/tenants-five-sanitized-aspire-state.json').write_text(json.dumps([{k:r.get(k) for k in ['name','state','healthStatus']} for r in x['resources']],indent=2)+'\n')
Path('/tmp/tenants-five-trx-verification.json').write_text(json.dumps({'focused':fc,'full':ac,'all_42_dedicated_cases_pass_in_full':True},indent=2)+'\n')
names = [
 'tenants-five-initial-build.log', 'tenants-five-build.log', 'tenants-five-final-build.log',
 'tenants-five-reviewed-build.log', 'tenants-five-review-patch-build.log',
 'tenants-five-focused.log', 'tenants-five-initial-focused.log', 'tenants-five-focused-direct.log',
 'tenants-five-focused.trx', 'tenants-five-initial-review-focused.log', 'tenants-five-initial-review-focused.trx',
 'tenants-five-reviewed-focused.log', 'tenants-five-reviewed-focused.trx', 'tenants-five-focused-command.json',
 'tenants-five-full.log', 'tenants-five-full-final.log', 'tenants-five-reviewed-full.log',
 'tenants-five-sanitized-aspire-state.json', 'tenants-five-source-and-assembly-sha256.json',
 'tenants-five-trx-verification.json', 'tenants-five-commit-message.txt', 'tenants-five-commitlint.log',
 'tenants-five-commit-validation.json', 'tenants-five-fetch.log', 'tenants-five-precommit-git.json',
 'tenants-five-whitespace.log', 'tenants-five-ledger-verification.json', 'tenants-five-story-gitlinks.log',
]
files=[Path('/tmp')/name for name in names]
files+=[Path('/tmp/tenants-five-full/results.trx'),Path('/tmp/tenants-five-full-final/results.trx'),Path('/tmp/tenants-five-reviewed-full/results.trx')]
artifact=root/'_bmad-output/implementation-artifacts/dw-248-255-269-276-313-raw-logs.zip'
with zipfile.ZipFile(artifact,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  assert p.is_file(),p
  arc=str(p.relative_to('/tmp')) if p.name=='results.trx' else 'logs/'+p.name
  z.write(p,arc)
 z.write('/tmp/tenants-five-bundle.py','verify-and-bundle.py')
print(f'Archived {len(set(files))} evidence files, {artifact.stat().st_size} bytes')
