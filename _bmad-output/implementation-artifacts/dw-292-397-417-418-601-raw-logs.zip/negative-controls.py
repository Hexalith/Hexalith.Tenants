import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

root = Path.cwd()
sys.path.insert(0, str(root / 'tests/scripts'))

def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, root / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def expect_failure(case, label):
    stream = io.StringIO()
    outcome = unittest.TextTestRunner(stream=stream).run(unittest.TestSuite([case]))
    if outcome.wasSuccessful() or outcome.errors:
        raise RuntimeError(f'{label}: expected assertion failure, got {stream.getvalue()}')
    return {'control': label, 'tests_run': outcome.testsRun, 'assertion_failures': len(outcome.failures),
            'errors': len(outcome.errors), 'rejected': True}

results = []
with tempfile.TemporaryDirectory(prefix='tooling negative ') as directory:
    temp = Path(directory)
    pushall = load('pushall_control', 'tests/scripts/test_pushall_default_branch.py')
    old_manifest = temp / 'pushall.md'
    old_manifest.write_bytes(subprocess.check_output(['git','show','349379e305d4eda41d36821376073308ef8a8ea3:.agents/skills/pushall/SKILL.md']))
    pushall.SKILLS = [old_manifest]
    for method in ('test_failed_initial_fetch_stops_before_any_later_operation',
                   'test_successful_switch_without_correct_head_is_refused'):
        results.append(expect_failure(pushall.PushallDefaultBranchTests(method), 'baseline pushall: ' + method))
    catalog = load('catalog_control', 'tests/scripts/test_elicitation_numbers.py')
    script = temp / 'pick_methods.py'
    script.write_bytes(subprocess.check_output(['git','show','349379e305d4eda41d36821376073308ef8a8ea3:.agents/skills/bmad-advanced-elicitation/scripts/pick_methods.py']))
    catalog.SCRIPTS = [script]
    results.append(expect_failure(catalog.ElicitationNumberTests('test_duplicate_numbers_are_rejected'), 'baseline catalog permits collisions'))
    tea = load('tea_control', 'tests/scripts/test_tea_enforcement.py')
    hook = temp / 'tea-enforce.cjs'
    hook.write_text(tea.HOOKS[0].read_text().replace('process.exit(code);', 'process.exit(0);'))
    tea.HOOKS = [hook]
    results.append(expect_failure(tea.TeaEnforcementTests('test_pre_blocks_focused_write_edit_and_multiedit'), 'always-success hook entry point'))
print(json.dumps(results, indent=2))
