from pathlib import Path
import sys,json,hashlib,datetime
w=Path(__file__).parent;r=Path(json.loads((w/'state.json').read_text())['root']);phase=sys.argv[1];projects=[]
for folder in ['src','samples']:
 for p in sorted((r/folder).glob('*/*.csproj')):
  if p.parent.name.endswith('.Tests'):continue
  asset=p.parent/'obj/project.assets.json';raw=asset.read_bytes();data=json.loads(raw);packages=sorted(k for k in data['libraries'] if k.lower().startswith('hexalith.eventstore.'))
  assert packages and all(k.endswith('/3.128.4') and data['libraries'][k]['type']=='package' for k in packages),(p,packages)
  dest=w/'assets'/phase/asset.relative_to(r);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
  projects.append({'project':str(p.relative_to(r)),'archiveEntry':str(dest.relative_to(w)),'sha256':hashlib.sha256(raw).hexdigest(),'eventStorePackages':packages})
d={'phase':phase,'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rootRevision':json.loads((w/'state.json').read_text())['rootRevision'],'catalogSha256':hashlib.sha256((r/'references/Hexalith.Builds/Props/Directory.Packages.props').read_bytes()).hexdigest(),'projects':projects}
(w/('assets-'+phase+'.json')).write_text(json.dumps(d,indent=2)+'\n');print('Captured',len(projects),'owned production assets:',phase)
