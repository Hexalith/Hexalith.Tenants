from pathlib import Path
import json,zipfile,hashlib,datetime,subprocess,re
w=Path(__file__).parent;state=json.loads((w/'state.json').read_text());r=Path(state['root']);out=r/'_bmad-output/implementation-artifacts';stem='dependency-refresh-eventstore-3.128.4';now=datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
assert (w/'catalog.before.props').read_bytes()==(r/'references/Hexalith.Builds/Props/Directory.Packages.props').read_bytes()
assert (w/'audit.before.json').read_bytes()==(r/'references/Hexalith.Builds/Tools/package-version-audit.json').read_bytes()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==state['rootRevision']
assert subprocess.check_output(['git','diff','--raw','HEAD','--','references/'],cwd=r)==b''
audit=json.loads((w/'audit.live.json').read_text(encoding='utf-8-sig'));eventstore=[{k:p[k] for k in ['id','auditedVersion','selectedVersion','latestStable','latestPrerelease','listingState','disposition','sourceResults']} for p in audit['packages'] if p['family']=='hexalith-eventstore'];assert len(eventstore)==13 and all(p['selectedVersion']==p['latestStable']=='3.128.4' and p['listingState']=='listed' for p in eventstore)
commands=[]
for f in sorted((w/'commands').glob('*.json')):
 d=json.loads(f.read_text());log=w/d['archiveEntry'];assert sha(log.read_bytes())==d['sha256'];text=log.read_text(errors='replace');summary=re.search(r'Test run summary[\s\S]*',text)
 if summary:
  d['testSummary']=summary.group().strip();d['testCounts']={k:int(re.search(r'\b'+k+r': (\d+)',d['testSummary']).group(1)) for k in ['total','failed','succeeded','skipped']}
 commands.append(d)
commands.sort(key=lambda c:c['startedAtUtc'])
assets=[json.loads(p.read_text()) for p in sorted(w.glob('assets-*.json'))]
for phase in assets:
 for p in phase['projects']:
  data=(w/p['archiveEntry']).read_bytes();assert sha(data)==p['sha256'];libs=json.loads(data)['libraries'];assert all(k.endswith('/3.128.4') and libs[k]['type']=='package' for k in p['eventStorePackages'])
historical=[]
for p in sorted(out.glob('dependency-refresh-eventstore-3.*')):
 if p.name.startswith(stem) or not p.is_file():continue
 rel=p.relative_to(r).as_posix();blob=subprocess.check_output(['git','show','HEAD:'+rel],cwd=r);assert blob==p.read_bytes(),p
 historical.append({'path':rel,'sha256':sha(blob),'unchangedFromRootRevision':state['rootRevision']})
archive=out/(stem+'-raw-logs-2026-10-29.zip');entries=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(w.rglob('*')):
  if not f.is_file() or f.name=='archive-manifest.json':continue
  raw=f.read_bytes();name=f.relative_to(w).as_posix();z.writestr(name,raw);entries.append({'archiveEntry':name,'sha256':sha(raw),'bytes':len(raw)})
 manifest=json.dumps({'capturedAtUtc':now,'entries':entries},indent=2)+'\n';z.writestr('archive-manifest.json',manifest)
totals={k:sum(c.get('testCounts',{}).get(k,0) for c in commands) for k in ['total','failed','succeeded','skipped']};assert totals=={'total':10887,'failed':0,'succeeded':10887,'skipped':0}
recipes=[]
for c in commands:
 if 'testCounts' not in c:continue
 args=c['command'].copy();args[args.index('--minimum-expected-tests')+1]=str(c['testCounts']['total']);recipes.append({'suite':c['name'],'command':args,'meaning':'Recommended future repeat minimum based on observed complete-suite count; original executed command is preserved above.'})
evidence={'testTotals':totals,'recommendedRepeatCommands':recipes,'gateSummary':{'packageCurrency':'passed','releaseBuildCompatibility':'passed in both recorded modes','defaultLaneTests':'10887 passed, zero failures/skips','currentContinuationGitlinks':'passed: no diff from independently recorded starting root revision','historicalEndpointAudit':'passed at ef4b7f2f99b2a60910b94481a198f591c51bfe5c','legacyBaselineToCurrentStoryAudit':'failed: eight intervening undeclared pointers; historical records need reconciliation','overall':'package verification passed; historical story remains in-progress'},'review':json.loads((w/'review-triage.json').read_text()),**json.loads((w/'extra-evidence.json').read_text()),'schema':'hexalith.tenants.eventstore-package-verification.v1','targetVersion':'3.128.4','result':'already-current; no dependency change necessary','verifiedAtUtc':now,'baseline':state,'constraints':{'dependencyPinChanged':False,'checkedInAuditChanged':False,'gitlinksMoved':False,'staged':False,'committed':False,'pushed':False},'liveDiscovery':{'auditArchiveEntry':'audit.live.json','priorAuditArchiveEntry':'audit.before.json','generatedFromRevision':audit['generatedFromRevision'],'catalogSha256':audit['catalogSha256'],'catalogRawSha256':audit['catalogRawSha256'],'snapshot':audit['snapshot'],'sources':audit['sources'],'eventStorePackages':eventstore},'invariants':json.loads((w/'invariants.json').read_text()),'commands':commands,'resolvedAssets':assets,'historicalEvidencePreserved':historical,'limitations':['Historical story gitlink declaration check exits 1 for eight intervening undeclared gitlinks since the retained October 10 baseline. The current continuation has zero gitlink diff from its independently recorded starting revision; the old baseline was not reset.','No new package version, publication, explicit Tenants pack, isolated packaged Tenants consumer probe, full Aspire runtime suite or browser qualification is claimed. The default build automatically created six Commons dependency package artifacts, listed separately. Default UI uses its documented FrontComposer/Memories source exception; standalone package-mode results are recorded separately.'],'rawArchive':{'path':archive.relative_to(r).as_posix(),'sha256':sha(archive.read_bytes()),'manifestArchiveEntry':'archive-manifest.json','manifestSha256':sha(manifest.encode()),'entryCountExcludingManifest':len(entries)}}
path=out/(stem+'-evidence-2026-10-29.json');path.write_text(json.dumps(evidence,indent=2)+'\n');print(path);print('archive',archive.stat().st_size,'bytes;',len(entries),'hashed entries;',len(commands),'commands');print([(c['name'],c['exitCode']) for c in commands])
