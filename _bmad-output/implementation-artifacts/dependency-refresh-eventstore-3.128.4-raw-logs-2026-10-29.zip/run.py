from pathlib import Path
import sys,json,subprocess,datetime,hashlib,time
work=Path(__file__).parent; state=json.loads((work/'state.json').read_text()); name=sys.argv[1]; cwd=sys.argv[2]; args=sys.argv[3:]; log=work/'commands'/(name+'.log'); start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
with log.open('wb') as output: code=subprocess.run(args,cwd=cwd,stdout=output,stderr=subprocess.STDOUT).returncode
raw=log.read_bytes(); result={'name':name,'command':args,'cwd':cwd,'startedAtUtc':start,'finishedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':round(time.monotonic()-t,3),'exitCode':code,'archiveEntry':'commands/'+log.name,'sha256':hashlib.sha256(raw).hexdigest()};(work/'commands'/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result)); print(raw.decode(errors='replace')[-6500:]);sys.exit(code)
