#pragma warning disable CA2007

extern alias TenantsApi;

using System.IdentityModel.Tokens.Jwt;
using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

using Hexalith.Commons.UniqueIds;
using Hexalith.EventStore.Client.Gateway;
using Hexalith.EventStore.Client.Projections;
using Hexalith.EventStore.Client.Queries;
using Hexalith.EventStore.Authorization;
using Hexalith.EventStore.Contracts.Commands;
using Hexalith.EventStore.Contracts.Projections;
using Hexalith.EventStore.Contracts.Events;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.EventStore.Contracts.Streams;
using Hexalith.EventStore.Controllers;
using Hexalith.EventStore.DomainService;
using Hexalith.EventStore.Queries;
using Hexalith.EventStore.Server.Pipeline.Queries;
using Hexalith.EventStore.Server.Queries;
using Hexalith.Tenants.Contracts;
using Hexalith.Tenants.Contracts.Commands;
using Hexalith.Tenants.Contracts.Enums;
using Hexalith.Tenants.Contracts.Events;
using Hexalith.Tenants.Contracts.Identity;
using Hexalith.Tenants.Contracts.Queries;
using Hexalith.FrontComposer.Contracts.Rendering;
using Hexalith.Memories.Client.Rest;
using Hexalith.Tenants.Configuration;
using Hexalith.Tenants.Queries.Handlers;
using Hexalith.Tenants.Server.Projections;
using Hexalith.Tenants.Telemetry;
using Hexalith.Tenants.UI.State.GlobalAdministrators;
using Hexalith.Tenants.UI.State.TenantAudit;
using Hexalith.Tenants.UI.State.TenantCommands;
using Hexalith.Tenants.Projections;
using Hexalith.Tenants.UI.Services.Gateways;

using MediatR;

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;

using NSubstitute;

using Shouldly;

namespace Hexalith.Tenants.IntegrationTests;

public sealed class TenantsApiGeneratedControllerTests
{
    private const string JwtAudience = "hexalith-eventstore";
    private const string JwtIssuer = "hexalith-dev";
    private const string JwtSigningKey = "this-is-a-generated-api-test-signing-key-minimum-32-chars";

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() },
    };

    [Fact]
    public async Task ListTenants_requires_authorization_before_gateway_submission()
    {
        CapturingEventStoreGatewayClient gateway = new();
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = factory.CreateClient();

        HttpResponseMessage response = await client.GetAsync("/api/tenants");

        response.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
        gateway.SubmittedQueries.ShouldBeEmpty();
    }

    [Fact]
    public async Task ListTenants_generated_route_submits_index_query_and_forwards_freshness_headers()
    {
        DateTimeOffset servedAt = DateTimeOffset.Parse("2026-07-03T05:00:00Z", CultureInfo.InvariantCulture);
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(
            new PaginatedResult<TenantSummary>(
                [new TenantSummary("tenant.alpha", "Alpha", TenantStatus.Active)],
                "next-cursor",
                true),
            eTag: "index-etag-2",
            metadata: new QueryResponseMetadata(
                ETag: "index-etag-2",
                IsStale: true,
                ProjectionVersion: "index-v2",
                ServedAt: servedAt)
            {
                Provenance = QueryResponseProvenance.ProjectionBacked,
            });
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/tenants?cursor=opaque&pageSize=25");

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        response.Headers.ETag.ShouldNotBeNull().Tag.ShouldBe("\"index-etag-2\"");
        response.Headers.GetValues("X-Hexalith-Projection-Version").ShouldHaveSingleItem().ShouldBe("index-v2");
        response.Headers.GetValues("X-Hexalith-Served-At").ShouldHaveSingleItem().ShouldBe(servedAt.ToString("O", CultureInfo.InvariantCulture));
        response.Headers.GetValues("X-Hexalith-Is-Stale").ShouldHaveSingleItem().ShouldBe("true");

        JsonElement body = await response.Content.ReadFromJsonAsync<JsonElement>();
        body.GetProperty("items").GetArrayLength().ShouldBe(1);
        body.GetProperty("items")[0].GetProperty("tenantId").GetString().ShouldBe("tenant.alpha");

        SubmittedQuery query = gateway.SubmittedQueries.ShouldHaveSingleItem();
        query.Request.Tenant.ShouldBe("system");
        query.Request.Domain.ShouldBe(ListTenantsQuery.Domain);
        query.Request.AggregateId.ShouldBe("index");
        query.Request.EntityId.ShouldBeNull();
        query.Request.QueryType.ShouldBe(ListTenantsQuery.QueryType);
        query.Request.ProjectionType.ShouldBe(ListTenantsQuery.ProjectionType);
        query.IfNoneMatch.ShouldBeNull();
        query.CancellationToken.CanBeCanceled.ShouldBeTrue();
        JsonElement payload = query.Request.Payload.ShouldNotBeNull();
        payload.GetProperty("cursor").GetString().ShouldBe("opaque");
        payload.GetProperty("pageSize").GetInt32().ShouldBe(25);
    }

    [Fact]
    public async Task Generated_query_route_suppresses_projection_headers_for_handler_computed_result()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(
            new TenantDetail(
                "tenant.alpha",
                "Alpha",
                "Tenant Alpha",
                TenantStatus.Active,
                [],
                new Dictionary<string, string>(StringComparer.Ordinal),
                DateTimeOffset.Parse("2026-07-03T05:20:00Z", CultureInfo.InvariantCulture)),
            eTag: "opaque-store-etag",
            metadata: new QueryResponseMetadata(
                ETag: "opaque-store-etag",
                IsNotModified: false,
                IsStale: false,
                ProjectionVersion: "tenant-sequence:42")
            {
                Provenance = QueryResponseProvenance.HandlerComputed,
                Lifecycle = ProjectionLifecycleState.Current,
            });
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/tenants/tenant.alpha");
        request.Headers.IfNoneMatch.ParseAdd("\"conflicting-validator\"");

        using HttpResponseMessage response = await client.SendAsync(
            request,
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        response.Headers.GetValues("X-Hexalith-Query-Provenance").ShouldHaveSingleItem().ShouldBe("HandlerComputed");
        response.Headers.ETag.ShouldBeNull();
        response.Headers.Contains("X-Hexalith-Projection-Version").ShouldBeFalse();
        response.Headers.Contains("X-Hexalith-Is-Stale").ShouldBeFalse();
        response.Headers.Contains(ProjectionLifecyclePolicy.HeaderName).ShouldBeFalse();

        TenantDetail? detail = await response.Content.ReadFromJsonAsync<TenantDetail>(
            JsonOptions,
            TestContext.Current.CancellationToken);
        detail.ShouldNotBeNull().TenantId.ShouldBe("tenant.alpha");
        gateway.SubmittedQueries.ShouldHaveSingleItem().IfNoneMatch.ShouldBe("\"conflicting-validator\"");
    }

    [Fact]
    public async Task UserTenants_generated_absolute_route_submits_index_query_for_target_user_entity()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<UserTenantMembership>([], null, false));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/users/user.alpha/tenants?pageSize=12");

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        SubmittedQuery query = gateway.SubmittedQueries.ShouldHaveSingleItem();
        query.Request.Tenant.ShouldBe("system");
        query.Request.Domain.ShouldBe(GetUserTenantsQuery.Domain);
        query.Request.AggregateId.ShouldBe("index");
        query.Request.EntityId.ShouldBe("user.alpha");
        query.Request.QueryType.ShouldBe(GetUserTenantsQuery.QueryType);
        query.Request.ProjectionType.ShouldBe(GetUserTenantsQuery.ProjectionType);
        query.Request.Payload.ShouldNotBeNull().GetProperty("pageSize").GetInt32().ShouldBe(12);
    }

    [Fact]
    public async Task TenantDetail_generated_route_submits_tenant_scoped_query_for_route_tenant()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new TenantDetail(
            "tenant.alpha",
            "Alpha",
            "Tenant Alpha",
            TenantStatus.Active,
            [],
            new Dictionary<string, string>(StringComparer.Ordinal),
            DateTimeOffset.Parse("2026-07-03T05:20:00Z", CultureInfo.InvariantCulture)));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/tenants/tenant.alpha");

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        SubmittedQuery query = gateway.SubmittedQueries.ShouldHaveSingleItem();
        query.Request.Tenant.ShouldBe("system");
        query.Request.Domain.ShouldBe(GetTenantQuery.Domain);
        query.Request.AggregateId.ShouldBe("tenant.alpha");
        query.Request.EntityId.ShouldBe("tenant.alpha");
        query.Request.QueryType.ShouldBe(GetTenantQuery.QueryType);
        query.Request.ProjectionType.ShouldBe(GetTenantQuery.ProjectionType);
        query.Request.Payload.ShouldBeNull();
    }

    [Fact]
    public async Task TenantUsers_generated_route_submits_tenant_scoped_query_with_paging_payload()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<TenantMember>(
            [new TenantMember("user.alpha", TenantRole.TenantReader)],
            "users-next",
            true));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/tenants/tenant.alpha/users?cursor=user-cursor&pageSize=20");

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        SubmittedQuery query = gateway.SubmittedQueries.ShouldHaveSingleItem();
        query.Request.Tenant.ShouldBe("system");
        query.Request.Domain.ShouldBe(GetTenantUsersQuery.Domain);
        query.Request.AggregateId.ShouldBe("tenant.alpha");
        query.Request.EntityId.ShouldBe("tenant.alpha");
        query.Request.QueryType.ShouldBe(GetTenantUsersQuery.QueryType);
        query.Request.ProjectionType.ShouldBe(GetTenantUsersQuery.ProjectionType);
        JsonElement payload = query.Request.Payload.ShouldNotBeNull();
        payload.GetProperty("cursor").GetString().ShouldBe("user-cursor");
        payload.GetProperty("pageSize").GetInt32().ShouldBe(20);
    }

    [Fact]
    public async Task GlobalAdministrators_generated_absolute_route_submits_fixed_platform_scope_query()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<GlobalAdministratorSummary>([], null, false));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/global-administrators?pageSize=10");

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        SubmittedQuery query = gateway.SubmittedQueries.ShouldHaveSingleItem();
        query.Request.Tenant.ShouldBe("system");
        query.Request.Domain.ShouldBe(GetGlobalAdministratorsQuery.Domain);
        query.Request.AggregateId.ShouldBe("global-administrators");
        query.Request.EntityId.ShouldBe("global-administrators");
        query.Request.QueryType.ShouldBe(GetGlobalAdministratorsQuery.QueryType);
        query.Request.ProjectionType.ShouldBe(GetGlobalAdministratorsQuery.ProjectionType);
    }

    [Theory]
    [InlineData(1, "projection-v1", "etag-v1", QueryResponseProvenance.ProjectionBacked, ProjectionLifecycleState.Current, GlobalAdministratorsSurfaceKind.Ready, true)]
    [InlineData(30, "projection-v1", "etag-v1", QueryResponseProvenance.ProjectionBacked, ProjectionLifecycleState.Stale, GlobalAdministratorsSurfaceKind.Stale, false)]
    [InlineData(1, null, "etag-v1", QueryResponseProvenance.ProjectionBacked, ProjectionLifecycleState.Current, GlobalAdministratorsSurfaceKind.Ready, false)]
    [InlineData(1, "projection-v1", null, QueryResponseProvenance.ProjectionBacked, ProjectionLifecycleState.Current, GlobalAdministratorsSurfaceKind.Ready, true)]
    public async Task GlobalAdministratorsRealHandlerMetadataSurvivesRouterRestClientAndUiGateway(
        int projectedAgeMinutes,
        string? projectionVersion,
        string? eTag,
        QueryResponseProvenance expectedProvenance,
        ProjectionLifecycleState expectedLifecycle,
        GlobalAdministratorsSurfaceKind expectedKind,
        bool expectedCompleteEvidence)
    {
        DateTimeOffset now = DateTimeOffset.Parse("2026-09-21T12:00:00Z", CultureInfo.InvariantCulture);
        var model = new GlobalAdministratorReadModel
        {
            Administrators = ["admin.current", "target.user"],
            ProjectedAt = now.AddMinutes(-projectedAgeMinutes),
            ProjectionVersion = projectionVersion,
        };
        using var gateway = new HandlerRoutedEventStoreGatewayClient(model, eTag, now);
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient serviceClient = CreateAuthenticatedClient(factory);

        using HttpResponseMessage response = await serviceClient.GetAsync(
            "/api/global-administrators?pageSize=20",
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        response.Headers.GetValues("X-Hexalith-Query-Provenance")
            .ShouldHaveSingleItem()
            .ShouldBe(expectedProvenance.ToString());
        response.Headers.TryGetValues("X-Hexalith-Projection-Lifecycle", out IEnumerable<string>? lifecycleHeaders)
            .ShouldBe(expectedLifecycle is not ProjectionLifecycleState.Unknown);
        if (expectedLifecycle is not ProjectionLifecycleState.Unknown)
        {
            lifecycleHeaders.ShouldNotBeNull().ShouldHaveSingleItem().ShouldBe(expectedLifecycle.ToString());
        }

        response.Headers.Contains("X-Hexalith-Projection-Version")
            .ShouldBe(expectedProvenance is QueryResponseProvenance.ProjectionBacked && !string.IsNullOrWhiteSpace(projectionVersion));
        response.Headers.ETag.ShouldBe(new EntityTagHeaderValue($"\"{eTag ?? projectionVersion}\""));

        using var replayClient = new HttpClient(new ReplayHandler(response))
        {
            BaseAddress = new Uri("https://tenants.invalid"),
        };
        var restClient = new TenantsRestQueryClient(replayClient);
        var memoriesClient = new MemoriesClient(
            new HttpClient { BaseAddress = new Uri("https://memories.invalid") },
            Options.Create(new MemoriesClientOptions()),
            NullLogger<MemoriesClient>.Instance);
        var uiGateway = new TenantQueryGateway(
            restClient,
            new FixedUserContextAccessor("admin.current"),
            memoriesClient,
            new TenantSearchCursorCodec(new EphemeralDataProtectionProvider()));

        GlobalAdministratorsSnapshot snapshot = await uiGateway.GetGlobalAdministratorsAsync(
            new GlobalAdministratorsRequest(PageSize: 20),
            previous: null,
            TestContext.Current.CancellationToken);

        snapshot.Kind.ShouldBe(expectedKind);
        snapshot.Lifecycle.ShouldBe(expectedLifecycle);
        snapshot.ProjectionVersion.ShouldBe(
            expectedProvenance is QueryResponseProvenance.ProjectionBacked ? projectionVersion : null);
        snapshot.IsCompleteEvidence.ShouldBe(expectedCompleteEvidence);
        snapshot.Rows.Select(static row => row.UserId).ShouldBe(["admin.current", "target.user"]);
    }

    [Theory]
    [InlineData("stored-validator")]
    [InlineData(null)]
    public async Task PersistedRemovalProofSurvivesRealProjectionHandlerQueryRouterRestAndUiGateway(string? storeTag)
    {
        DateTimeOffset now = new(2026, 10, 13, 12, 0, 0, TimeSpan.Zero);
        const string tenantId = "tenant.alpha";
        const string correlation = "exact-removal-attempt";
        IReadModelStore store = Substitute.For<IReadModelStore>();
        var persisted = new Dictionary<string, object>(StringComparer.Ordinal);
        ConfigurePersistedModel<TenantReadModel>(store, persisted, storeTag);
        ConfigurePersistedModel<TenantAuditReadModel>(store, persisted, storeTag);
        ConfigurePersistedModel<TenantIndexReadModel>(store, persisted, storeTag);
        ConfigurePersistedModel<GlobalAdministratorReadModel>(store, persisted, storeTag);
        persisted["projection:global-administrators:singleton"] = new GlobalAdministratorReadModel
        {
            Administrators = ["admin.current"], ProjectedAt = now, ProjectionVersion = "tenant-sequence:1",
        };
        ProjectionEventDto[] events =
        [
            ProjectionEvent(new TenantCreated(tenantId, "Alpha", null, now), "evt-created-1", 1, now),
            ProjectionEvent(new UserAddedToTenant(tenantId, "reader", TenantRole.TenantReader), "evt-added-2", 2, now),
            ProjectionEvent(new UserRemovedFromTenant(tenantId, "reader"), "evt-removal-3", 3, now) with { CorrelationId = correlation },
        ];
        _ = await new TenantProjectionHandler(store, NullLogger<TenantProjectionHandler>.Instance, new FixedTimeProvider(now))
            .ProjectAsync(new ProjectionRequest("system", "tenants", tenantId, events), TestContext.Current.CancellationToken);
        TenantReadModel tenant = persisted["projection:tenants:" + tenantId].ShouldBeOfType<TenantReadModel>();
        tenant.Members.ShouldNotContainKey("reader");
        tenant.ProjectionVersion.ShouldBe("tenant-sequence:3");
        TenantAuditReadModel audit = persisted["audit:" + tenantId].ShouldBeOfType<TenantAuditReadModel>();
        audit.ProjectionVersion.ShouldBe("tenant-sequence:3");
        TenantAuditEntry storedRemoval = audit.Entries.Single(row => row.EventType == nameof(UserRemovedFromTenant));
        storedRemoval.EventId.ShouldBe("evt-removal-3");
        storedRemoval.CommandCorrelationId.ShouldBe(correlation);
        storedRemoval.AggregateSequence.ShouldBe(3);

        using var diagnostics = new EventStoreDomainDiagnostics("tenants");
        var handler = new GetTenantAuditQueryHandler(store,
            new QueryCursorCodec(new EphemeralDataProtectionProvider(), "Hexalith.Tenants.Integration.QueryCursor.v1"),
            new TenantTelemetry(diagnostics), NullLogger<GetTenantAuditQueryHandler>.Instance,
            timeProvider: new FixedTimeProvider(now));
        using var gateway = new HandlerRoutedEventStoreGatewayClient(handler);
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient serviceClient = CreateAuthenticatedClient(factory);
        using HttpResponseMessage response = await serviceClient.GetAsync("/api/tenants/" + tenantId + "/audit", TestContext.Current.CancellationToken);
        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        response.Headers.GetValues("X-Hexalith-Projection-Lifecycle").ShouldHaveSingleItem().ShouldBe("Current");
        // The complete persisted replay certifies producer authority independently of the store ETag.
        response.Headers.GetValues("X-Hexalith-Projection-Version").ShouldHaveSingleItem().ShouldBe(audit.ProjectionVersion);
        response.Headers.ETag.ShouldBe(new EntityTagHeaderValue($"\"{storeTag ?? audit.ProjectionVersion}\""));
        using var replayClient = new HttpClient(new ReplayHandler(response)) { BaseAddress = new Uri("https://tenants.invalid") };
        var memoriesClient = new MemoriesClient(new HttpClient { BaseAddress = new Uri("https://memories.invalid") },
            Options.Create(new MemoriesClientOptions()), NullLogger<MemoriesClient>.Instance);
        var uiGateway = new TenantQueryGateway(new TenantsRestQueryClient(replayClient),
            new FixedUserContextAccessor("admin.current"), memoriesClient,
            new TenantSearchCursorCodec(new EphemeralDataProtectionProvider()));
        TenantAuditSnapshot snapshot = await uiGateway.GetTenantAuditAsync(new TenantAuditRequest(tenantId), null, TestContext.Current.CancellationToken);
        snapshot.Freshness.ShouldBe(ReadModelFreshnessState.Current);
        snapshot.Lifecycle.ShouldBe(ProjectionLifecycleState.Current);
        snapshot.ProjectionVersion.ShouldBe(audit.ProjectionVersion);
        snapshot.ETag.ShouldBe(storeTag ?? audit.ProjectionVersion);
        TenantAuditRow row = snapshot.Rows.Single(entry => entry.EventType == nameof(UserRemovedFromTenant));
        row.CommandCorrelationId.ShouldBe(correlation);
        row.AggregateSequence.ShouldBe(3);
        TenantRemoveMemberCommandSnapshot.IsMatchingRemovalProof(row, tenantId, "reader", correlation, 3).ShouldBeTrue();
        TenantRemoveMemberCommandSnapshot.IsMatchingRemovalProof(row, tenantId, "reader", "other-attempt", 3).ShouldBeFalse();
        TenantRemoveMemberCommandSnapshot.IsMatchingRemovalProof(row, tenantId, "reader", correlation, 4).ShouldBeFalse();
        TenantAuditReceipt receipt = TenantAuditReceipt.FromRow(row);
        receipt.State.ShouldBe(TenantAuditReceiptState.Ready);
        receipt.ToString().ShouldNotContain(correlation);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("stored-validator")]
    public async Task PersistedIndexAuthoritySurvivesProjectionRestAndUiWithoutStoreTags(string? storeTag)
    {
        DateTimeOffset now = new(2026, 10, 26, 12, 0, 0, TimeSpan.Zero);
        IReadModelStore store = Substitute.For<IReadModelStore>();
        var persisted = new Dictionary<string, object>(StringComparer.Ordinal);
        ConfigurePersistedModel<TenantReadModel>(store, persisted, storeTag);
        ConfigurePersistedModel<TenantAuditReadModel>(store, persisted, storeTag);
        ConfigurePersistedModel<TenantIndexReadModel>(store, persisted, storeTag);
        ConfigurePersistedModel<GlobalAdministratorReadModel>(store, persisted, storeTag);
        persisted["projection:global-administrators:singleton"] = new GlobalAdministratorReadModel { Administrators = ["admin.current"] };
        _ = await new TenantProjectionHandler(store, NullLogger<TenantProjectionHandler>.Instance, new FixedTimeProvider(now))
            .ProjectAsync(new("system", "tenants", "tenant.alpha",
            [ProjectionEvent(new TenantCreated("tenant.alpha", "Alpha", null, now), "created", 1, now),
             ProjectionEvent(new UserAddedToTenant("tenant.alpha", "reader", TenantRole.TenantReader), "reader", 2, now)]));
        TenantIndexReadModel index = persisted["projection:tenant-index:singleton"].ShouldBeOfType<TenantIndexReadModel>();
        index.AggregateSequences["tenant.alpha"].ShouldBe(2);
        index.ProjectionVersion.ShouldBe(TenantIndexProjectionVersion.Create(index));
        index.ProjectionVersion.ShouldNotBeNull();
        using var diagnostics = new EventStoreDomainDiagnostics("tenants");
        var handler = new GetUserTenantsQueryHandler(store,
            new QueryCursorCodec(new EphemeralDataProtectionProvider(), "index-authority"),
            new TenantTelemetry(diagnostics), NullLogger<GetUserTenantsQueryHandler>.Instance, timeProvider: new FixedTimeProvider(now));
        using var gateway = new HandlerRoutedEventStoreGatewayClient(handler);
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient serviceClient = CreateAuthenticatedClient(factory);
        using HttpResponseMessage response = await serviceClient.GetAsync("/api/users/reader/tenants");
        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        response.Headers.ETag.ShouldBe(new EntityTagHeaderValue($"\"{storeTag ?? index.ProjectionVersion}\""));
        response.Headers.GetValues("X-Hexalith-Projection-Version").ShouldHaveSingleItem().ShouldBe(index.ProjectionVersion);
        using var replayClient = new HttpClient(new ReplayHandler(response)) { BaseAddress = new Uri("https://tenants.invalid") };
        var memoriesClient = new MemoriesClient(new HttpClient { BaseAddress = new Uri("https://memories.invalid") },
            Options.Create(new MemoriesClientOptions()), NullLogger<MemoriesClient>.Instance);
        var snapshot = await new TenantQueryGateway(new TenantsRestQueryClient(replayClient),
            new FixedUserContextAccessor("admin.current"), memoriesClient,
            new TenantSearchCursorCodec(new EphemeralDataProtectionProvider())).GetUserTenantsAsync(new("reader"), null);
        snapshot.ProjectionVersion.ShouldBe(index.ProjectionVersion);
        snapshot.ETag.ShouldBe(storeTag ?? index.ProjectionVersion);
        snapshot.Freshness.ShouldBe(ReadModelFreshnessState.Current);
        snapshot.Lifecycle.ShouldBe(ProjectionLifecycleState.Current);
        snapshot.Rows.ShouldHaveSingleItem().TenantId.ShouldBe("tenant.alpha");
    }

    private static ProjectionEventDto ProjectionEvent(IEventPayload payload, string eventId, long sequence, DateTimeOffset timestamp)
        => new(payload.GetType().FullName!, JsonSerializer.SerializeToUtf8Bytes(payload, payload.GetType()), "json", sequence,
            timestamp, "unrelated-correlation", eventId, "admin.current");

    [Fact]
    public async Task AmbiguousLegacyUsesExistingSdkHttpFailureAndUiErrorWithoutEvidence()
    {
        IReadModelStore store = Substitute.For<IReadModelStore>();
        var persisted = new Dictionary<string, object>
        {
            ["projection:global-administrators:singleton"] = new GlobalAdministratorReadModel { Administrators = ["admin.current"] },
            [TenantAuditStreams.LegacySystemKey] = new TenantAuditReadModel
            {
                Entries = [new TenantAuditEntry("private-evidence-reference", "UnknownEvent", AuditEventCategory.Access,
                    "private-actor", DateTimeOffset.UtcNow, "system", new Dictionary<string, string>())],
            },
        };
        ConfigurePersistedModel<GlobalAdministratorReadModel>(store, persisted);
        ConfigurePersistedModel<TenantAuditReadModel>(store, persisted);
        using var diagnostics = new EventStoreDomainDiagnostics("tenants");
        var handler = new GetTenantAuditQueryHandler(store,
            new QueryCursorCodec(new EphemeralDataProtectionProvider(), "failure-boundary"),
            new TenantTelemetry(diagnostics), NullLogger<GetTenantAuditQueryHandler>.Instance);
        var router = new HandlerAwareQueryRouter(new UnexpectedInnerQueryRouter(), new AlwaysSupportedDomainQueryHandlerRegistry(),
            new DirectDomainQueryInvoker(handler), NullLogger<HandlerAwareQueryRouter>.Instance);
        var submit = new Hexalith.EventStore.Server.Pipeline.SubmitQueryHandler(router,
            NullLogger<Hexalith.EventStore.Server.Pipeline.SubmitQueryHandler>.Instance);
        var exceptionHandler = new Hexalith.EventStore.ErrorHandling.QueryExecutionFailedExceptionHandler(
            NullLogger<Hexalith.EventStore.ErrorHandling.QueryExecutionFailedExceptionHandler>.Instance);
        var builder = Microsoft.AspNetCore.Builder.WebApplication.CreateBuilder();
        builder.WebHost.UseTestServer();
        await using var app = builder.Build();
        app.MapGet("/api/tenants/system/audit", async context =>
        {
            try
            {
                _ = await submit.Handle(new SubmitQuery("system", "tenants", "system", GetTenantAuditQuery.QueryType,
                    [], "safe-query-reference", "admin.current"), context.RequestAborted);
            }
            catch (QueryExecutionFailedException failure)
            {
                failure.StatusCode.ShouldBe(500);
                _ = await exceptionHandler.TryHandleAsync(context, failure, context.RequestAborted);
            }
        });
        await app.StartAsync();
        using HttpClient client = app.GetTestClient();
        using HttpResponseMessage response = await client.GetAsync("/api/tenants/system/audit");
        response.StatusCode.ShouldBe(HttpStatusCode.InternalServerError);
        string body = await response.Content.ReadAsStringAsync();
        body.ShouldNotContain("private-evidence-reference");
        body.ShouldNotContain("private-actor");
        response.Headers.Contains("X-Hexalith-Projection-Version").ShouldBeFalse();
        response.Headers.ETag.ShouldBeNull();
        using var replayClient = new HttpClient(new ReplayHandler(response)) { BaseAddress = new Uri("https://tenants.invalid") };
        var memories = new MemoriesClient(new HttpClient { BaseAddress = new Uri("https://memories.invalid") },
            Options.Create(new MemoriesClientOptions()), NullLogger<MemoriesClient>.Instance);
        TenantAuditSnapshot snapshot = await new TenantQueryGateway(new TenantsRestQueryClient(replayClient),
            new FixedUserContextAccessor("admin.current"), memories,
            new TenantSearchCursorCodec(new EphemeralDataProtectionProvider())).GetTenantAuditAsync(new("system"), null);
        snapshot.Kind.ShouldBe(TenantAuditSurfaceKind.Error);
        snapshot.Rows.ShouldBeEmpty();
        snapshot.ETag.ShouldBeNull();
        snapshot.ProjectionVersion.ShouldBeNull();
    }

    private static void ConfigurePersistedModel<T>(IReadModelStore store, Dictionary<string, object> persisted, string? storeTag = "stored-validator") where T : class
    {
        store.GetAsync<T>(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(call => new ReadModelEntry<T>(persisted.TryGetValue(call.ArgAt<string>(1), out object? value) ? (T)value : null, storeTag));
        store.TrySaveAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<T>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(call => { persisted[call.ArgAt<string>(1)] = call.ArgAt<T>(2); return true; });
    }

    [Theory]
    [InlineData("tenant.alpha", null)]
    [InlineData("system", null)]
    [InlineData("system", "tenant")]
    [InlineData("system", "global-administrators")]
    public async Task TenantAudit_generated_route_submits_tenant_scoped_filter_payload(string tenantId, string? stream)
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<TenantAuditEntry>([], null, false));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync(
            $"/api/tenants/{tenantId}/audit?category=Access&cursor=audit-cursor&pageSize=30"
                + (stream is null ? string.Empty : "&stream=" + stream));

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        SubmittedQuery query = gateway.SubmittedQueries.ShouldHaveSingleItem();
        query.Request.Tenant.ShouldBe("system");
        query.Request.Domain.ShouldBe(GetTenantAuditQuery.Domain);
        query.Request.AggregateId.ShouldBe(tenantId);
        query.Request.EntityId.ShouldBe(tenantId);
        query.Request.QueryType.ShouldBe(GetTenantAuditQuery.QueryType);
        query.Request.ProjectionType.ShouldBe(GetTenantAuditQuery.ProjectionType);
        JsonElement payload = query.Request.Payload.ShouldNotBeNull();
        payload.GetProperty("category").GetString().ShouldBe(nameof(AuditEventCategory.Access));
        payload.GetProperty("cursor").GetString().ShouldBe("audit-cursor");
        payload.GetProperty("pageSize").GetInt32().ShouldBe(30);
        if (stream is not null)
        {
            payload.GetProperty("stream").GetString().ShouldBe(stream);
        }
    }

    [Fact]
    public async Task Generated_query_route_preserves_if_none_match_and_returns_not_modified_with_freshness_headers()
    {
        DateTimeOffset servedAt = DateTimeOffset.Parse("2026-07-03T05:15:00Z", CultureInfo.InvariantCulture);
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueNotModified(
            "index-etag-2",
            new QueryResponseMetadata(
                ETag: "index-etag-2",
                IsNotModified: true,
                IsStale: false,
                ProjectionVersion: "index-v2",
                ServedAt: servedAt)
            {
                Provenance = QueryResponseProvenance.ProjectionBacked,
            });
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/tenants?pageSize=25");
        request.Headers.IfNoneMatch.ParseAdd("\"index-etag-1\"");

        HttpResponseMessage response = await client.SendAsync(request);

        response.StatusCode.ShouldBe(HttpStatusCode.NotModified);
        response.Headers.ETag.ShouldNotBeNull().Tag.ShouldBe("\"index-etag-2\"");
        response.Headers.GetValues("X-Hexalith-Projection-Version").ShouldHaveSingleItem().ShouldBe("index-v2");
        response.Headers.GetValues("X-Hexalith-Served-At").ShouldHaveSingleItem().ShouldBe(servedAt.ToString("O", CultureInfo.InvariantCulture));
        response.Headers.GetValues("X-Hexalith-Is-Stale").ShouldHaveSingleItem().ShouldBe("false");
        gateway.SubmittedQueries.ShouldHaveSingleItem().IfNoneMatch.ShouldBe("\"index-etag-1\"");
    }

    [Fact]
    public async Task Generated_query_route_returns_safe_problem_when_not_modified_has_no_strong_etag()
    {
        await AssertNotModifiedWithoutStrongETagMapsToBadGatewayAsync(null);
    }

    [Fact]
    public async Task Generated_query_route_returns_safe_problem_when_not_modified_has_weak_etag()
    {
        await AssertNotModifiedWithoutStrongETagMapsToBadGatewayAsync("W/\"index-etag-2\"");
    }

    [Fact]
    public async Task Generated_query_route_returns_safe_problem_when_not_modified_is_not_projection_backed()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueNotModified(
            "index-etag-2",
            new QueryResponseMetadata(ETag: "index-etag-2", IsNotModified: true));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);
        using var request = new HttpRequestMessage(HttpMethod.Get, "/api/tenants");
        request.Headers.IfNoneMatch.ParseAdd("\"index-etag-2\"");

        HttpResponseMessage response = await client.SendAsync(
            request,
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.BadGateway);
        response.Headers.Contains("ETag").ShouldBeFalse();
        JsonElement problem = await response.Content.ReadFromJsonAsync<JsonElement>(
            cancellationToken: TestContext.Current.CancellationToken);
        problem.GetProperty("title").GetString().ShouldBe("Bad Gateway");
    }

    [Theory]
    [InlineData("wrong-issuer", JwtAudience)]
    [InlineData(JwtIssuer, "wrong-audience")]
    public async Task ListTenants_rejects_token_with_untrusted_issuer_or_audience(string issuer, string audience)
    {
        CapturingEventStoreGatewayClient gateway = new();
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            "Bearer",
            CreateJwt("test-user", "queries:*", issuer, audience));

        HttpResponseMessage response = await client.GetAsync("/api/tenants", TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
        gateway.SubmittedQueries.ShouldBeEmpty();
    }

    [Fact]
    public async Task ListTenants_authority_mode_uses_discovery_signing_keys_and_validates_issuer()
    {
        const string authority = "https://identity.example.test";
        var discoveryConfiguration = new OpenIdConnectConfiguration
        {
            Issuer = authority,
        };
        discoveryConfiguration.SigningKeys.Add(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtSigningKey)));

        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<TenantSummary>([], null, false));
        await using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:Authority"] = authority,
                ["EventStore:Authentication:Audience"] = JwtAudience,
                ["EventStore:Authentication:RequireHttpsMetadata"] = "false",
            },
            services => services.PostConfigure<JwtBearerOptions>(
                JwtBearerDefaults.AuthenticationScheme,
                options => options.ConfigurationManager =
                    new StaticConfigurationManager<OpenIdConnectConfiguration>(discoveryConfiguration)));
        using HttpClient client = factory.CreateClient();

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            "Bearer",
            CreateJwt("test-user", "queries:*", authority, JwtAudience));
        HttpResponseMessage accepted = await client.GetAsync(
            "/api/tenants",
            TestContext.Current.CancellationToken);

        accepted.StatusCode.ShouldBe(HttpStatusCode.OK);
        gateway.SubmittedQueries.Count.ShouldBe(1);

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            "Bearer",
            CreateJwt("test-user", "queries:*", "https://untrusted.example.test", JwtAudience));
        HttpResponseMessage rejected = await client.GetAsync(
            "/api/tenants",
            TestContext.Current.CancellationToken);

        rejected.StatusCode.ShouldBe(HttpStatusCode.Unauthorized);
        gateway.SubmittedQueries.Count.ShouldBe(1);
    }

    [Theory]
    [InlineData(null, "EventStore:Authentication:SigningKey or Jwt:SigningKey is required when neither EventStore:Authentication:Authority nor Oidc:Authority is configured.")]
    [InlineData("", "EventStore:Authentication:SigningKey or Jwt:SigningKey is required when neither EventStore:Authentication:Authority nor Oidc:Authority is configured.")]
    [InlineData("   ", "EventStore:Authentication:SigningKey or Jwt:SigningKey is required when neither EventStore:Authentication:Authority nor Oidc:Authority is configured.")]
    [InlineData("short-key", "The configured EventStore:Authentication:SigningKey or Jwt:SigningKey must be at least 32 bytes (256 bits) for HS256 token validation.")]
    public void Symmetric_key_mode_rejects_missing_blank_or_short_signing_key(
        string? signingKey,
        string expectedMessage)
    {
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:Issuer"] = JwtIssuer,
                ["EventStore:Authentication:Audience"] = JwtAudience,
                ["EventStore:Authentication:SigningKey"] = signingKey,
            });

        InvalidOperationException exception = Should.Throw<InvalidOperationException>(() =>
            factory.Services
                .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
                .Get(JwtBearerDefaults.AuthenticationScheme));

        exception.Message.ShouldBe(expectedMessage);
    }

    [Fact]
    public void Symmetric_key_mode_accepts_exactly_32_bytes()
    {
        string signingKey = new('a', 32);
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:Issuer"] = JwtIssuer,
                ["EventStore:Authentication:Audience"] = JwtAudience,
                ["EventStore:Authentication:SigningKey"] = signingKey,
            });

        JwtBearerOptions options = factory.Services
            .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
            .Get(JwtBearerDefaults.AuthenticationScheme);

        SymmetricSecurityKey key = options.TokenValidationParameters.IssuerSigningKey
            .ShouldBeOfType<SymmetricSecurityKey>();
        key.KeySize.ShouldBe(256);
    }

    [Fact]
    public async Task Public_api_accepts_jwt_signing_key_alias_without_eventstore_authentication_keys()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<TenantSummary>([], null, false));
        await using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?> { ["Jwt:SigningKey"] = JwtSigningKey });
        using HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            "Bearer",
            CreateJwt("test-user", "queries:*", JwtIssuer, JwtAudience));

        using HttpResponseMessage response = await client.GetAsync(
            "/api/tenants",
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        gateway.SubmittedQueries.Count.ShouldBe(1);
    }

    [Fact]
    public async Task Public_api_accepts_oidc_authority_alias_without_eventstore_authentication_keys()
    {
        const string authority = "https://identity.example.test";
        var discoveryConfiguration = new OpenIdConnectConfiguration { Issuer = authority };
        discoveryConfiguration.SigningKeys.Add(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtSigningKey)));
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryResult(new PaginatedResult<TenantSummary>([], null, false));
        await using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?> { ["Oidc:Authority"] = authority },
            services => services.PostConfigure<JwtBearerOptions>(
                JwtBearerDefaults.AuthenticationScheme,
                options => options.ConfigurationManager =
                    new StaticConfigurationManager<OpenIdConnectConfiguration>(discoveryConfiguration)));
        using HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            "Bearer",
            CreateJwt("test-user", "queries:*", authority, JwtAudience));

        using HttpResponseMessage response = await client.GetAsync(
            "/api/tenants",
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.OK);
        gateway.SubmittedQueries.Count.ShouldBe(1);
    }

    [Fact]
    public void Blank_legacy_signing_key_uses_valid_alias()
    {
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:SigningKey"] = " ",
                ["Jwt:SigningKey"] = JwtSigningKey,
                ["EventStore:Authentication:Issuer"] = JwtIssuer,
                ["EventStore:Authentication:Audience"] = JwtAudience,
            });

        JwtBearerOptions options = factory.Services
            .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
            .Get(JwtBearerDefaults.AuthenticationScheme);

        options.TokenValidationParameters.IssuerSigningKey.ShouldBeOfType<SymmetricSecurityKey>()
            .KeySize.ShouldBeGreaterThanOrEqualTo(256);
    }

    [Fact]
    public void Blank_legacy_authority_uses_valid_alias()
    {
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:Authority"] = " ",
                ["Oidc:Authority"] = "https://identity.example.test",
                ["EventStore:Authentication:Issuer"] = "https://identity.example.test",
                ["EventStore:Authentication:Audience"] = JwtAudience,
            });

        JwtBearerOptions options = factory.Services
            .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
            .Get(JwtBearerDefaults.AuthenticationScheme);

        options.Authority.ShouldBe("https://identity.example.test");
    }

    [Fact]
    public void Legacy_signing_key_wins_over_alias()
    {
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:SigningKey"] = JwtSigningKey,
                ["Jwt:SigningKey"] = "alias-signing-key-that-is-at-least-32-bytes-long",
                ["EventStore:Authentication:Issuer"] = JwtIssuer,
                ["EventStore:Authentication:Audience"] = JwtAudience,
            });

        JwtBearerOptions options = factory.Services
            .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
            .Get(JwtBearerDefaults.AuthenticationScheme);

        options.TokenValidationParameters.IssuerSigningKey.ShouldBeOfType<SymmetricSecurityKey>()
            .Key.ShouldBe(Encoding.UTF8.GetBytes(JwtSigningKey));
    }

    [Fact]
    public void Legacy_authority_wins_over_alias()
    {
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["EventStore:Authentication:Authority"] = "https://legacy-identity.example.test",
                ["Oidc:Authority"] = "https://alias-identity.example.test",
                ["EventStore:Authentication:Issuer"] = "https://legacy-identity.example.test",
                ["EventStore:Authentication:Audience"] = JwtAudience,
            });

        JwtBearerOptions options = factory.Services
            .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
            .Get(JwtBearerDefaults.AuthenticationScheme);

        options.Authority.ShouldBe("https://legacy-identity.example.test");
    }

    [Fact]
    public void Short_alias_signing_key_names_both_key_aliases()
    {
        CapturingEventStoreGatewayClient gateway = new();
        using var factory = new TenantsApiWebApplicationFactory(
            gateway,
            new Dictionary<string, string?>
            {
                ["Jwt:SigningKey"] = "short-key",
                ["EventStore:Authentication:Issuer"] = JwtIssuer,
                ["EventStore:Authentication:Audience"] = JwtAudience,
            });

        InvalidOperationException exception = Should.Throw<InvalidOperationException>(() =>
            factory.Services
                .GetRequiredService<IOptionsMonitor<JwtBearerOptions>>()
                .Get(JwtBearerDefaults.AuthenticationScheme));

        exception.Message.ShouldBe(
            "The configured EventStore:Authentication:SigningKey or Jwt:SigningKey must be at least 32 bytes (256 bits) for HS256 token validation.");
    }

    private static async Task AssertNotModifiedWithoutStrongETagMapsToBadGatewayAsync(string? eTag)
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueNotModified(
            eTag,
            new QueryResponseMetadata(
                ETag: eTag,
                IsNotModified: true)
            {
                Provenance = QueryResponseProvenance.ProjectionBacked,
            });
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/tenants", TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.BadGateway);
        response.Headers.Contains("ETag").ShouldBeFalse();
        JsonElement problem = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: TestContext.Current.CancellationToken);
        problem.GetProperty("title").GetString().ShouldBe("Bad Gateway");
    }

    [Fact]
    public async Task Generated_query_route_maps_gateway_failure_to_safe_problem_details()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueQueryFailure(new EventStoreGatewayException(
            StatusCodes.Status403Forbidden,
            "Forbidden",
            detail: "Access denied.",
            correlationId: "01KTESTCORRELATION00000",
            tenantId: TenantIdentity.DefaultTenantId,
            reasonCode: "tenant-forbidden"));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);

        HttpResponseMessage response = await client.GetAsync("/api/tenants", TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.Forbidden);
        JsonElement problem = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: TestContext.Current.CancellationToken);
        problem.GetProperty("title").GetString().ShouldBe("Forbidden");
        problem.GetProperty("correlationId").GetString().ShouldBe("01KTESTCORRELATION00000");
        problem.GetProperty("tenantId").GetString().ShouldBe(TenantIdentity.DefaultTenantId);
        problem.GetProperty("reasonCode").GetString().ShouldBe("tenant-forbidden");
    }

    [Fact]
    public async Task Generated_query_route_propagates_request_cancellation_to_gateway()
    {
        CapturingEventStoreGatewayClient gateway = new()
        {
            BlockQueriesUntilCancellation = true,
        };
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory);
        using CancellationTokenSource cancellation = CancellationTokenSource.CreateLinkedTokenSource(
            TestContext.Current.CancellationToken);

        Task<HttpResponseMessage> request = client.GetAsync("/api/tenants", cancellation.Token);
        CancellationToken gatewayToken = await gateway.QueryStarted.Task.WaitAsync(
            TimeSpan.FromSeconds(10),
            TestContext.Current.CancellationToken);
        cancellation.Cancel();

        _ = await Should.ThrowAsync<OperationCanceledException>(() => request);
        gatewayToken.IsCancellationRequested.ShouldBeTrue();
    }

    [Fact]
    public async Task Generated_command_routes_submit_all_external_command_families_through_gateway()
    {
        foreach (CommandRouteCase commandCase in CommandRouteCases())
        {
            string statusId = UniqueIdHelper.GenerateSortableUniqueStringId();
            CapturingEventStoreGatewayClient gateway = new();
            gateway.EnqueueCommandResult(statusId);
            await using var factory = new TenantsApiWebApplicationFactory(gateway);
            using HttpClient client = CreateAuthenticatedClient(factory, "commands:*");

            HttpResponseMessage response = await SendJsonAsync(client, commandCase);

            response.StatusCode.ShouldBe(HttpStatusCode.Accepted, commandCase.Name);
            response.Headers.RetryAfter.ShouldNotBeNull().Delta.ShouldBe(TimeSpan.FromSeconds(1));
            response.Headers.Location.ShouldBeNull(commandCase.Name);
            SubmitCommandResponse? body = await response.Content.ReadFromJsonAsync<SubmitCommandResponse>(
                cancellationToken: TestContext.Current.CancellationToken);
            body.ShouldNotBeNull().CorrelationId.ShouldBe(statusId);

            SubmittedCommand command = gateway.SubmittedCommands.ShouldHaveSingleItem();
            command.Request.Tenant.ShouldBe(TenantIdentity.DefaultTenantId, commandCase.Name);
            command.Request.Domain.ShouldBe(commandCase.ExpectedDomain, commandCase.Name);
            command.Request.AggregateId.ShouldBe(commandCase.ExpectedAggregateId, commandCase.Name);
            command.Request.CommandType.ShouldBe(commandCase.ExpectedCommandType, commandCase.Name);
            command.Request.MessageId.ShouldNotBeNullOrWhiteSpace();
            _ = UniqueIdHelper.ExtractTimestamp(command.Request.MessageId);
            command.Request.Payload.GetProperty(commandCase.IdentityPropertyName).GetString().ShouldBe(commandCase.ExpectedIdentityValue);
            command.Request.Payload.GetRawText().ShouldBe(
                JsonSerializer.SerializeToElement(commandCase.Body, JsonOptions).GetRawText(),
                commandCase.Name);
            command.CancellationToken.CanBeCanceled.ShouldBeTrue(commandCase.Name);
        }
    }

    [Fact]
    public async Task Generated_command_route_rejects_null_body_before_gateway_call()
    {
        CapturingEventStoreGatewayClient gateway = new();
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory, "commands:*");
        using var content = new StringContent("null", Encoding.UTF8, "application/json");

        HttpResponseMessage response = await client.PostAsync(
            "/api/tenants/tenant.alpha/enable",
            content,
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
        JsonElement problem = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: TestContext.Current.CancellationToken);
        problem.GetProperty("detail").GetString().ShouldBe("Request body is required.");
        gateway.SubmittedCommands.ShouldBeEmpty();
    }

    [Fact]
    public async Task Generated_command_route_rejects_route_body_mismatch_before_gateway_call()
    {
        foreach (CommandMismatchCase mismatchCase in CommandMismatchCases())
        {
            CapturingEventStoreGatewayClient gateway = new();
            await using var factory = new TenantsApiWebApplicationFactory(gateway);
            using HttpClient client = CreateAuthenticatedClient(factory, "commands:*");

            using var request = new HttpRequestMessage(mismatchCase.Method, mismatchCase.Route)
            {
                Content = JsonContent.Create(mismatchCase.Body, options: JsonOptions),
            };

            HttpResponseMessage response = await client.SendAsync(request, TestContext.Current.CancellationToken);

            response.StatusCode.ShouldBe(HttpStatusCode.BadRequest, mismatchCase.Name);
            JsonElement problem = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: TestContext.Current.CancellationToken);
            problem.GetProperty("detail").GetString().ShouldNotBeNull().ShouldContain("does not match");
            gateway.SubmittedCommands.ShouldBeEmpty();
        }
    }

    [Fact]
    public async Task Generated_command_route_propagates_request_cancellation_to_gateway()
    {
        CapturingEventStoreGatewayClient gateway = new()
        {
            BlockCommandsUntilCancellation = true,
        };
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory, "commands:*");
        using CancellationTokenSource cancellation = CancellationTokenSource.CreateLinkedTokenSource(
            TestContext.Current.CancellationToken);

        Task<HttpResponseMessage> request = client.PostAsJsonAsync(
            "/api/tenants/tenant.alpha/enable",
            new EnableTenant("tenant.alpha"),
            JsonOptions,
            cancellation.Token);
        CancellationToken gatewayToken = await gateway.CommandStarted.Task.WaitAsync(
            TimeSpan.FromSeconds(10),
            TestContext.Current.CancellationToken);
        cancellation.Cancel();

        _ = await Should.ThrowAsync<OperationCanceledException>(() => request);
        gatewayToken.IsCancellationRequested.ShouldBeTrue();
    }

    [Fact]
    public async Task Generated_command_route_maps_gateway_failure_to_safe_problem_details()
    {
        CapturingEventStoreGatewayClient gateway = new();
        gateway.EnqueueCommandFailure(new EventStoreGatewayException(
            StatusCodes.Status403Forbidden,
            "Forbidden",
            detail: "Access denied.",
            correlationId: "01KTESTCORRELATION00000",
            tenantId: TenantIdentity.DefaultTenantId,
            reasonCode: "tenant-forbidden"));
        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient client = CreateAuthenticatedClient(factory, "commands:*");

        HttpResponseMessage response = await client.PostAsJsonAsync(
            "/api/tenants/tenant.alpha/enable",
            new EnableTenant("tenant.alpha"),
            JsonOptions,
            TestContext.Current.CancellationToken);

        response.StatusCode.ShouldBe(HttpStatusCode.Forbidden);
        JsonElement problem = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: TestContext.Current.CancellationToken);
        problem.GetProperty("title").GetString().ShouldBe("Forbidden");
        problem.GetProperty("correlationId").GetString().ShouldBe("01KTESTCORRELATION00000");
        problem.GetProperty("tenantId").GetString().ShouldBe(TenantIdentity.DefaultTenantId);
        problem.GetProperty("reasonCode").GetString().ShouldBe("tenant-forbidden");
        gateway.SubmittedCommands.ShouldHaveSingleItem();
    }

    /// <summary>
    /// Cross-checks the real <see cref="TenantsRestQueryClient"/> against the real generated controllers:
    /// the client builds the URIs, the controllers answer them, and the client parses what they emit.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Story 1.10's whole point is that the six UI reads go direct to these routes over this typed client.
    /// Every other test either drives the controller with a hand-written URL, or drives the client against a
    /// stub handler; the one live-stack read test substitutes an adapter that re-implements the pre-1.10
    /// SubmitQueryAsync path. Nothing checked the client's own route construction, or its header parsing,
    /// against the service that actually answers it -- so a renamed header or a changed route shape would
    /// break every read in a real deployment with the suite green.
    /// </para>
    /// <para>
    /// The client cannot be pointed straight at <c>factory.CreateClient()</c>: it builds request URIs with
    /// <c>UriCreationOptions.DangerousDisablePathAndQueryCanonicalization</c> so that dot-only tenant ids
    /// cannot be normalized into a different resource, and <c>Microsoft.AspNetCore.TestHost</c> throws
    /// <c>InvalidOperationException</c> on such a URI in <c>PathString.FromUriComponent</c>. Exercising the
    /// client in-process against the controllers therefore requires this three-stage cross-check rather than
    /// a single call; a real-socket harness would be needed to collapse it into one.
    /// </para>
    /// </remarks>
    [Fact]
    public async Task Direct_rest_client_routes_match_the_generated_controllers_and_parse_their_real_headers()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        DateTimeOffset servedAt = DateTimeOffset.Parse("2026-07-29T10:00:00Z", CultureInfo.InvariantCulture);

        // Stage 1: let the production client build every route, and capture exactly what it would send.
        var recorder = new RouteRecordingHandler();
        using (var recordingClient = new HttpClient(recorder) { BaseAddress = new Uri("https://tenants.invalid") })
        {
            var probe = new TenantsRestQueryClient(recordingClient);
            _ = await probe.ListTenantsAsync(new ListTenantsQuery { Cursor = "opaque", PageSize = 25 }, null, cancellationToken);
            _ = await probe.GetTenantAsync(new GetTenantQuery { TenantId = "tenant.alpha" }, null, cancellationToken);
            _ = await probe.GetTenantUsersAsync(new GetTenantUsersQuery { TenantId = "tenant.alpha", PageSize = 20 }, null, cancellationToken);
            _ = await probe.GetUserTenantsAsync(new GetUserTenantsQuery { UserId = "user.alpha", PageSize = 12 }, null, cancellationToken);
            _ = await probe.GetTenantAuditAsync(new GetTenantAuditQuery { TenantId = "tenant.alpha", PageSize = 50 }, null, cancellationToken);
            _ = await probe.GetGlobalAdministratorsAsync(new GetGlobalAdministratorsQuery { PageSize = 20 }, null, cancellationToken);
        }

        recorder.Paths.Count.ShouldBe(6);

        // The paths must carry their query parameters, not merely be routable. Asserting only the count and
        // the QueryType order let a regression that stopped appending query parameters yield six routable
        // paths in the same order while every paged read silently lost its cursor and page size.
        recorder.Paths[0].ShouldContain("pageSize=25");
        recorder.Paths[0].ShouldContain("cursor=opaque");
        recorder.Paths[2].ShouldContain("pageSize=20");
        recorder.Paths[3].ShouldContain("pageSize=12");
        recorder.Paths[4].ShouldContain("pageSize=50");
        recorder.Paths[5].ShouldContain("pageSize=20");

        // Stage 2: the generated controllers must answer those exact paths -- not hand-written equivalents.
        CapturingEventStoreGatewayClient gateway = new();
        // Lifecycle is set, not left at Unknown. The emitter writes X-Hexalith-Projection-Lifecycle only for
        // a non-Unknown value, so the whole malformed/contradiction/normalize block in TenantsRestQueryClient
        // was bypassed and no assertion below read Metadata.Lifecycle at all.
        QueryResponseMetadata Metadata(string version) => new(
            ETag: version,
            IsStale: false,
            ProjectionVersion: version,
            ServedAt: servedAt)
        {
            Provenance = QueryResponseProvenance.ProjectionBacked,
            Lifecycle = ProjectionLifecycleState.Current,
        };

        gateway.EnqueueQueryResult(
            new PaginatedResult<TenantSummary>([new TenantSummary("tenant.alpha", "Alpha", TenantStatus.Active)], null, false),
            eTag: "list-v1",
            Metadata("list-v1"));
        gateway.EnqueueQueryResult(
            new TenantDetail(
                "tenant.alpha",
                "Alpha",
                "Alpha description",
                TenantStatus.Active,
                [new TenantMember("user.alpha", TenantRole.TenantOwner)],
                new Dictionary<string, string>(StringComparer.Ordinal),
                servedAt),
            eTag: "detail-v1",
            Metadata("detail-v1"));
        gateway.EnqueueQueryResult(
            new PaginatedResult<TenantMember>([new TenantMember("user.alpha", TenantRole.TenantOwner)], null, false),
            eTag: "members-v1",
            Metadata("members-v1"));
        gateway.EnqueueQueryResult(
            new PaginatedResult<UserTenantMembership>([], null, false),
            eTag: "user-tenants-v1",
            Metadata("user-tenants-v1"));
        gateway.EnqueueQueryResult(
            new PaginatedResult<TenantAuditEntry>([], null, false),
            eTag: "audit-v1",
            Metadata("audit-v1"));
        gateway.EnqueueQueryResult(
            new PaginatedResult<GlobalAdministratorSummary>([new GlobalAdministratorSummary("admin.alpha")], null, false),
            eTag: "admins-v1",
            Metadata("admins-v1"));

        await using var factory = new TenantsApiWebApplicationFactory(gateway);
        using HttpClient serviceClient = CreateAuthenticatedClient(factory);

        List<HttpResponseMessage> realResponses = [];
        foreach (string path in recorder.Paths)
        {
            HttpResponseMessage response = await serviceClient.GetAsync(path, cancellationToken);
            response.StatusCode.ShouldBe(HttpStatusCode.OK, $"the generated controllers must serve the route the client builds: {path}");
            realResponses.Add(response);
        }

        gateway.SubmittedQueries.Select(static query => query.Request.QueryType).ShouldBe(
        [
            ListTenantsQuery.QueryType,
            GetTenantQuery.QueryType,
            GetTenantUsersQuery.QueryType,
            GetUserTenantsQuery.QueryType,
            GetTenantAuditQuery.QueryType,
            GetGlobalAdministratorsQuery.QueryType,
        ]);

        // Stage 3: replay each REAL response -- real status, real X-Hexalith-* headers, real body -- through
        // the production client, so its metadata parsing is proven against what the service actually emits.
        async Task<TenantsRestQueryResponse<TPayload>> ReplayAsync<TPayload>(
            int index,
            Func<TenantsRestQueryClient, Task<TenantsRestQueryResponse<TPayload>>> read)
        {
            using var replay = new HttpClient(new ReplayHandler(realResponses[index]))
            {
                BaseAddress = new Uri("https://tenants.invalid"),
            };
            return await read(new TenantsRestQueryClient(replay));
        }

        TenantsRestQueryResponse<PaginatedResult<TenantSummary>> list = await ReplayAsync(
            0, client => client.ListTenantsAsync(new ListTenantsQuery { Cursor = "opaque", PageSize = 25 }, null, cancellationToken));
        list.FailureKind.ShouldBe(TenantsRestQueryFailureKind.None);
        list.Payload.ShouldNotBeNull().Items.ShouldHaveSingleItem().TenantId.ShouldBe("tenant.alpha");
        list.Metadata.ShouldNotBeNull().ProjectionVersion.ShouldBe("list-v1");
        list.Metadata!.Provenance.ShouldBe(QueryResponseProvenance.ProjectionBacked);
        list.Metadata!.Lifecycle.ShouldBe(
            ProjectionLifecycleState.Current,
            "the client must parse the lifecycle header the real emitter writes");
        // GetStrongETag returns the unquoted strong tag content, so this is the controller's ETag as the
        // client stores it -- the same shape TenantsRestQueryClientTests pins against a stub handler.
        list.ETag.ShouldBe("list-v1");

        TenantsRestQueryResponse<TenantDetail> detail = await ReplayAsync(
            1, client => client.GetTenantAsync(new GetTenantQuery { TenantId = "tenant.alpha" }, null, cancellationToken));
        detail.FailureKind.ShouldBe(TenantsRestQueryFailureKind.None);
        detail.Payload.ShouldNotBeNull().TenantId.ShouldBe("tenant.alpha");
        detail.Metadata.ShouldNotBeNull().ProjectionVersion.ShouldBe("detail-v1");

        TenantsRestQueryResponse<PaginatedResult<TenantMember>> members = await ReplayAsync(
            2, client => client.GetTenantUsersAsync(new GetTenantUsersQuery { TenantId = "tenant.alpha", PageSize = 20 }, null, cancellationToken));
        members.FailureKind.ShouldBe(TenantsRestQueryFailureKind.None);
        members.Payload.ShouldNotBeNull().Items.ShouldHaveSingleItem().UserId.ShouldBe("user.alpha");
        members.Metadata.ShouldNotBeNull().ProjectionVersion.ShouldBe("members-v1");

        TenantsRestQueryResponse<PaginatedResult<UserTenantMembership>> userTenants = await ReplayAsync(
            3, client => client.GetUserTenantsAsync(new GetUserTenantsQuery { UserId = "user.alpha", PageSize = 12 }, null, cancellationToken));
        userTenants.FailureKind.ShouldBe(TenantsRestQueryFailureKind.None);
        userTenants.Payload.ShouldNotBeNull().Items.ShouldBeEmpty();

        TenantsRestQueryResponse<PaginatedResult<TenantAuditEntry>> audit = await ReplayAsync(
            4, client => client.GetTenantAuditAsync(new GetTenantAuditQuery { TenantId = "tenant.alpha", PageSize = 50 }, null, cancellationToken));
        audit.FailureKind.ShouldBe(TenantsRestQueryFailureKind.None);
        audit.Payload.ShouldNotBeNull().Items.ShouldBeEmpty();

        TenantsRestQueryResponse<PaginatedResult<GlobalAdministratorSummary>> admins = await ReplayAsync(
            5, client => client.GetGlobalAdministratorsAsync(new GetGlobalAdministratorsQuery { PageSize = 20 }, null, cancellationToken));
        admins.FailureKind.ShouldBe(TenantsRestQueryFailureKind.None);
        admins.Payload.ShouldNotBeNull().Items.ShouldHaveSingleItem().UserId.ShouldBe("admin.alpha");
        admins.Metadata.ShouldNotBeNull().ProjectionVersion.ShouldBe("admins-v1");

        // Stage 4: the conditional path, end to end. The controller's 304 behaviour and the client's 304
        // parsing were each covered separately -- against hand-written URLs and against a stub handler -- so
        // the one seam neither covered was the one that matters: IsSupportedNotModified needs an exact strong
        // ETag plus a projection version plus projection-backed provenance, all from the real emitter.
        gateway.EnqueueNotModified(
            "list-v1",
            new QueryResponseMetadata(
                ETag: "list-v1",
                IsNotModified: true,
                IsStale: false,
                ProjectionVersion: "list-v1",
                ServedAt: servedAt)
            {
                Provenance = QueryResponseProvenance.ProjectionBacked,
                Lifecycle = ProjectionLifecycleState.Current,
            });

        using var conditionalRequest = new HttpRequestMessage(HttpMethod.Get, recorder.Paths[0]);
        conditionalRequest.Headers.IfNoneMatch.ParseAdd("\"list-v1\"");
        using HttpResponseMessage notModified = await serviceClient.SendAsync(conditionalRequest, cancellationToken);
        notModified.StatusCode.ShouldBe(HttpStatusCode.NotModified);

        using (var replay = new HttpClient(new ReplayHandler(notModified))
        {
            BaseAddress = new Uri("https://tenants.invalid"),
        })
        {
            TenantsRestQueryResponse<PaginatedResult<TenantSummary>> conditional =
                await new TenantsRestQueryClient(replay).ListTenantsAsync(
                    new ListTenantsQuery { Cursor = "opaque", PageSize = 25 },
                    "list-v1",
                    cancellationToken);

            conditional.FailureKind.ShouldBe(
                TenantsRestQueryFailureKind.None,
                "a 304 from the real emitter must satisfy every clause of IsSupportedNotModified");
            conditional.Metadata.ShouldNotBeNull().IsNotModified.ShouldBe(true);
            conditional.Metadata!.ProjectionVersion.ShouldBe("list-v1");
            conditional.Metadata!.Provenance.ShouldBe(QueryResponseProvenance.ProjectionBacked);
            conditional.Metadata!.Lifecycle.ShouldBe(ProjectionLifecycleState.Current);
            conditional.ETag.ShouldBe("list-v1");
        }

        foreach (HttpResponseMessage response in realResponses)
        {
            response.Dispose();
        }
    }

    /// <summary>Captures the paths the production client builds, without answering them meaningfully.</summary>
    private sealed class RouteRecordingHandler : HttpMessageHandler
    {
        public List<string> Paths { get; } = [];

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Paths.Add(request.RequestUri!.PathAndQuery);
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.ServiceUnavailable));
        }
    }

    /// <summary>Replays one captured real service response so the client parses genuine headers and body.</summary>
    private sealed class ReplayHandler(HttpResponseMessage captured) : HttpMessageHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            byte[] body = await captured.Content.ReadAsByteArrayAsync(cancellationToken);
            var replayed = new HttpResponseMessage(captured.StatusCode)
            {
                Content = new ByteArrayContent(body),
            };
            foreach (KeyValuePair<string, IEnumerable<string>> header in captured.Headers)
            {
                _ = replayed.Headers.TryAddWithoutValidation(header.Key, header.Value);
            }

            foreach (KeyValuePair<string, IEnumerable<string>> header in captured.Content.Headers)
            {
                _ = replayed.Content.Headers.TryAddWithoutValidation(header.Key, header.Value);
            }

            return replayed;
        }
    }

    private static HttpClient CreateAuthenticatedClient(
        TenantsApiWebApplicationFactory factory,
        string permission = "queries:*")
    {
        HttpClient client = factory.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", CreateJwt("test-user", permission));
        return client;
    }

    private static string CreateJwt(
        string subject,
        string permission,
        string issuer = JwtIssuer,
        string audience = JwtAudience)
    {
        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtSigningKey)),
            SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims:
            [
                new Claim("sub", subject),
                new Claim("permissions", JsonSerializer.Serialize(new[] { permission }), JsonClaimValueTypes.JsonArray),
                new Claim("tenants", JsonSerializer.Serialize(new[] { "system", "tenant.alpha" }), JsonClaimValueTypes.JsonArray),
            ],
            notBefore: DateTime.UtcNow.AddMinutes(-1),
            expires: DateTime.UtcNow.AddMinutes(10),
            signingCredentials: credentials);
        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static async Task<HttpResponseMessage> SendJsonAsync(HttpClient client, CommandRouteCase commandCase)
    {
        using var request = new HttpRequestMessage(commandCase.Method, commandCase.Route)
        {
            Content = JsonContent.Create(commandCase.Body, options: JsonOptions),
        };

        return await client.SendAsync(request, TestContext.Current.CancellationToken);
    }

    private static CommandRouteCase[] CommandRouteCases()
        =>
        [
            new(
                "create tenant",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha",
                new CreateTenant("tenant.alpha", "Alpha", "Tenant Alpha"),
                TenantIdentity.Domain,
                "tenant.alpha",
                CreateTenant.CommandType,
                "tenantId",
                "tenant.alpha"),
            new(
                "update tenant",
                HttpMethod.Put,
                "/api/tenants/tenant.alpha",
                new UpdateTenant("tenant.alpha", "Alpha Updated", "Updated tenant"),
                TenantIdentity.Domain,
                "tenant.alpha",
                UpdateTenant.CommandType,
                "tenantId",
                "tenant.alpha"),
            new(
                "enable tenant",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/enable",
                new EnableTenant("tenant.alpha"),
                TenantIdentity.Domain,
                "tenant.alpha",
                EnableTenant.CommandType,
                "tenantId",
                "tenant.alpha"),
            new(
                "disable tenant",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/disable",
                new DisableTenant("tenant.alpha"),
                TenantIdentity.Domain,
                "tenant.alpha",
                DisableTenant.CommandType,
                "tenantId",
                "tenant.alpha"),
            new(
                "add tenant user",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/users/user.alpha/add",
                new AddUserToTenant("tenant.alpha", "user.alpha", TenantRole.TenantReader),
                TenantIdentity.Domain,
                "tenant.alpha",
                AddUserToTenant.CommandType,
                "userId",
                "user.alpha"),
            new(
                "remove tenant user",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/users/user.alpha/remove",
                new RemoveUserFromTenant("tenant.alpha", "user.alpha"),
                TenantIdentity.Domain,
                "tenant.alpha",
                RemoveUserFromTenant.CommandType,
                "userId",
                "user.alpha"),
            new(
                "change tenant user role",
                HttpMethod.Patch,
                "/api/tenants/tenant.alpha/users/user.alpha/role",
                new ChangeUserRole("tenant.alpha", "user.alpha", TenantRole.TenantContributor),
                TenantIdentity.Domain,
                "tenant.alpha",
                ChangeUserRole.CommandType,
                "userId",
                "user.alpha"),
            new(
                "set tenant configuration",
                HttpMethod.Put,
                "/api/tenants/tenant.alpha/configuration/billing.plan",
                new SetTenantConfiguration("tenant.alpha", "billing.plan", "pro"),
                TenantIdentity.Domain,
                "tenant.alpha",
                SetTenantConfiguration.CommandType,
                "key",
                "billing.plan"),
            new(
                "remove tenant configuration",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/configuration/billing.plan/remove",
                new RemoveTenantConfiguration("tenant.alpha", "billing.plan"),
                TenantIdentity.Domain,
                "tenant.alpha",
                RemoveTenantConfiguration.CommandType,
                "key",
                "billing.plan"),
            new(
                "set global administrator",
                HttpMethod.Post,
                "/api/global-administrators/user.alpha/set",
                new SetGlobalAdministrator("user.alpha"),
                TenantIdentity.GlobalAdministratorsDomain,
                TenantIdentity.GlobalAdministratorsAggregateId,
                SetGlobalAdministrator.CommandType,
                "userId",
                "user.alpha"),
            new(
                "remove global administrator",
                HttpMethod.Post,
                "/api/global-administrators/user.alpha/remove",
                new RemoveGlobalAdministrator("user.alpha"),
                TenantIdentity.GlobalAdministratorsDomain,
                TenantIdentity.GlobalAdministratorsAggregateId,
                RemoveGlobalAdministrator.CommandType,
                "userId",
                "user.alpha"),
        ];

    private static CommandMismatchCase[] CommandMismatchCases()
        =>
        [
            new(
                "tenant id route mismatch",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/enable",
                new EnableTenant("tenant.beta")),
            new(
                "tenant-user tenant id route mismatch",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/users/user.alpha/add",
                new AddUserToTenant("tenant.beta", "user.alpha", TenantRole.TenantReader)),
            new(
                "tenant-user user id route mismatch",
                HttpMethod.Post,
                "/api/tenants/tenant.alpha/users/user.alpha/add",
                new AddUserToTenant("tenant.alpha", "user.beta", TenantRole.TenantReader)),
            new(
                "configuration tenant id route mismatch",
                HttpMethod.Put,
                "/api/tenants/tenant.alpha/configuration/billing.plan",
                new SetTenantConfiguration("tenant.beta", "billing.plan", "pro")),
            new(
                "configuration key route mismatch",
                HttpMethod.Put,
                "/api/tenants/tenant.alpha/configuration/billing.plan",
                new SetTenantConfiguration("tenant.alpha", "billing.mode", "pro")),
            new(
                "global administrator user id route mismatch",
                HttpMethod.Post,
                "/api/global-administrators/user.alpha/set",
                new SetGlobalAdministrator("user.beta")),
        ];

    private sealed class TenantsApiWebApplicationFactory(
        IEventStoreGatewayClient gateway,
        IReadOnlyDictionary<string, string?>? authenticationConfiguration = null,
        Action<IServiceCollection>? configureServices = null)
        : WebApplicationFactory<TenantsApi::Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            _ = builder.UseEnvironment("Development");
            _ = builder.ConfigureAppConfiguration((_, configuration) =>
            {
                configuration.Sources.Clear();
                configuration.AddInMemoryCollection(authenticationConfiguration is null
                    ? new Dictionary<string, string?>
                    {
                        ["EventStore:Authentication:Issuer"] = JwtIssuer,
                        ["EventStore:Authentication:Audience"] = JwtAudience,
                        ["EventStore:Authentication:SigningKey"] = JwtSigningKey,
                    }
                    : authenticationConfiguration);
            });
            _ = builder.ConfigureTestServices(services =>
            {
                services.RemoveAll<IEventStoreGatewayClient>();
                services.AddSingleton<IEventStoreGatewayClient>(gateway);
                configureServices?.Invoke(services);
            });
        }
    }

    private sealed class HandlerRoutedEventStoreGatewayClient : IEventStoreGatewayClient, IDisposable
    {
        private readonly EventStoreDomainDiagnostics _diagnostics = new("tenants");
        private readonly HandlerAwareQueryRouter _router;

        public HandlerRoutedEventStoreGatewayClient(
            GlobalAdministratorReadModel model,
            string? eTag,
            DateTimeOffset now)
        {
            var handler = new GetGlobalAdministratorsQueryHandler(
                new SingleGlobalAdministratorReadModelStore(model, eTag),
                new QueryCursorCodec(new EphemeralDataProtectionProvider(), "Hexalith.Tenants.Integration.QueryCursor.v1"),
                new TenantTelemetry(_diagnostics),
                NullLogger<GetGlobalAdministratorsQueryHandler>.Instance,
                Options.Create(new ReadModelFreshnessOptions
                {
                    Aging = TimeSpan.FromMinutes(5),
                    Stale = TimeSpan.FromMinutes(10),
                }),
                new FixedTimeProvider(now));
            _router = new HandlerAwareQueryRouter(
                new UnexpectedInnerQueryRouter(),
                new AlwaysSupportedDomainQueryHandlerRegistry(),
                new DirectDomainQueryInvoker(handler),
                NullLogger<HandlerAwareQueryRouter>.Instance);
        }

        public HandlerRoutedEventStoreGatewayClient(IDomainQueryHandler handler)
        {
            _router = new HandlerAwareQueryRouter(new UnexpectedInnerQueryRouter(),
                new AlwaysSupportedDomainQueryHandlerRegistry(), new DirectDomainQueryInvoker(handler),
                NullLogger<HandlerAwareQueryRouter>.Instance);
        }

        public async Task<EventStoreQueryResult> SubmitQueryAsync(
            SubmitQueryRequest request,
            string? ifNoneMatch = null,
            CancellationToken cancellationToken = default)
        {
            const string correlationId = "real-handler-correlation";
            byte[] payload = request.Payload is JsonElement element
                ? JsonSerializer.SerializeToUtf8Bytes(element, JsonOptions)
                : [];
            QueryRouterResult routed = await _router.RouteQueryAsync(
                new SubmitQuery(
                    request.Tenant,
                    request.Domain,
                    request.AggregateId,
                    request.QueryType,
                    payload,
                    correlationId,
                    "admin.current",
                    request.EntityId,
                    request.ProjectionType,
                    request.ProjectionActorType,
                    IsGlobalAdmin: true),
                cancellationToken);

            routed.Success.ShouldBeTrue(routed.ErrorMessage);
            JsonElement routedPayload = routed.Payload.ShouldNotBeNull();
            IMediator mediator = Substitute.For<IMediator>();
            _ = mediator.Send(Arg.Any<SubmitQuery>(), Arg.Any<CancellationToken>())
                .Returns(new SubmitQueryResult(
                    correlationId,
                    routedPayload,
                    routed.ProjectionType,
                    routed.Metadata));
            IETagService eTagService = Substitute.For<IETagService>();
            _ = eTagService.GetCurrentETagAsync(
                    Arg.Any<string>(),
                    request.Tenant,
                    Arg.Any<CancellationToken>())
                .Returns("later-projection-validator");
            ITenantValidator tenantValidator = Substitute.For<ITenantValidator>();
            _ = tenantValidator.ValidateAsync(
                    Arg.Any<ClaimsPrincipal>(),
                    request.Tenant,
                    Arg.Any<CancellationToken>(),
                    request.AggregateId)
                .Returns(TenantValidationResult.Allowed);
            IRbacValidator rbacValidator = Substitute.For<IRbacValidator>();
            _ = rbacValidator.ValidateAsync(
                    Arg.Any<ClaimsPrincipal>(),
                    Arg.Any<string>(),
                    Arg.Any<string>(),
                    Arg.Any<string>(),
                    Arg.Any<string>(),
                    Arg.Any<CancellationToken>(),
                    Arg.Any<string?>())
                .Returns(RbacValidationResult.Allowed);
            var controller = new QueriesController(
                mediator,
                eTagService,
                tenantValidator,
                rbacValidator,
                NullLogger<QueriesController>.Instance)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext
                    {
                        User = new ClaimsPrincipal(new ClaimsIdentity(
                            [new Claim("sub", "admin.current"), new Claim("role", "global-administrator")],
                            "test")),
                    },
                },
            };
            controller.HttpContext.Items["CorrelationId"] = correlationId;

            IActionResult action = await controller.Submit(request, ifNoneMatch, cancellationToken);
            OkObjectResult ok = action.ShouldBeOfType<OkObjectResult>();
            SubmitQueryResponse body = ok.Value.ShouldBeOfType<SubmitQueryResponse>();
            string? responseETag = controller.Response.Headers.ETag.Count == 0
                ? null
                : controller.Response.Headers.ETag.ToString().Trim('"');
            return new EventStoreQueryResult(
                body.CorrelationId,
                body.Payload,
                IsNotModified: false,
                responseETag)
            {
                Metadata = body.Metadata,
            };
        }

        public Task<EventStoreQueryResult<T>> SubmitQueryAsync<T>(
            SubmitQueryRequest request,
            string? ifNoneMatch = null,
            CancellationToken cancellationToken = default)
            => throw new NotSupportedException();

        public Task<SubmitCommandResponse> SubmitCommandAsync(
            SubmitCommandRequest request,
            CancellationToken cancellationToken = default)
            => throw new NotSupportedException();

        public Task<StreamReadPage> ReadStreamAsync(
            StreamReadRequest request,
            CancellationToken cancellationToken = default)
            => throw new NotSupportedException();

        public void Dispose() => _diagnostics.Dispose();
    }

    private sealed class SingleGlobalAdministratorReadModelStore(
        GlobalAdministratorReadModel model,
        string? eTag) : IReadModelStore
    {
        public Task<ReadModelEntry<TValue>> GetAsync<TValue>(
            string storeName,
            string key,
            CancellationToken cancellationToken = default)
            where TValue : class
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (typeof(TValue) != typeof(GlobalAdministratorReadModel))
            {
                throw new InvalidOperationException($"Unexpected read model type {typeof(TValue).Name}.");
            }

            return Task.FromResult(new ReadModelEntry<TValue>((TValue)(object)model, eTag));
        }

        public Task SaveAsync<TValue>(
            string storeName,
            string key,
            TValue value,
            CancellationToken cancellationToken = default)
            where TValue : class
            => throw new NotSupportedException();

        public Task<bool> TrySaveAsync<TValue>(
            string storeName,
            string key,
            TValue value,
            string eTag,
            CancellationToken cancellationToken = default)
            where TValue : class
            => throw new NotSupportedException();
    }

    private sealed class AlwaysSupportedDomainQueryHandlerRegistry : IDomainQueryHandlerRegistry
    {
        public Task<bool> SupportsQueryAsync(
            string domain,
            string queryType,
            CancellationToken cancellationToken = default)
            => Task.FromResult(true);
    }

    private sealed class DirectDomainQueryInvoker(IDomainQueryHandler handler) : IDomainQueryInvoker
    {
        public Task<QueryResult> InvokeAsync(QueryEnvelope query, CancellationToken cancellationToken = default)
            => handler.ExecuteAsync(query, cancellationToken);
    }

    private sealed class UnexpectedInnerQueryRouter : IQueryRouter
    {
        public Task<QueryRouterResult> RouteQueryAsync(
            SubmitQuery query,
            CancellationToken cancellationToken = default)
            => throw new InvalidOperationException("The handler-aware route unexpectedly delegated to the projection actor router.");
    }

    private sealed class FixedTimeProvider(DateTimeOffset now) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => now;
    }

    private sealed class FixedUserContextAccessor(string userId) : IUserContextAccessor
    {
        public string? TenantId => TenantIdentity.DefaultTenantId;

        public string? UserId => userId;
    }

    private sealed class CapturingEventStoreGatewayClient : IEventStoreGatewayClient
    {
        private readonly Queue<object> _responses = new();

        public List<SubmittedCommand> SubmittedCommands { get; } = [];

        public List<SubmittedQuery> SubmittedQueries { get; } = [];

        public bool BlockCommandsUntilCancellation { get; init; }

        public bool BlockQueriesUntilCancellation { get; init; }

        public TaskCompletionSource<CancellationToken> CommandStarted { get; }
            = new(TaskCreationOptions.RunContinuationsAsynchronously);

        public TaskCompletionSource<CancellationToken> QueryStarted { get; }
            = new(TaskCreationOptions.RunContinuationsAsynchronously);

        public async Task<SubmitCommandResponse> SubmitCommandAsync(
            SubmitCommandRequest request,
            CancellationToken cancellationToken = default)
        {
            SubmittedCommands.Add(new SubmittedCommand(request, cancellationToken));
            if (BlockCommandsUntilCancellation)
            {
                _ = CommandStarted.TrySetResult(cancellationToken);
                await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
                throw new InvalidOperationException("The blocked command completed without cancellation.");
            }

            object next = _responses.Dequeue();
            if (next is Exception exception)
            {
                throw exception;
            }

            return (SubmitCommandResponse)next;
        }

        public async Task<EventStoreQueryResult> SubmitQueryAsync(
            SubmitQueryRequest request,
            string? ifNoneMatch = null,
            CancellationToken cancellationToken = default)
        {
            SubmittedQueries.Add(new SubmittedQuery(request, ifNoneMatch, cancellationToken));
            if (BlockQueriesUntilCancellation)
            {
                _ = QueryStarted.TrySetResult(cancellationToken);
                await Task.Delay(Timeout.InfiniteTimeSpan, cancellationToken);
                throw new InvalidOperationException("The blocked query completed without cancellation.");
            }

            object next = _responses.Dequeue();
            if (next is Exception exception)
            {
                throw exception;
            }

            return (EventStoreQueryResult)next;
        }

        public Task<EventStoreQueryResult<T>> SubmitQueryAsync<T>(
            SubmitQueryRequest request,
            string? ifNoneMatch = null,
            CancellationToken cancellationToken = default)
            => throw new NotSupportedException();

        public Task<StreamReadPage> ReadStreamAsync(StreamReadRequest request, CancellationToken cancellationToken = default)
            => throw new NotSupportedException();

        public void EnqueueCommandResult(string correlationId)
            => _responses.Enqueue(new SubmitCommandResponse(correlationId));

        public void EnqueueCommandFailure(Exception exception)
            => _responses.Enqueue(exception);

        public void EnqueueQueryResult<T>(
            T payload,
            string? eTag = "etag",
            QueryResponseMetadata? metadata = null)
            => _responses.Enqueue(new EventStoreQueryResult(
                "correlation",
                JsonSerializer.SerializeToElement(payload, JsonOptions),
                IsNotModified: false,
                eTag)
            {
                Metadata = metadata ?? new QueryResponseMetadata(ETag: eTag, IsStale: false),
            });

        public void EnqueueNotModified(string? eTag, QueryResponseMetadata? metadata = null)
            => _responses.Enqueue(new EventStoreQueryResult(null, null, IsNotModified: true, eTag)
            {
                Metadata = metadata ?? new QueryResponseMetadata(ETag: eTag, IsNotModified: true),
            });

        public void EnqueueQueryFailure(Exception exception)
            => _responses.Enqueue(exception);
    }

    private sealed record SubmittedQuery(SubmitQueryRequest Request, string? IfNoneMatch, CancellationToken CancellationToken);

    private sealed record SubmittedCommand(SubmitCommandRequest Request, CancellationToken CancellationToken);

    private sealed record CommandRouteCase(
        string Name,
        HttpMethod Method,
        string Route,
        object Body,
        string ExpectedDomain,
        string ExpectedAggregateId,
        string ExpectedCommandType,
        string IdentityPropertyName,
        string ExpectedIdentityValue);

    private sealed record CommandMismatchCase(
        string Name,
        HttpMethod Method,
        string Route,
        object Body);
}
