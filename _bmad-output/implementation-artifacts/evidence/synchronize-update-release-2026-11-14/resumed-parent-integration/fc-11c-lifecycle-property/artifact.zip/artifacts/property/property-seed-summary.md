## Lifecycle Property Run

- FsCheck package: FsCheck.Xunit.v3 3.3.1
- MaxTest: 10000
- MaxSize: 96
- Replay seed: 17119656915235211680,8590200883085196229,0
- Filter: --filter-trait Category=NightlyProperty
- Results: TestResults/property-nightly
- Generated operation distribution: uniform token modulo 10 across submit, acknowledge, syncing, confirmed, rejected, duplicate terminal, reconnect observation, retry observation, stale observation, and reset/idling
- Shrink result: none for a passing run; failing runs must retain FsCheck shrink output and fixture conversion evidence
- Replay command: pwsh ./eng/run-lifecycle-property-suite.ps1 -MaxTest 10000 -Replay "17119656915235211680,8590200883085196229,0" -ResultsDirectory "TestResults/property-nightly"
