## Property Evidence

- FsCheck package: FsCheck.Xunit.v3 3.3.1
- CI suite: 1000 generated command sequences, deterministic replay seed configured on property attributes
- Nightly suite: 10000 generated command sequences using FC_PROPERTY_MAX_TEST=10000; replay seed is generated when -Replay is omitted
- Fixture path: tests/Hexalith.FrontComposer.Shell.Tests/Infrastructure/Lifecycle/Fixtures/command-idempotency-counterexamples.json
- Redaction scan: clean
- Submodules: no recursive nested submodule command is used

## Lifecycle Property Run

- FsCheck package: FsCheck.Xunit.v3 3.3.1
- MaxTest: 10000
- MaxSize: 96
- Replay seed: 17119656915235211680,8590200883085196229,0
- Filter: --filter-trait Category=NightlyProperty
- Results: TestResults/property-nightly
- Generated operation distribution: uniform token modulo 10 across submit, acknowledge, syncing, confirmed, rejected, duplicate terminal, reconnect observation, retry observation, stale observation, and reset/idling
- Shrink result: none for a passing run; failing runs must retain FsCheck shrink output and fixture conversion evidence
- Replay command: pwsh ./eng/run-lifecycle-property-suite.ps1 -MaxTest 10000 -Replay "17119656915235211680,8590200883085196229,0" -ResultsDirectory "TestResults/property-nightly"

