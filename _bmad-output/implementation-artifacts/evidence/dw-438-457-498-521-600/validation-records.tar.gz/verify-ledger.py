from pathlib import Path
import collections, hashlib, json, re, subprocess
selected={438,457,498,521,600}
original=Path(__file__).with_name("ledger-before.md").read_bytes()
current=Path("_bmad-output/implementation-artifacts/deferred-work.md").read_bytes()
def records(data):
    matches=list(re.finditer(rb"^### DW-(\d+):",data,re.M))
    return {int(m.group(1)): data[m.start():(matches[i+1].start() if i+1<len(matches) else len(data))] for i,m in enumerate(matches)}
a,b=records(original),records(current)
assert set(a)==set(b), "Numbered identity drift"
assert len(a)==657
for key in sorted(set(a)-selected):
    assert a[key]==b[key], f"Unselected DW-{key} body changed"
counts=collections.Counter()
for key,body in b.items():
    match=re.search(rb"^status: (\w+)",body,re.M)
    assert match, key
    counts[match.group(1).decode()]+=1
for key in selected:
    if a[key]!=b[key]:
        for line in a[key].splitlines():
            if line.startswith((b"status:",b"disposition:",b"next-action:")) or not line.strip(): continue
            assert line in b[key].splitlines(), f"Original selected field lost: DW-{key}: {line!r}"
result={"numberedIds":len(a),"selected":[f"DW-{key}" for key in sorted(selected)],"changedNumberedRecords":[key for key in a if a[key]!=b[key]],"unchangedUnselectedNumberedRecords":len(set(a)-selected),"statusCounts":dict(counts),"originalSelectedFieldsPreserved":True,"baselineLedgerSha256":hashlib.sha256(original).hexdigest()}
print(json.dumps(result,indent=2))
