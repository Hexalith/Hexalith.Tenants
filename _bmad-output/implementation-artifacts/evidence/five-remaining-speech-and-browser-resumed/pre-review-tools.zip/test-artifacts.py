"""Integrity tamper controls run only in isolated disposable evidence copies."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def refresh(directory):
    path = directory / "artifact-manifest.json"
    manifest = json.loads(path.read_bytes())
    manifest["files"] = [{"path": item.relative_to(directory).as_posix(), "bytes": item.stat().st_size,
                          "sha256": hashlib.sha256(item.read_bytes()).hexdigest()}
                         for item in sorted(directory.rglob("*")) if item.is_file() and item != path]
    write(path, manifest)


def edit_json(directory, name, mutate):
    path = directory / name
    value = json.loads(path.read_bytes())
    mutate(value)
    write(path, value)


def bind_browser(directory, name):
    fingerprint = hashlib.sha256((directory / name).read_bytes()).hexdigest()
    edit_json(directory, "browser-invocations.json", lambda data: [row.update(packetSha256=fingerprint)
              for row in data["invocations"] if row["packet"] == name])


def main():
    results = []
    cases = ["positive", "unbound bytes", "matrix coverage", "native observer binding", "grid gate", "grant negative control", "speech receipt boundary"]
    for case in cases:
        with tempfile.TemporaryDirectory(prefix="tenants-resumed-artifact-control-") as temporary:
            base = Path(temporary)
            directory = base / HERE.name
            shutil.copytree(HERE, directory)
            # Copy only the immutable helper links needed by this check.
            source = json.loads((directory / "executed-source-manifest.json").read_bytes())
            for item in source["source"]:
                for version in [item] + item.get("previousVersions", []):
                    relative = version["immutableSnapshot"]
                    destination = directory / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(HERE / relative, destination)
            if case == "unbound bytes":
                path = directory / "grant-current-controls.json"
                path.write_bytes(path.read_bytes() + b" ")
            elif case == "matrix coverage":
                edit_json(directory, "native-matrix.json", lambda data: data["windows"][0].update(trial="S9-en"))
            elif case == "native observer binding":
                edit_json(directory, "native-attempt-index.json", lambda data: data["attempts"][0].update(observerSha256="0" * 64))
            elif case == "grid gate":
                edit_json(directory, "grid-external-failure.json", lambda data: data["failure"].update(label="waived"))
                bind_browser(directory, "grid-external-failure.json")
            elif case == "grant negative control":
                edit_json(directory, "grant-current-controls.json", lambda data: next(row for row in data["cases"]
                    if row["scenario"] == "grant-escape-held-subscription").update(completionRejectedWhileHeld=False))
                bind_browser(directory, "grant-current-controls.json")
            elif case == "speech receipt boundary":
                edit_json(directory, "speech-inspection.json", lambda data: data["windows"][0]["sampleArrivalSegments"].update(
                    matchedStateBeforeCollectorReceipt=999))
            if case not in {"positive", "unbound bytes"}:
                refresh(directory)
            run = subprocess.run([sys.executable, "-B", "-O", str(directory / "validate-artifacts.py")], capture_output=True, text=True)
            if case == "positive":
                require(run.returncode == 0, run.stderr)
            else:
                require(run.returncode != 0 and "ValueError:" in run.stderr, "Tamper accepted: " + case)
            results.append({"case": case, "exitCode": run.returncode,
                            "diagnostic": run.stderr.splitlines()[-1] if run.stderr else "accepted"})
    print(json.dumps({"isolatedTemporaryCopiesOnly": True, "optimizedPython": True, "controls": results}, indent=2))


if __name__ == "__main__":
    main()
