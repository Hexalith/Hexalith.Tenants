"""Build the exact current-profile matrix without claiming AT acceptance.

Text occurrences describe queued output only. They include all focus/live output
and neither identify announcement causality nor establish audible completion.
"""
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import zipfile


HERE = Path(__file__).resolve().parent
TRIALS = ["S0", "S1", "S2", "S3", "C1-lifecycle", "C1-availability", "C2-lifecycle", "C2-availability",
          "C3-events-lifecycle", "C3-events-availability", "C3-unavailable-lifecycle", "C3-unavailable-availability"]
TEXT = {
    "en": {
        "searchUnavailable": "Protected whole-set search is temporarily unavailable. You can continue browsing the authorized tenant list.",
        "searchRefreshed": "Protected search paging could not be restored. Search has restarted from the first page.",
        "listRefreshed": "The requested page was no longer available. The authorized first page has been refreshed.",
        "pendingLabel": "Audit pending",
        "pendingReason": "The command's events are stored, but its audit record is not readable yet. It normally appears shortly, and no proof is claimed until it does.",
        "unavailableLabel": "Audit unavailable",
        "unavailableReason": "The audit status could not be read or verified after the command was sent. This does not mean the record does not exist, and no proof is claimed.",
    },
    "fr": {
        "searchUnavailable": "La recherche protégée sur l'ensemble des locataires est temporairement indisponible. Vous pouvez continuer à parcourir la liste autorisée.",
        "searchRefreshed": "La pagination de recherche protégée n'a pas pu être restaurée. La recherche a redémarré depuis la première page.",
        "listRefreshed": "La page demandée n'était plus disponible. La première page autorisée a été actualisée.",
        "pendingLabel": "Audit en attente",
        "pendingReason": "Les événements de la commande sont enregistrés, mais son enregistrement d’audit n’est pas encore lisible. Il apparaît normalement sous peu, et aucune preuve n’est revendiquée d’ici là.",
        "unavailableLabel": "Audit indisponible",
        "unavailableReason": "Le statut d’audit n’a pas pu être lu ni vérifié après l’envoi de la commande. Cela ne signifie pas que l’enregistrement n’existe pas, et aucune preuve n’est revendiquée.",
    },
}


def normalize(value):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", value).replace("’", "'")).strip().casefold()


def utc(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def build():
    refresh = json.loads((HERE / "native-refresh.json").read_bytes())
    root_revision = next(row for row in refresh["repositories"] if row["path"] == ".")["after"]["revision"]
    rows = {(pairing, trial + "-" + culture): {"pairing": pairing, "culture": culture, "trial": trial + "-" + culture,
             "sourceRootRevision": root_revision, "protocolComplete": False, "independentlyAssessed": False,
             "acceptedForClosure": False, "status": "not captured in a completed current-profile window"}
            for pairing in ("NVDA/Chrome", "NVDA/Firefox") for culture in ("en", "fr") for trial in TRIALS}
    inspections = []
    index = json.loads((HERE / "native-attempt-index.json").read_bytes())
    for attempt in index["attempts"]:
        if attempt["sourceRootRevision"] != root_revision:
            continue
        with zipfile.ZipFile(HERE / attempt["packet"]) as archive:
            fixture = json.loads(archive.read("fixture.json"))
            timeline = json.loads(archive.read("timeline.json"))
            speech = json.loads(archive.read("speech.json"))
            capture = json.loads(archive.read("capture.json"))
        for completed in fixture.get("nativeSpeechTrials", []):
            trial = completed["trial"]
            row = rows[(attempt["pairing"], trial)]
            trigger = next(item for item in timeline if item.get("kind") == "trigger" and item.get("trial") == trial)
            event = next(item for item in timeline if item.get("kind") == "observe" and item.get("trial") == trial)
            trigger_time = utc(trigger["utc"])
            state_time = utc(event["stateUtc"])
            receipt_time = utc(completed["observation"]["startedUtc"])
            end_time = utc(completed["observation"]["endedUtc"])
            duration = utc(completed["observation"]["endedUtc"]) - utc(event["stateUtc"])
            valid = (duration >= timedelta(seconds=30) and completed["observation"]["queuedQuietSeconds"] >= 5
                     and completed["control"]["verified"] and completed["interruption"]["verified"]
                     and capture["sourceSettingsUnchanged"] and fixture["sourceStableThroughCleanup"])
            if trial.startswith("C"):
                state = event["fixture"]
                expected_status = "events" if trial.startswith("C1-") or trial.startswith("C3-events-") else "unavailable"
                valid = valid and state["simulatedCommands"] == 1 and state["unexpectedCommands"] == 0 \
                    and state["projection"] == "hold" and state["status"] == expected_status
            samples = [sample for sample in speech if sample["trial"] == trial]
            queued = " ".join(sample["text"] for sample in samples)
            pre_trigger = [sample for sample in samples if utc(sample["utc"]) < trigger_time]
            post_trigger = [sample for sample in samples if trigger_time <= utc(sample["utc"]) <= end_time]
            post_trigger_text = " ".join(sample["text"] for sample in post_trigger)
            pre_trigger_text = " ".join(sample["text"] for sample in pre_trigger)
            occurrences = {name: normalize(post_trigger_text).count(normalize(text)) for name, text in TEXT[row["culture"]].items()}
            row.update(protocolComplete=bool(valid), status="complete controls; independent speech assessment pending" if valid
                       else "recorded completion does not satisfy replayed window/control gates", packet=attempt["packet"],
                       triggerUtc=trigger["utc"], matchingStateUtc=event["stateUtc"],
                       collectorReceiptStartedUtc=completed["observation"]["startedUtc"],
                       observationEndedUtc=completed["observation"]["endedUtc"],
                       stateToEndMilliseconds=duration.total_seconds() * 1000, speechSamples=len(samples),
                       positiveControlVerified=completed["control"]["verified"],
                       cancellationResponseVerified=completed["interruption"]["verified"])
            inspections.append({"pairing": attempt["pairing"], "culture": row["culture"], "trial": trial,
                "packet": attempt["packet"], "speechMember": "speech.json", "timelineMember": "timeline.json",
                "queuedTextSha256": hashlib.sha256(queued.encode()).hexdigest(),
                "triggerUtc": trigger["utc"], "matchingStateUtc": event["stateUtc"],
                "collectorReceiptStartedUtc": completed["observation"]["startedUtc"],
                "observationEndedUtc": completed["observation"]["endedUtc"],
                "postTriggerQueuedTextOccurrences": occurrences,
                "preTriggerQueuedTextOccurrences": {name: normalize(pre_trigger_text).count(normalize(text))
                    for name, text in TEXT[row["culture"]].items()},
                "sampleArrivalSegments": {"preTrigger": len(pre_trigger),
                    "triggerBeforeMatchedState": sum(trigger_time <= utc(sample["utc"]) < state_time for sample in samples),
                    "matchedStateBeforeCollectorReceipt": sum(state_time <= utc(sample["utc"]) < receipt_time for sample in samples),
                    "collectorReceiptThroughEnd": sum(receipt_time <= utc(sample["utc"]) <= end_time for sample in samples),
                    "afterEnd": sum(utc(sample["utc"]) > end_time for sample in samples)},
                "productWindowCancellationNotifications": sum(item.get("kind") == "nvda-speech-canceled"
                    and item.get("trial") == trial for item in timeline),
                "focusAtMatchingState": event["focus"], "fixtureAtMatchingState": event["fixture"],
                "interpretation": "Provisional literal occurrence inventory, including focus and live output; no announcement-cause attribution, no audible-completion claim and no independent acceptance."})
    matrix = {"profile": "frozen c2da profile at refreshed run start", "sourceRootRevision": root_revision,
              "sourceInventory": "native-refresh.json", "requiredWindows": 48,
              "completedWindowControls": sum(row["protocolComplete"] for row in rows.values()),
              "independentlyAcceptedWindows": 0, "windows": list(rows.values()),
              "earlierSourceAttemptsCountTowardThisMatrix": False}
    inspection = {"method": "See build-native-matrix.py; complete raw queues and state/focus timelines remain in hash-bound ZIP members. Literal counts are not independent AT assessment.", "windows": inspections}
    return matrix, inspection


def main():
    matrix, inspection = build()
    (HERE / "native-matrix.json").write_text(json.dumps(matrix, indent=2) + "\n")
    (HERE / "speech-inspection.json").write_text(json.dumps(inspection, indent=2) + "\n")
    print(json.dumps({"completedCurrentProfileWindows": matrix["completedWindowControls"], "requiredWindows": 48,
                      "independentlyAccepted": 0}, indent=2))


if __name__ == "__main__":
    main()
