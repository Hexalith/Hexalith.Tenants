# Five deferred UI safety items — implementation verification

Approved baseline: `14133e96d2c5efb13270580f920133079707398b`. This packet verifies the implementation for DW-194, DW-201, DW-221, DW-267 and DW-609 against the [approved frozen matrix](spec-dw-194-201-221-267-609-ui-safety.md). Independent review, exact ledger/index conservation, commit validation and main integration remain separate workflow steps.

## Implemented behavior

- Removal uses the complete existing ten-fact preview inside Fluent's native modal, with the shared FrontComposer label/focus containment helpers. Browser document focus is asserted during native Tab/Shift+Tab. Moving focus to the lifecycle region before a control becomes disabled prevents pending Escape from bypassing Fluent's host guard. A held focus await cannot admit dismissed, replaced, revoked or disposed work. No new modal framework or shared-library edit is introduced.
- Create requires a measured safe viewport and preserves intent/tracked work during resize. A matching conflict offers open-existing only after a bounded authorized detail read, and rechecks before navigation. Detail Back preserves sort/context, expands the create region and focuses its visible lifecycle anchor. Restoration checks its exact route, view, caller, authority, snapshot and operation after module import; obsolete imports cannot focus or consume return markers.
- Optional `CollectionShapes` distinguishes declared array intent from scalar intent and rejects malformed/contradictory metadata. Metadata key names follow case-insensitive configuration semantics; `array` and policy data remain exact. Shipped appsettings deliberately stays in legacy mode, preserving layered deployments. [Deployment documentation](../../docs/tenant-configuration-read-policy.md) explains opt-in, reload and flattened-provider ambiguity.
- Command activity callbacks serialize per exact attempt/generation, metadata refresh uses the existing drain, and safe-resource lookup preserves each flow's fallback. Lease admission recognizes only its exact current owner. Held old callbacks cannot block or detach route replacements.
- Retained snapshots and in-flight reads bind to observed authorization revision as well as subject/tenant. Ready/degraded workspace rows and both membership panels clear facts/validators on real authentication events and requery after current authority resolves; retired reads cannot repopulate them. Internal unchanged-authority resolution retains ordinary soft-refresh/ETag behavior. Existing current-policy configuration reauthorization remains in force.

## Final gates

| Gate | Result | Raw member in archive |
| --- | --- | --- |
| Debug/source UI test build | 0 warnings, 0 errors | `final/build.log` |
| Maintained UI project | **7,684 passed; 0 failed; 0 skipped**, 1m43.632s | `final/ui-tests.log` |
| Workspace consumers, including nine mounted authority and four held return cases | 163/163 | `final/workspace-consumers-tests.log` |
| My tenants / user lookup surfaces | 31/31 and 40/40 | `final/my-memberships-tests.log`, `final/user-memberships-tests.log` |
| Standalone audit authority boundary | 8/8 | `final/audit-authority-boundary-tests.log` |
| Static validator startup/hung-browser failure controls | 2/2, unchanged bounds | `final/static-validator-controls-tests.log` |
| Authenticated production UI browser | **12/12**, fresh build, stable source, closure eligible | `final/browser.json`, `final/browser.log` |
| Story gitlinks / whitespace | exit 0 / exit 0 | `final/gitlinks.log`, `final/diff-check.log` |

Verbose raw JSON/logs remain intact in [raw-validation.zip](evidence/dw-194-201-221-267-609/raw-validation.zip); the small [manifest](evidence/dw-194-201-221-267-609/manifest.json) records hashes, counts, source/binary identity and evidence limits. Exact commands are `final/commands.json`. Earlier focused passes are under `supporting/`; final maintained-suite execution covers those tests on the final source.

## Frozen matrix coverage

Every test below executes in `final/ui-tests.log`. Applicable native browser cases are named exactly as recorded in `final/browser.json`.

| Frozen row | Passing test/browser evidence |
| --- | --- |
| Removal preview; Tab, Shift+Tab, Escape; pending safeguards | Browser `member-native-modal-keyboard` and `member-pending-native-dismissal`; `RemoveTenantMemberFlowTests.Held_delivery_on_narrow_viewport_retains_a_tab_stop_and_guarded_escape`; `Held_pre_submit_focus_cannot_admit_obsolete_or_dismissed_work` (authority, replacement, dismissal, disposal). Native `:modal`, document focus, inert background, exact focus return, overlay, held delivery and unsafe-width recovery remain asserted. |
| Create; unknown/unsafe measured width | `CreateTenantFlowTests.Unknown_or_unsafe_viewport_blocks_create_and_resize_preserves_tracked_work`; `TenantsWorkspaceTests.Workspace_names_the_first_tenant_bootstrap_exception_when_create_stays_available`; browser `create-measured-conflict-recovery`. |
| Create conflict; readable versus unverifiable target | `CreateTenantFlowTests.Conflict_navigation_requires_fresh_read_authority_and_rechecks_before_opening`; `TenantsWorkspaceTests.Held_create_return_import_keeps_exact_view_authority_and_lifetime_ownership` (unchanged, view, authority, disposal); browser `create-measured-conflict-recovery`, including `backRestoresVisibleCreateLifecycle=true`. |
| Explicit array/scalar policy; malformed/reload/legacy compatibility | `TenantConfigurationReadPolicyTests.Explicit_collection_intent_distinguishes_empty_array_from_scalar_declaration`; `Malformed_or_incomplete_collection_shape_metadata_fails_closed`; `Explicit_shape_reload_rejects_scalar_element_conflicts_and_recovers_after_correction`; `Configuration_metadata_keys_are_case_insensitive_while_policy_data_remains_literal`; retained `An_emptied_environment_override_cannot_clear_a_declared_display_safe_list`. |
| Held/repeated refresh or activity callback | `TenantCommandActivityCoordinatorTests.Repeated_held_activity_joins_one_parent_admission_and_releases_once`; `Late_activity_result_cannot_release_replacement_attempt`; `EditTenantMetadataFlowTests.Repeated_refresh_while_status_is_held_drains_one_followup_for_the_original_attempt`; retained `TenantRetainedCommandFlowTests.FaultedOldActivityAcquisitionCannotDetachTheNewRouteAttempt`; `TenantAggregateCommandAdmissionGateTests.Lease_admission_reports_only_its_exact_current_owner_after_replacement`; `TenantCommandFlowGuardTests.Safe_message_lookup_preserves_per_flow_fallback_without_exposing_resource_identifiers`. |
| Same subject/tenant; permission change during read/retention | `TenantQueryGatewayTests.Same_subject_permission_revision_discards_retained_rows_and_validators_then_recovers` (28 combinations), `Same_subject_unnotified_permission_change_withholds_inflight_completion` (14), and disposed-scope regression; `TenantsWorkspaceTests.Mounted_read_consumers_drop_old_authority_facts_before_requery_and_retire_held_reads` (list/my/user × ready/degraded/in-flight); all eight `AuditReadAuthorityBoundaryTests`; retained BFF `Reauthorize_drops_scope_when_the_grant_was_revoked_since_the_page_rendered` and gateway `Get_tenant_retained_reauthorization_failure_makes_configuration_unavailable`. |

## Bounded qualification and preserved diagnostics

The full browser invocation explicitly unsets `TENANTS_BROWSER_UI_SAFETY_ONLY` and `TENANTS_BROWSER_SKIP_BUILD`. All nine retained administrator cases plus three selected safety cases run. Selected-only diagnostics are ineligible for closure. The final packet records 37 authorized fixture reads, 15 administrator reads, two fixture-local command simulations, zero unexpected command attempts and zero circuit errors.

The test-only loopback OIDC issuer exercises production signed-token validation, authentication and Razor components. Deterministic HTTP/SignalR responses qualify UI behavior; they do not qualify backend authorization, stored domain state or command delivery. No command is forwarded. The pre-existing AppHost start failure remains: duplicate `eventstore-app-api-token` registration at Program.cs:79, AppHost exit 134 / CLI exit 2; exact baseline command/log are recorded in the approved spec. No distributed deployment or Release qualification is claimed.

`diagnostics/` retains superseded full-suite failures, the initial browser focus failure, selected-only evidence and the earlier full browser packet. A historical closure bit in a superseded packet does not qualify final source. Corrections include exact-attempt callback gates, the demonstrated focus-before-disable fix, awaited async Cancel completion, polling non-render timer retirement, and boundary assertions requiring rows/links to disappear during pending authority. Six pre-existing fixed-format `ToString` absence assertions were removed while preserving actual row/paging assertions; the support-safety gate remains enabled and passes.

The static validator still exports every real fixture and retains its mutations/checks. Its 12,690-byte export/derived-asset block is byte-identical to baseline (SHA-256 `3469d4ee148fa5a78607b0f0f559bd022dcacf57129b683fb42e9ce1c62c60e2`), moved after initial server readiness and the first browser result so failure-control bounds exclude unrelated export startup. `final/static-export-conservation.json` records the comparison.

Legacy configuration ambiguity remains an intentional compatibility limit until deployment opt-in. No implementation ledger/index, accepted-limitation record, event history or dependency gitlink was changed by this implementation handoff.
