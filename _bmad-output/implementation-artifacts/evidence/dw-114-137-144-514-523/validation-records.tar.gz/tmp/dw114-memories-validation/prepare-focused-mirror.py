from pathlib import Path
import subprocess, tarfile, shutil, hashlib, json
owner=Path('/home/administrator/projects/hexalith/tenants/references/Hexalith.Memories')
root=Path('/tmp/dw114-memories-validation/mirror')
root.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','ls-files','-z'],cwd=owner).decode().split('\0')
selected=[p for p in paths if p and (p.startswith(('src/','tests/','samples/')) or '/' not in p)]
archive=root.parent/'source.tar'
with archive.open('wb') as f: subprocess.run(['git','archive','--format=tar','HEAD',*selected],cwd=owner,stdout=f,check=True)
with tarfile.open(archive) as t:t.extractall(root,filter='data')
manifest={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=owner).decode().strip(),'overlaid':{}}
for p in ['src/Hexalith.Memories.Contracts/V1/SearchResult.cs','tests/Hexalith.Memories.IntegrationTests/Search/SyntacticSearchIntegrationTests.cs']:
 data=(owner/p).read_bytes();(root/p).write_bytes(data);manifest['overlaid'][p]=hashlib.sha256(data).hexdigest()
refs=root/'references';refs.mkdir(exist_ok=True)
for sibling in ['Hexalith.Builds','Hexalith.EventStore','Hexalith.FrontComposer','Hexalith.Commons','Hexalith.AI.Tools','Hexalith.McpCli','Hexalith.Platform']:
 link=refs/sibling
 if not link.exists():link.symlink_to(owner.parent/sibling,target_is_directory=True)
source=root/'src/Hexalith.Memories.Server/Activities/Tenants/ProvisionRediSearchActivity.cs'
data=source.read_bytes();source.write_bytes(data.replace(b'Ingestion.TenantIngestionOwnership',b'global::Hexalith.Memories.Server.Ingestion.TenantIngestionOwnership'))
manifest['baseline_only_compile_repair']='Fully qualify TenantIngestionOwnership in disposable ProvisionRediSearchActivity copy; original tracked source unchanged.'
(root.parent/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root.parent/'focus.targets').write_text('''<Project>
 <Target Name="SelectDW114SearchLane" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectName)' == 'Hexalith.Memories.IntegrationTests'">
  <ItemGroup>
   <Compile Remove="@(Compile)" />
   <Compile Include="Search/SyntacticSearchIntegrationTests.cs;Fixtures/RedisStackFixture.cs;Factories/IndexInputFactory.cs;$(IntermediateOutputPath)$(MSBuildProjectName).GlobalUsings.g.cs" />
  </ItemGroup>
 </Target>
</Project>''')
print(root)
