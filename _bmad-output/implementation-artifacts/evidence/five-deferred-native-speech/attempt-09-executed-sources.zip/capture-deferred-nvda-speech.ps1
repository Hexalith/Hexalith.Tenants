<#
.SYNOPSIS
Opt-in native Windows/NVDA Speech Viewer collection for the disposable fixture.
.DESCRIPTION
Run in a disposable native checkout. Uses private NVDA config and owned child
processes only. Refuses an existing NVDA session. Queued Speech Viewer output
does not establish audible completion. Raw logs remain in the temporary run dir;
review and sanitize speech before copying evidence into the repository.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [ValidateSet('chromium', 'firefox')][string]$BrowserEngine = 'chromium',
    [string]$NvdaPath = 'C:\Program Files\NVDA\nvda_noUIAccess.exe',
    [string]$SettingsPath = "$env:APPDATA\nvda\nvda.ini",
    [string]$FixtureRoot = (Resolve-Path "$PSScriptRoot\..\..\..").Path
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Native Windows is required.' }
if (Get-Process -Name nvda, nvda_noUIAccess, nvda_uiAccess -ErrorAction SilentlyContinue) {
    throw 'An NVDA session is already running. Preserve it; run this capture in a separate disposable desktop session.'
}
if (-not (Test-Path -LiteralPath $NvdaPath -PathType Leaf)) { throw 'NVDA executable is missing.' }
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Use a new output directory; earlier evidence is never overwritten.' }
$null = New-Item -ItemType Directory -Path $OutputDirectory
$OutputDirectory = (Resolve-Path -LiteralPath $OutputDirectory).Path
$privateRoot = Join-Path ([IO.Path]::GetTempPath()) ('tenants-native-speech-' + [Guid]::NewGuid().ToString('N'))
$configRoot = Join-Path $privateRoot 'nvda'
$null = New-Item -ItemType Directory -Path (Join-Path $configRoot 'scratchpad\globalPlugins') -Force
$encoding = New-Object Text.UTF8Encoding($false)
function Get-Sha256([string]$Path) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $algorithm.Dispose() }
}
$settings = if (Test-Path -LiteralPath $SettingsPath) { [IO.File]::ReadAllText($SettingsPath) } else { '' }
$originalSettingsHash = if (Test-Path -LiteralPath $SettingsPath) { Get-Sha256 $SettingsPath } else { $null }
function Set-IniValue([string]$Text, [string]$Section, [string]$Key, [string]$Value) {
    $pattern = '(?ms)^\[' + [regex]::Escape($Section) + '\]\s*\r?\n(?<body>.*?)(?=^\[|\z)'
    $match = [regex]::Match($Text, $pattern)
    if (-not $match.Success) { return $Text + "`r`n[$Section]`r`n$Key = $Value`r`n" }
    $body = $match.Groups['body'].Value
    $line = '(?m)^\s*' + [regex]::Escape($Key) + '\s*=.*$'
    if ([regex]::IsMatch($body, $line)) { $body = [regex]::Replace($body, $line, "$Key = $Value") }
    else { $body += "$Key = $Value`r`n" }
    return $Text.Substring(0, $match.Index) + "[$Section]`r`n" + $body + $Text.Substring($match.Index + $match.Length)
}
$settings = Set-IniValue $settings 'general' 'showWelcomeDialogAtStartup' 'False'
$settings = Set-IniValue $settings 'general' 'language' 'en'
$settings = Set-IniValue $settings 'speechViewer' 'showSpeechViewerAtStartup' 'True'
$settings = Set-IniValue $settings 'development' 'enableScratchpadDir' 'True'
[IO.File]::WriteAllText((Join-Path $configRoot 'nvda.ini'), $settings, $encoding)
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'deferred-nvda-observer.py') -Destination (Join-Path $configRoot 'scratchpad\globalPlugins\tenantsSpeechObserver.py')
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class TenantsSpeechDesktop {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern IntPtr SendMessageTimeout(IntPtr hwnd, uint message, UIntPtr wparam, System.Text.StringBuilder text, uint flags, uint timeout, out UIntPtr result);
    public static string ReadText(IntPtr hwnd) {
        UIntPtr length;
        if (SendMessageTimeout(hwnd, 0x000E, UIntPtr.Zero, null, 2, 1000, out length) == IntPtr.Zero) throw new InvalidOperationException("Owned viewer length read timed out");
        int count = checked((int)length.ToUInt64());
        if (count > 1000000) throw new InvalidOperationException("Owned viewer exceeded the capture bound");
        var text = new System.Text.StringBuilder(count + 1);
        UIntPtr copied;
        if (SendMessageTimeout(hwnd, 0x000D, (UIntPtr)(count + 1), text, 2, 1000, out copied) == IntPtr.Zero) throw new InvalidOperationException("Owned viewer text read timed out");
        return text.ToString();
    }
}
'@
$entryForeground = [TenantsSpeechDesktop]::GetForegroundWindow()
$started = [DateTime]::UtcNow
$ownedNvda = @()
$node = $null
$viewer = $null
$viewerText = ''
$lastSpeech = [DateTime]::UtcNow
$trial = $null
$capture = $false
$browserHandle = [IntPtr]::Zero
$browserProcess = 0
$interruptionOffset = 0
$transcript = New-Object Collections.Generic.List[object]
$protocol = New-Object Collections.Generic.List[object]
$metadata = [ordered]@{
    startedUtc = $started.ToString('o'); engine = $BrowserEngine
    osVersion = [Environment]::OSVersion.VersionString
    nvdaVersion = (Get-Item -LiteralPath $NvdaPath).VersionInfo.ProductVersion
    viewerSource = 'NVDA-owned Speech Viewer edit control, read without changing focus'
    timing = 'UTC sample time at 100 ms polling; queued text arrival, not word onset or audible completion'
    settingsOrigin = $(if ($originalSettingsHash) { 'private copy of existing nvda.ini; no addons copied' } else { 'private NVDA default configuration' })
    settingsOverrides = @('English NVDA interface', 'welcome dialog disabled', 'Speech Viewer shown on startup', 'private read-only scratchpad settings observer enabled')
    sourceSettingsSha256 = $originalSettingsHash
    collectorSha256 = Get-Sha256 $PSCommandPath
    observerSha256 = Get-Sha256 (Join-Path $PSScriptRoot 'deferred-nvda-observer.py')
    outputSanitized = $false; passed = $false
}
function Get-ViewerText {
    return [TenantsSpeechDesktop]::ReadText([IntPtr]$viewer.Current.NativeWindowHandle)
}
function Sample-Speech {
    $interruptionPath = Join-Path $configRoot 'interruptions.jsonl'
    if (Test-Path -LiteralPath $interruptionPath) {
        $lines = @([IO.File]::ReadAllLines($interruptionPath))
        if ($script:capture -and $lines.Count -gt $script:interruptionOffset) {
            foreach ($line in $lines[$script:interruptionOffset..($lines.Count - 1)]) {
                $event = $line | ConvertFrom-Json
                $script:protocol.Add(@{ kind = $event.kind; utc = $event.utc; trial = $script:trial })
            }
        }
        $script:interruptionOffset = $lines.Count
    }
    $current = Get-ViewerText
    if ($current -eq $script:viewerText) { return }
    if (-not $current.StartsWith($script:viewerText, [StringComparison]::Ordinal)) {
        $script:protocol.Add(@{ kind = 'viewer-text-reset'; trial = $script:trial; oldLength = $script:viewerText.Length; newLength = $current.Length; utc = [DateTime]::UtcNow.ToString('o') })
        throw 'Viewer text was reset or truncated; this capture cannot be accepted.'
    }
    $delta = $current.Substring($script:viewerText.Length)
    $script:viewerText = $current
    $script:lastSpeech = [DateTime]::UtcNow
    if ($script:capture) {
        [uint32]$foregroundProcess = 0
        $foreground = [TenantsSpeechDesktop]::GetForegroundWindow()
        $null = [TenantsSpeechDesktop]::GetWindowThreadProcessId($foreground, [ref]$foregroundProcess)
        if ($foreground -ne $script:browserHandle) { throw 'Browser foreground was lost during speech capture; unrelated desktop speech is excluded.' }
        $modePath = Join-Path $configRoot 'effective-mode.json'
        $mode = if (Test-Path -LiteralPath $modePath) { Get-Content -LiteralPath $modePath -Raw | ConvertFrom-Json } else { $null }
        $script:transcript.Add([ordered]@{ utc = $script:lastSpeech.ToString('o'); trial = $script:trial
            browserForeground = $true; nvdaMode = $mode; text = $delta })
    }
}
function Wait-Quiet([int]$MinimumMilliseconds, [DateTime]$Deadline) {
    while ([DateTime]::UtcNow -lt $Deadline) {
        Sample-Speech
        if ([TenantsSpeechDesktop]::GetForegroundWindow() -ne $script:browserHandle) { throw 'Browser foreground was lost during the observation.' }
        if (([DateTime]::UtcNow - $script:lastSpeech).TotalMilliseconds -ge $MinimumMilliseconds) { return }
        Start-Sleep -Milliseconds 100
    }
    throw 'No five-second quiet window within 60 seconds; retain this attempt as inconclusive.'
}
try {
    $launchedNvda = Start-Process -FilePath $NvdaPath -ArgumentList @('--config-path', ('"' + $configRoot + '"'), '--log-file', ('"' + (Join-Path $privateRoot 'nvda.log') + '"')) -PassThru
    $ownedNvda = @($launchedNvda)
    $deadline = [DateTime]::UtcNow.AddSeconds(20)
    while (-not $viewer -and [DateTime]::UtcNow -lt $deadline) {
        $ownedNvda = @(Get-Process -Id $launchedNvda.Id -ErrorAction SilentlyContinue)
        $condition = New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::NameProperty, 'NVDA Speech Viewer')
        $windows = [Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Children, $condition)
        foreach ($window in $windows) {
            if (@($ownedNvda | ForEach-Object { $_.Id }) -contains $window.Current.ProcessId) {
                $editCondition = New-Object Windows.Automation.PropertyCondition([Windows.Automation.AutomationElement]::ClassNameProperty, 'RICHEDIT50W')
                $edits = $window.FindAll([Windows.Automation.TreeScope]::Descendants, $editCondition)
                if ($edits.Count -eq 1) {
                    $viewer = $edits[0]
                    $metadata.viewerProcessId = $window.Current.ProcessId
                    $metadata.viewerControlClass = $viewer.Current.ClassName
                    $metadata.viewerControlType = $viewer.Current.ControlType.ProgrammaticName
                    break
                }
            }
        }
        if (-not $viewer) { Start-Sleep -Milliseconds 100 }
    }
    if (-not $viewer) { throw 'No edit control bound to the owned NVDA Speech Viewer was found.' }
    $viewerText = Get-ViewerText
    $metadata.viewerBound = $true
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = (Get-Command node).Source
    $start.WorkingDirectory = $FixtureRoot
    $runner = Join-Path $FixtureRoot 'tests\Hexalith.Tenants.UI.Tests\Browser\validate-authenticated-administrator-dialogs.mjs'
    $packet = Join-Path $OutputDirectory 'fixture.json'
    $start.Arguments = '"' + $runner + '" "' + $packet + '"'
    $start.UseShellExecute = $false
    $start.RedirectStandardInput = $true; $start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
    $start.CreateNoWindow = $true
    $start.EnvironmentVariables['TENANTS_BROWSER_HANDOFF'] = 'native'
    $start.EnvironmentVariables['TENANTS_BROWSER_ENGINE'] = $BrowserEngine
    $start.EnvironmentVariables['TENANTS_NATIVE_SPEECH_CAPTURE'] = '1'
    if ($BrowserEngine -eq 'chromium') { $start.EnvironmentVariables['TENANTS_BROWSER_CHANNEL'] = 'chrome' }
    else { $start.EnvironmentVariables.Remove('TENANTS_BROWSER_CHANNEL') }
    $node = New-Object Diagnostics.Process
    $node.StartInfo = $start
    $null = $node.Start()
    $stderr = $node.StandardError.ReadToEndAsync()
    $lineTask = $node.StandardOutput.ReadLineAsync()
    while (-not $node.HasExited -or $null -ne $lineTask) {
        if ($capture) { Sample-Speech }
        if (-not $lineTask.IsCompleted) { Start-Sleep -Milliseconds 100; continue }
        $line = $lineTask.GetAwaiter().GetResult()
        if ($null -eq $line) { $lineTask = $null; break }
        [IO.File]::AppendAllText((Join-Path $privateRoot 'runner.stdout'), $line + "`r`n", $encoding)
        $lineTask = $node.StandardOutput.ReadLineAsync()
        if (-not $line.StartsWith('{"nativeSpeech":true,')) { continue }
        $event = $line | ConvertFrom-Json
        $protocol.Add($event)
        $response = @{ sequence = $event.sequence; ok = $true }
        switch ($event.kind) {
            'session' {
                $capture = $false
                $windowDeadline = [DateTime]::UtcNow.AddSeconds(5)
                do {
                    $candidate = @(Get-Process -Name chrome, firefox -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like 'Tenants native speech fixture*' -and $_.StartTime.ToUniversalTime() -ge $started })
                    if ($candidate.Count -eq 1) { break }
                    Start-Sleep -Milliseconds 100
                } while ([DateTime]::UtcNow -lt $windowDeadline)
                if ($candidate.Count -ne 1) { throw "The disposable browser window is not unique (matching windows: $($candidate.Count))." }
                $browserProcess = $candidate[0].Id; $browserHandle = $candidate[0].MainWindowHandle
                # Never foreground the terminal or viewer; only this uniquely titled disposable browser.
                $null = [TenantsSpeechDesktop]::SetForegroundWindow($browserHandle)
                if ([TenantsSpeechDesktop]::GetForegroundWindow() -ne $browserHandle) { throw 'The native fixture browser is not in the foreground.' }
            }
            'arm' { $trial = $event.trial; $viewerText = Get-ViewerText; $lastSpeech = [DateTime]::UtcNow; $capture = $true }
            'quiet' { Wait-Quiet 5000 ([DateTime]::UtcNow.AddSeconds(60)); $protocol.Add(@{ kind = 'quiet-window'; trial = $trial; utc = [DateTime]::UtcNow.ToString('o'); queuedQuietSeconds = 5 }) }
            'trigger' { Sample-Speech }
            'observe' {
                $observationStart = [DateTime]::UtcNow
                $deadline = ([DateTime]::Parse($event.stateUtc).ToUniversalTime()).AddSeconds(60)
                $minimumEnd = ([DateTime]::Parse($event.stateUtc).ToUniversalTime()).AddSeconds(30)
                while ([DateTime]::UtcNow -lt $minimumEnd) { Sample-Speech; if ([TenantsSpeechDesktop]::GetForegroundWindow() -ne $browserHandle) { throw 'Browser foreground was lost.' }; Start-Sleep -Milliseconds 100 }
                Wait-Quiet 5000 $deadline
                $response.observation = @{ startedUtc = $observationStart.ToString('o'); endedUtc = [DateTime]::UtcNow.ToString('o'); queuedQuietSeconds = 5; audibleCompletion = 'not established by Speech Viewer' }
                $protocol.Add(@{ kind = 'observation-end'; trial = $trial; observation = $response.observation })
                $capture = $false
            }
            'control-start' { $trial = $event.trial + '-focus-control'; $viewerText = Get-ViewerText; $capture = $true }
            'control-end' {
                Start-Sleep -Milliseconds 500
                Wait-Quiet 5000 ([DateTime]::UtcNow.AddSeconds(60))
                $count = @($transcript | Where-Object { $_.trial -eq $trial }).Count
                $protocol.Add(@{ kind = 'focus-control-result'; trial = $trial; speechSamples = $count; utc = [DateTime]::UtcNow.ToString('o') })
                if ($count -eq 0) { throw 'Positive focus/omission control produced no captured speech.' }
                # Real OS Control key records an explicit interruption control, outside product observation.
                [TenantsSpeechDesktop]::keybd_event(0x11, 0, 0, [UIntPtr]::Zero)
                [TenantsSpeechDesktop]::keybd_event(0x11, 0, 2, [UIntPtr]::Zero)
                $protocol.Add(@{ kind = 'interruption-control'; trial = $trial; utc = [DateTime]::UtcNow.ToString('o'); key = 'Control'; audibleCompletion = 'not inferred' })
                $capture = $false
            }
            'complete' { $capture = $false; $metadata.completed = $true }
            default { throw 'Unknown native capture protocol event.' }
        }
        $node.StandardInput.WriteLine(($response | ConvertTo-Json -Compress -Depth 8))
        $node.StandardInput.Flush()
    }
    $node.WaitForExit()
    [IO.File]::WriteAllText((Join-Path $privateRoot 'runner.stderr'), $stderr.GetAwaiter().GetResult(), $encoding)
    $metadata.runnerExitCode = $node.ExitCode
    if ($node.ExitCode -ne 0) { throw 'Native fixture did not complete; retain its failure packet.' }
    $metadata.passed = $true
}
catch {
    $metadata.failure = $_.Exception.Message
    Write-Warning $metadata.failure
}
finally {
    $capture = $false
    if ($node -and -not $node.HasExited) {
        # Close the owned runner's stdin first; never kill a process by browser name.
        $node.StandardInput.Close()
        if (-not $node.WaitForExit(5000)) { & taskkill.exe /PID $node.Id /T /F | Out-Null }
    }
    foreach ($process in $ownedNvda) {
        $current = Get-Process -Id $process.Id -ErrorAction SilentlyContinue
        if ($current -and $current.StartTime -eq $process.StartTime) {
            try { Stop-Process -Id $process.Id -ErrorAction Stop }
            catch { $metadata.cleanupBlocker = 'The owned NVDA process could not be stopped by this token.'; $metadata.passed = $false }
        }
    }
    $metadata.sourceSettingsUnchanged = if ($originalSettingsHash) { (Get-Sha256 $SettingsPath) -eq $originalSettingsHash } else { -not (Test-Path -LiteralPath $SettingsPath) }
    $effective = Join-Path $configRoot 'effective-settings.json'
    if (Test-Path -LiteralPath $effective) { $metadata.effectiveSettings = Get-Content -LiteralPath $effective -Raw | ConvertFrom-Json }
    else { $metadata.passed = $false; $metadata.settingsBlocker = 'Effective NVDA settings were not observed.' }
    $metadata.finishedUtc = [DateTime]::UtcNow.ToString('o')
    $metadata.privateLogs = $privateRoot
    [IO.File]::WriteAllText((Join-Path $OutputDirectory 'capture.json'), ($metadata | ConvertTo-Json -Depth 12), $encoding)
    [IO.File]::WriteAllText((Join-Path $OutputDirectory 'speech.json'), (ConvertTo-Json -InputObject @($transcript.ToArray()) -Depth 8), $encoding)
    [IO.File]::WriteAllText((Join-Path $OutputDirectory 'timeline.json'), (ConvertTo-Json -InputObject @($protocol.ToArray()) -Depth 12), $encoding)
    if ([TenantsSpeechDesktop]::GetForegroundWindow() -eq $browserHandle -and [TenantsSpeechDesktop]::IsWindow($entryForeground)) {
        $null = [TenantsSpeechDesktop]::SetForegroundWindow($entryForeground)
    }
}
if (-not $metadata.passed) { exit 1 }
