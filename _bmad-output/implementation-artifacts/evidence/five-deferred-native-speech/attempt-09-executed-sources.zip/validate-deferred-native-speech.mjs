// Native-only, opt-in orchestration. Speech comes exclusively from the separate
// NVDA-owned Speech Viewer collector; these browser observations are not speech.
import assert from 'node:assert/strict';
import { createInterface } from 'node:readline';

export async function runDeferredNativeSpeech({ fixture, newSession, evidence, wait }) {
    assert.equal(process.platform, 'win32', 'Native speech qualification requires Windows');
    assert.equal(process.env.TENANTS_NATIVE_SPEECH_CAPTURE, '1', 'Use capture-deferred-nvda-speech.ps1');
    const reader = createInterface({ input: process.stdin, crlfDelay: Infinity });
    const input = reader[Symbol.asyncIterator]();
    let sequence = 0;
    const exchange = async event => {
        const request = { nativeSpeech: true, sequence: ++sequence, utc: new Date().toISOString(), ...event };
        console.log(JSON.stringify(request));
        const response = await input.next();
        assert.equal(response.done, false, 'Native collector closed before acknowledgement');
        const reply = JSON.parse(response.value);
        assert.equal(reply.sequence, sequence, 'Native collector acknowledgement mismatch');
        assert.equal(reply.ok, true, 'Native collector could not retain a valid observation');
        return reply;
    };
    let page;
    const id = value => page.getByTestId(value);
    const focus = () => page.evaluate(() => {
        let node = document.activeElement;
        while (node?.shadowRoot?.activeElement) node = node.shadowRoot.activeElement;
        const ancestry = [];
        for (let item = node; item; item = item.parentElement || item.getRootNode()?.host)
            if (item.getAttribute?.('data-testid')) ancestry.push(item.getAttribute('data-testid'));
        return { documentHasFocus: document.hasFocus(), element: node?.localName, ancestry };
    });
    const tabTo = async locator => {
        assert.equal(await locator.count(), 1, 'The selected keyboard target must be unique');
        await wait(() => locator.evaluate(node => !node.hasAttribute('disabled')), 'Native keyboard target enabled');
        for (let count = 0; count < 100; count++) {
            if (await locator.evaluate(node => {
                let active = document.activeElement;
                while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
                return node === active || node.contains(active) || node.shadowRoot?.contains(active);
            })) return;
            await page.keyboard.press('Tab');
        }
        assert.fail('Selected control was not reached by keyboard');
    };
    const session = async culture => {
        page = await newSession(culture);
        await page.evaluate(() => { document.title = 'Tenants native speech fixture'; });
        await page.bringToFront();
        await exchange({ kind: 'session', culture });
    };
    const observe = async (trial, culture, action, state) => {
        await exchange({ kind: 'arm', trial, culture, focus: await focus() });
        await exchange({ kind: 'quiet', trial });
        await exchange({ kind: 'trigger', trial, focus: await focus() });
        await action();
        await state();
        const result = await exchange({ kind: 'observe', trial, stateUtc: new Date().toISOString(), focus: await focus(), fixture: fixture.snapshot() });
        evidence.nativeSpeechTrials ??= [];
        evidence.nativeSpeechTrials.push({ trial, culture, observation: result.observation,
            focus: await focus(), fixture: fixture.snapshot() });
        // A product focus announcement after the window is an omission control.
        // It is retained separately and cannot satisfy the live-announcement gate.
        await exchange({ kind: 'control-start', trial });
        await tabTo(id('tenants-list-search'));
        await page.keyboard.press('Shift+Tab');
        await page.keyboard.press('Tab');
        await exchange({ kind: 'control-end', trial, focus: await focus() });
    };
    const search = async () => {
        await id('tenants-list-search').locator('input').fill('needle');
        await page.keyboard.press('Tab');
        await page.waitForURL(url => url.searchParams.get('search') === 'needle');
        await page.waitForLoadState('networkidle');
    };
    const availability = pageState => page.locator(`[data-testid="tenants-create-audit"] [data-testid="tenants-audit-availability"][data-state="${pageState}"]`);
    for (const culture of ['en', 'fr']) {
        await session(culture);
        assert.equal(await id('tenants-list-notices').locator('[data-testid$="-notice"]').count(), 0);
        await observe(`S0-${culture}`, culture, search, async () => {
            assert.equal(await id('tenants-list-notices').locator('[data-testid$="-notice"]').count(), 0);
        });

        await session(culture);
        fixture.apply('search down');
        await observe(`S1-${culture}`, culture, search, () => id('tenants-list-search-unavailable-notice').waitFor());

        await session(culture);
        await search();
        await id('tenants-list-next').click();
        await wait(() => id('tenants-list-previous').evaluate(node => !node.hasAttribute('disabled')), 'Protected page two');
        await id('tenants-list-detail-link').first().click();
        await id('tenants-detail-back').waitFor();
        await observe(`S2-${culture}`, culture, () => page.goBack(), () => id('tenants-list-search-refreshed-notice').waitFor());

        await session(culture);
        fixture.apply('search down');
        await search();
        await id('tenants-list-search-unavailable-notice').waitFor();
        fixture.apply('cursor reject-once');
        await tabTo(id('tenants-list-next'));
        await observe(`S3-${culture}`, culture, () => page.keyboard.press('Enter'), async () => {
            await id('tenants-list-refreshed-notice').waitFor();
            assert.equal(fixture.snapshot().rejectedCursors, 1);
            assert.equal(fixture.snapshot().recoveryPages, 1);
            assert.equal(fixture.snapshot().rejectCursor, false);
        });
        await id('tenants-list-next').click();
        await wait(() => fixture.snapshot().continuations === 1, 'Subsequent continuation permitted');
        assert.equal(fixture.snapshot().rejectedCursors, 1);

        for (const status of ['events', 'unavailable']) {
            for (const refresh of ['lifecycle', 'availability']) {
                await session(culture);
                fixture.apply(`status ${status}`);
                fixture.apply('projection hold');
                await id('tenants-create-accordion').getByRole('button').click();
                assert.equal(await page.locator('[data-testid="tenants-create-audit"] [data-testid="tenants-audit-availability"]').count(), 0);
                await id('tenants-create-tenant-id').locator('input').fill(`tenant.speech.${culture}-${status}-${refresh}`);
                await id('tenants-create-name').locator('input').fill('Speech fixture tenant');
                await page.keyboard.press('Tab');
                await tabTo(id('tenants-create-submit'));
                const expected = status === 'events' ? 'pending' : 'unavailable';
                const trial = `${status === 'events' ? 'C1' : 'C2'}-${refresh}-${culture}`;
                await observe(trial, culture, () => page.keyboard.press('Enter'), async () => {
                    await availability(expected).waitFor();
                    assert.equal((await page.evaluate(() => window.__handoffStates))[0]?.state, expected);
                    assert.equal(fixture.snapshot().projection, 'hold');
                    assert.equal(fixture.snapshot().simulatedCommands, 1);
                });
                const button = refresh === 'lifecycle' ? id('tenants-create-refresh')
                    : page.locator('[data-testid="tenants-create-audit"] [data-testid="tenants-audit-availability-recovery-refresh"]');
                await tabTo(button);
                const prior = fixture.snapshot().statusReads;
                await observe(`C3-${status}-${refresh}-${culture}`, culture, () => page.keyboard.press('Enter'), async () => {
                    await wait(() => fixture.snapshot().statusReads > prior, 'Selected Refresh performs a status read');
                    await wait(() => button.evaluate(node => !node.hasAttribute('disabled')), 'Selected Refresh completes');
                    await availability(expected).waitFor();
                    assert.equal(fixture.snapshot().simulatedCommands, 1);
                    assert.equal(fixture.snapshot().unexpectedCommands, 0);
                    assert.equal(fixture.snapshot().projection, 'hold');
                });
            }
        }
    }
    await exchange({ kind: 'complete' });
    reader.close();
    evidence.fixtureScope = 'Native authenticated disposable production UI; actual Speech Viewer output is retained separately and requires independent assessment';
}
