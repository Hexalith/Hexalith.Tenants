import json,re
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/tenants')
entry=Path(__file__).parent
selected={540,554,570,584,593}
def records(s):
 return {int(m.group(1)):m.group(0) for m in re.finditer(r'^### DW-(\d+):.*?(?=^#{2,3} |\Z)',s,re.M|re.S)}
before=records((entry/'deferred-work.md').read_text())
after=records((root/'_bmad-output/implementation-artifacts/deferred-work.md').read_text())
assert before.keys()==after.keys() and len(after)==657
for id in after.keys()-selected:
 assert after[id]==before[id],f'unselected DW-{id} changed'
open_ids={i for i,b in after.items() if re.search(r'^status: open$',b,re.M)}
index=(root/'docs/maintenance-backlog.md').read_text()
rows=[l for l in index.splitlines() if l.startswith('| DW-')]
listed=[int(i) for l in rows for i in re.findall(r'DW-(\d+)',l.split('|')[1])]
assert len(listed)==len(set(listed)) and set(listed)==open_ids
for id in selected:
 b=after[id]
 for line in before[id].splitlines():
  if line and not line.startswith('###'):
   assert line in b.splitlines() or 'pre-release-governance-'+line in b.splitlines(),f'DW-{id} original field missing: {line}'
print(json.dumps({'numberedRecords':len(after),'selected':sorted(selected),'open':len(open_ids),'done':len(after)-len(open_ids),'indexRows':len(rows),'unselectedBodiesPreserved':True,'selectedHistoricalLinesPreserved':True},indent=2))
