from pathlib import Path
import re, xml.etree.ElementTree as ET

root = ET.parse('/tmp/tenants-lifecycle-maintenance/full-final/results.trx').getroot()
c = root.find('.//{*}Counters').attrib
assert int(c['total']) == 7398 and int(c['passed']) == 7398 and int(c['failed']) == 0
assert all(r.attrib['outcome'] == 'Passed' for r in root.findall('.//{*}UnitTestResult'))

prefix = 'pre-lifecycle-maintenance-'
evidence = '_bmad-output/implementation-artifacts/dw-301-302-321-322-323-validation-evidence.md'
selected = {
301: ('Independent tenant/caller-keyed proof scopes preserve concurrent reads, cancellation generation and operation-owned disposal, including reentrant and competing-thread completion. The gateway shares its unconditional detail proof read. Focused and complete UI regressions pass; see '+evidence,
 'src/Hexalith.Tenants.UI/State/TenantCommands/TenantProofScope.cs; src/Hexalith.Tenants.UI/State/TenantCommands/TenantProofOperation.cs; src/Hexalith.Tenants.UI/Components/Pages/TenantDetailPage.razor; src/Hexalith.Tenants.UI/Services/Gateways/TenantQueryGateway.cs; tests/Hexalith.Tenants.UI.Tests/State/TenantProofScopeTests.cs; '+evidence),
302: ('Supplied high-impact evidence is the canonical projection marker, including absent versions; compatibility scalar parameters apply only without typed evidence. Preview, remount, submit and conflicting-version regressions pass in the focused and complete UI lanes; see '+evidence,
 'src/Hexalith.Tenants.UI/Components/Tenants/Lifecycle/TenantLifecycleActionAvailability.razor; src/Hexalith.Tenants.UI/Components/Tenants/Lifecycle/TenantLifecycleCommandFlow.razor; tests/Hexalith.Tenants.UI.Tests/Components/TenantLifecycleActionAvailabilityTests.cs; '+evidence),
321: ('Shared detail-page helpers preserve exact surface admission identity, nullable tracker retention polarity, route reclamation and successor ownership. Both lifecycle components share the existing focus exception policy. Nine page ownership cases and supported/unsupported focus checks pass with the complete UI suite; see '+evidence,
 'src/Hexalith.Tenants.UI/Components/Pages/TenantDetailPage.razor; src/Hexalith.Tenants.UI/Components/Tenants/Lifecycle/TenantLifecycleFocus.cs; tests/Hexalith.Tenants.UI.Tests/Components/TenantDetailSurfaceTests.cs; tests/Hexalith.Tenants.UI.Tests/Components/TenantLifecycleActionAvailabilityTests.cs; '+evidence),
322: ('Render-time tracker reads apply constant-size requested-tenant expiry; mutation sweeps reuse that policy. The original snapshot-only workload allocated 13176000 bytes; the strengthened three-collection workload allocates zero. Exact-deadline, dispatch-only, clock-regression and stale-arrival regressions pass with the complete UI suite; see '+evidence,
 'src/Hexalith.Tenants.UI/State/TenantCommands/TenantLifecycleAttemptTracker.cs; tests/Hexalith.Tenants.UI.Tests/State/TenantLifecycleMaintenanceTests.cs; '+evidence),
323: ('Thirty inconclusive polls bound missing/transient and verified pre-event status alongside the unchanged five-minute deadline. Remounts preserve identity and budget; terminal results and the stored-event final proof retain their semantics. Boundary, rendered held-proof and shipped EN/FR recovery regressions pass with the complete UI suite; see '+evidence,
 'src/Hexalith.Tenants.UI/State/TenantCommands/TenantLifecycleCommandSnapshot.cs; src/Hexalith.Tenants.UI/State/TenantCommands/TenantLifecycleAttemptTracker.cs; src/Hexalith.Tenants.UI/Resources/TenantsResources.resx; src/Hexalith.Tenants.UI/Resources/TenantsResources.fr.resx; tests/Hexalith.Tenants.UI.Tests/State/TenantLifecycleMaintenanceTests.cs; tests/Hexalith.Tenants.UI.Tests/Components/TenantLifecycleActionAvailabilityTests.cs; '+evidence),
}
summary = '**DW-301/DW-302/DW-321/DW-322/DW-323 closure (2026-10-22):** Shared lifecycle proof, lease and focus handling preserves caller/cancellation and exact ownership; typed evidence governs versions, routine tracker reads allocate no dictionary snapshots, and thirty inconclusive polls bound status waiting without discarding final event-backed proof. Exactly five records close: all 657 IDs remain, 530 done/127 open across 117 maintenance rows. Historical fields, unrelated records, dependencies and release holds remain preserved. See [validation evidence](LINK).'
p = Path('_bmad-output/implementation-artifacts/deferred-work.md')
s = p.read_text()
parts = re.split(r'(?=^### DW-)', s, flags=re.M)
for i, block in enumerate(parts):
 m = re.match(r'### DW-(\d+):', block)
 if m is None or int(m[1]) not in selected: continue
 n = int(m[1])
 verification, files = selected[n]
 values = {'status':'done 2026-10-22','disposition':'done','verification-date':'2026-10-22','verification':verification,'verification-files':files,'evidence-kind':'executed-regression','dependencies':'none (compatibility and regression gates satisfied)','next-action':'None; closed by the lifecycle maintenance batch.'}
 for key, value in values.items():
  pattern = r'^'+re.escape(key)+r': (.*)$'
  assert len(re.findall(pattern, block, re.M)) == 1, (n,key)
  block = re.sub(pattern, lambda match: prefix+key+': '+match[1]+'\n'+key+': '+value, block, flags=re.M)
 parts[i] = block
s = ''.join(parts)
s = s.replace('# Deferred Work\n\n', '# Deferred Work\n\n'+summary.replace('LINK', 'dw-301-302-321-322-323-validation-evidence.md')+'\n\n',1)
p.write_text(s)
p = Path('docs/maintenance-backlog.md')
s = p.read_text()
rows = [line for line in s.splitlines() if line.startswith('| DW-') and {int(v) for v in re.findall(r'DW-(\d+)',line.split('|')[1])} & selected.keys()]
assert len(rows) == 5
s = ''.join(line for line in s.splitlines(keepends=True) if line.rstrip('\n') not in rows)
for old,new in [('| done | 525 |','| done | 530 |'),('| actionable | 66 |','| actionable | 61 |'),('**Remaining: 132 open records across 122 index rows.**','**Remaining: 127 open records across 117 index rows.**')]:
 assert old in s
 s = s.replace(old,new,1)
s = s.replace('# Maintenance backlog\n\n','# Maintenance backlog\n\n'+summary.replace('LINK','../'+evidence)+'\n\n',1)
p.write_text(s)
print('Closed exactly:', sorted(selected))
