import json, subprocess, sys
import xml.etree.ElementTree as E
from pathlib import Path
root = Path(__file__).parent
paths = [Path('src/Hexalith.Tenants.UI/Components/Pages/TenantsWorkspace.razor')]
paths += [Path('src/Hexalith.Tenants.UI/Components/Tenants/Members') / (name + '.razor') for name in ('AddTenantMemberFlow', 'ChangeTenantMemberRoleFlow')]
backups = {p: p.read_bytes() for p in paths}
try:
    for p in paths:
        s = p.read_text()
        if p.name == 'TenantsWorkspace.razor':
            before = '''        long loadVersion = System.Threading.Interlocked.Increment(ref _loadVersion);
        // Cancellation may synchronously complete the previous read on this dispatcher.
        // Retire its generation before invoking any of its cancellation callbacks.
        using PendingLoadOperation operation = BeginLoad();'''
            after = '''        using PendingLoadOperation operation = BeginLoad();
        long loadVersion = System.Threading.Interlocked.Increment(ref _loadVersion);'''
            assert before in s
            s = s.replace(before, after, 1)
        else:
            assert 'private readonly AsyncLocal<bool> _isProjectionRefreshCallback = new();' in s
            s = s.replace('private readonly AsyncLocal<bool> _isProjectionRefreshCallback = new();', 'private bool _isProjectionRefreshCallback;').replace('_isProjectionRefreshCallback.Value', '_isProjectionRefreshCallback')
        p.write_bytes(s.replace('\n', '\r\n').encode())
    runner = [sys.executable, str(root / 'run.py')]
    build = ['dotnet', 'build', 'tests/Hexalith.Tenants.UI.Tests/Hexalith.Tenants.UI.Tests.csproj', '--configuration', 'Debug', '-p:UseHexalithProjectReferences=true', '-m:1', '-nr:false']
    assert subprocess.run(runner + ['negative-build'] + build).returncode == 0
    command = ['dotnet', 'tests/Hexalith.Tenants.UI.Tests/bin/Debug/net10.0/Hexalith.Tenants.UI.Tests.dll', '-method', '*SynchronousCancellationCompletionCannotApplyTheSupersededList', '-method', '*IndependentNudgeDuringHeldProjectionCallbackSchedulesCatchUpLookup', '-parallelMode', 'none', '-result-trx', str(root / 'negative.trx')]
    result = subprocess.run(runner + ['negative-tests'] + command)
    counters = E.parse(root / 'negative.trx').getroot().find('.//{*}Counters').attrib
    assert result.returncode != 0 and counters['total'] == '3' and counters['failed'] == '3', counters
    (root / 'negative-summary.json').write_text(json.dumps({'mutations': ['original workspace ordering', 'component-wide bool in add/change'], 'expected_failures': 3, 'counters': counters}, indent=2)+'\n')
    print('All three negative controls failed as required.')
finally:
    for p, content in backups.items():
        p.write_bytes(content)
    print('Restored exact candidate source bytes.')
