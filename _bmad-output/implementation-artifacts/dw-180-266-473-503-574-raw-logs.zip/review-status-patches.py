from pathlib import Path
p=Path('src/Hexalith.Tenants.UI/Components/Tenants/Audit/CorrectionStartPanel.razor');s=p.read_text()
s=s.replace('private int _statusReadInFlight;','private object? _statusReadOwner;')
s=s.replace('Volatile.Read(ref _statusReadInFlight) == 0','Volatile.Read(ref _statusReadOwner) is null')
s=s.replace('        if (Interlocked.CompareExchange(ref _statusReadInFlight, 1, 0) != 0) return;','        object statusReadOwner = new();\n        if (Interlocked.CompareExchange(ref _statusReadOwner, statusReadOwner, null) is not null) return;')
s=s.replace('        finally { Volatile.Write(ref _statusReadInFlight, 0); }','        finally { Interlocked.CompareExchange(ref _statusReadOwner, null, statusReadOwner); }')
# Retiring any mounted operation also retires only its local status-read guard. An old finally
# may no longer clear the successor's unique owner token.
s=s.replace('Interlocked.Increment(ref _confirmGeneration);','Interlocked.Increment(ref _confirmGeneration);\n            Interlocked.Exchange(ref _statusReadOwner, null);')
# The single-line lock in CloseAsync needs braces after the extra statement for clear scope.
s=s.replace('        lock (_confirmSync) Interlocked.Increment(ref _confirmGeneration);\n            Interlocked.Exchange(ref _statusReadOwner, null);','        lock (_confirmSync)\n        {\n            Interlocked.Increment(ref _confirmGeneration);\n            Interlocked.Exchange(ref _statusReadOwner, null);\n        }')
needle='''            }
            StateHasChanged();
        });
    }

    /// <inheritdoc />
    public void Dispose()'''
repl='''            }
            else if (_snapshot is null && Intent is not null
                && _attemptTracker.Find(Intent.TenantScope) is { } visible && visible.Matches(Intent))
            {
                // Same-caller resolution can restore this still-mounted panel without parent input.
                _snapshot = visible.Snapshot;
                _intentReference = Intent.OriginalAuditReference;
                _roleValue = visible.Snapshot.IntendedRole.ToString();
                _hasSubmitted = true;
            }
            StateHasChanged();
        });
    }

    /// <inheritdoc />
    public void Dispose()'''
assert needle in s;s=s.replace(needle,repl,1)
p.write_bytes(s.replace('\n','\r\n').encode())
p=Path('tests/Hexalith.Tenants.UI.Tests/Components/CorrectionStartPanelTests.cs');s=p.read_text()
start=s.index('    public async Task HeldStatusCannotDisplayOrUpdateAReplacement(');end=s.index('    /// <summary>A late nonterminal',start)
b=s[start:end]
b=b.replace('        TenantCorrectionPreviewSnapshot displayedReplacement = cut.Instance.Snapshot!;','''        TenantCorrectionPreviewSnapshot displayedReplacement = cut.Instance.Snapshot!;
        TaskCompletionSource<TenantCommandStatusResult> successorStatus = new(TaskCreationOptions.RunContinuationsAsynchronously);
        commands.StatusTask = successorStatus.Task;
        Task successorRefresh = cut.Find("[data-testid='tenants-correction-refresh']")
            .ClickAsync(new Microsoft.AspNetCore.Components.Web.MouseEventArgs());
        cut.WaitForAssertion(() => commands.StatusHandles.Count.ShouldBe(2));''')
b=b.replace('        commands.StatusHandles.ShouldHaveSingleItem().MessageId.ShouldBe(original.MessageId);','''        commands.StatusHandles.Count.ShouldBe(2);
        commands.StatusHandles[0].MessageId.ShouldBe(original.MessageId);
        commands.StatusHandles[1].MessageId.ShouldBe(replacement.MessageId);
        cut.Find("[data-testid='tenants-correction-refresh']").HasAttribute("disabled").ShouldBeTrue();''')
b=b.replace('        gate.IsLocked(TenantCommandAggregateLock.ForTenant(intent.TenantScope)).ShouldBeTrue();','''        gate.IsLocked(TenantCommandAggregateLock.ForTenant(intent.TenantScope)).ShouldBeTrue();
        successorStatus.SetResult(TenantCommandStatusResult.Pending("successor pending"));
        await successorRefresh.WaitAsync(TimeSpan.FromSeconds(5));
        cut.Instance.Snapshot!.MessageId.ShouldBe(replacement.MessageId);''')
s=s[:start]+b+s[end:]
marker='    [Fact]\n    public void Panel_renders_blocked_global_admin_reason_without_preview_handoff()'
new='''    [Fact]
    public async Task SameCallerResolutionRestoresAStillMountedCorrectionWithoutParentParameters()
    {
        Services.AddLocalization();
        var authentication = new Hexalith.Tenants.UI.Tests.State.TenantCorrectionAuthenticationStateProvider();
        using TenantCorrectionAttemptTracker tracker = new(authentication, static () => DateTimeOffset.UtcNow);
        TenantAggregateCommandAdmissionGate gate = new();
        Services.AddSingleton(tracker);
        Services.AddSingleton(gate);
        TenantCorrectionStartIntent intent = TenantCorrectionStartIntent.Evaluate(Context(
            Row("UserRemovedFromTenant"), TenantRole.TenantReader));
        TenantCorrectionAttempt attempt = BeginAcceptedCorrection(tracker, gate, intent);
        IRenderedComponent<CorrectionStartPanel> cut = Render<CorrectionStartPanel>(parameters => parameters.Add(p => p.Intent, intent));
        TaskCompletionSource<Microsoft.AspNetCore.Components.Authorization.AuthenticationState> identity = new(TaskCreationOptions.RunContinuationsAsynchronously);

        authentication.Change(identity.Task);
        cut.WaitForAssertion(() => cut.Instance.Snapshot.ShouldBeNull());
        identity.SetResult(Hexalith.Tenants.UI.Tests.State.TenantCorrectionAuthenticationStateProvider.State("operator.alpha"));

        cut.WaitForAssertion(() => cut.Instance.Snapshot!.MessageId.ShouldBe(attempt.MessageId));
        cut.Instance.Snapshot!.IntendedRole.ShouldBe(TenantRole.TenantReader);
        gate.IsLocked(TenantCommandAggregateLock.ForTenant(intent.TenantScope)).ShouldBeTrue();
    }

    [Fact]
    public async Task HeldStatusGatewayFallbackQueriesTheOriginalTenantAndTargetAfterReplacement()
    {
        Services.AddLocalization();
        using TenantCorrectionAttemptTracker tracker = new();
        TenantAggregateCommandAdmissionGate gate = new();
        Services.AddSingleton(tracker);
        Services.AddSingleton(gate);
        TaskCompletionSource<TenantCommandStatusResult> status = new(TaskCreationOptions.RunContinuationsAsynchronously);
        TaskCompletionSource started = new(TaskCreationOptions.RunContinuationsAsynchronously);
        StubTenantCommandGateway commands = new() { StatusTask = status.Task, StatusReadStarted = () => started.TrySetResult() };
        Services.AddSingleton<ITenantCommandGateway>(commands);
        StubTenantQueryGateway queries = new(Detail());
        Services.AddSingleton<ITenantQueryGateway>(queries);
        TenantCorrectionStartIntent intent = TenantCorrectionStartIntent.Evaluate(Context(
            Row("UserRemovedFromTenant"), TenantRole.TenantReader));
        TenantCorrectionAttempt original = BeginAcceptedCorrection(tracker, gate, intent);
        IRenderedComponent<CorrectionStartPanel> cut = Render<CorrectionStartPanel>(parameters => parameters.Add(p => p.Intent, intent));
        Task refreshing = cut.Find("[data-testid='tenants-correction-refresh']")
            .ClickAsync(new Microsoft.AspNetCore.Components.Web.MouseEventArgs());
        await started.Task.WaitAsync(TimeSpan.FromSeconds(5));
        TenantCorrectionStartIntent replacement = intent with {
            OriginalAuditReference = "replacement-reference", TenantScope = "tenant.beta", TargetUserId = "replacement-user",
            CurrentProjection = intent.CurrentProjection! with { TenantId = "tenant.beta", TargetUserId = "replacement-user" },
        };
        cut.Render(parameters => parameters.Add(p => p.Intent, replacement));
        TenantCorrectionPreviewSnapshot displayedReplacement = cut.Instance.Snapshot!;

        status.SetResult(new(CommandStatus.Completed, EventCount: 1, HasVerifiedCommandIdentity: true) { CommittedEventSequence = 2 });
        await refreshing.WaitAsync(TimeSpan.FromSeconds(5));

        queries.CorrectionCaptureTargets.ShouldHaveSingleItem().ShouldBe((intent.TenantScope, intent.TargetUserId));
        cut.Instance.Snapshot.ShouldBe(displayedReplacement);
        tracker.Find(intent.TenantScope)!.MessageId.ShouldBe(original.MessageId);
        commands.AddUserRequests.ShouldBeEmpty();
    }

'''
assert marker in s;s=s.replace(marker,new+marker,1)
s=s.replace('        public int CorrectionCaptureCount { get; private set; }','''        public int CorrectionCaptureCount { get; private set; }

        public List<(string TenantId, string TargetUserId)> CorrectionCaptureTargets { get; } = [];''')
s=s.replace('            CorrectionCaptureCount++;','            CorrectionCaptureTargets.Add((tenantId, targetUserId));\n            CorrectionCaptureCount++;')
p.write_bytes(s.replace('\n','\r\n').encode())
