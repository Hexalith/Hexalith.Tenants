from pathlib import Path
p=Path('src/Hexalith.Tenants.UI/Components/Tenants/Audit/CorrectionStartPanel.razor');s=p.read_text()
lines=s.splitlines()
for i in range(len(lines)-1,-1,-1):
 if 'Interlocked.Exchange(ref _statusReadOwner, null);' in lines[i]:
  pad=lines[i][:len(lines[i])-len(lines[i].lstrip())]
  lines.insert(i+1,pad+'_isSubmitting = false;')
s='\n'.join(lines)+'\n'
s=s.replace('            await InvokeAsync(() => { _isSubmitting = false; StateHasChanged(); }).ConfigureAwait(false);','''            if (!_disposed)
            {
                await InvokeAsync(() =>
                {
                    if (!_disposed && confirmGeneration == Volatile.Read(ref _confirmGeneration))
                    {
                        _isSubmitting = false;
                        StateHasChanged();
                    }
                }).ConfigureAwait(false);
            }''')
s=s.replace('            finally { _isSubmitting = false; }','''            finally
            {
                if (!_disposed)
                {
                    await InvokeAsync(() =>
                    {
                        if (!_disposed && statusGeneration == Volatile.Read(ref _confirmGeneration))
                        {
                            _isSubmitting = false;
                            StateHasChanged();
                        }
                    }).ConfigureAwait(false);
                }
            }''')
s=s.replace('''        object statusReadOwner = new();
        if (Interlocked.CompareExchange(ref _statusReadOwner, statusReadOwner, null) is not null) return;''','''        object? statusReadOwner = null;
        bool duplicateRead = false;
        if (!_disposed)
        {
            try
            {
                await InvokeAsync(() =>
                {
                    // An old delivery may start reconciliation after its mount was replaced. It
                    // can retain its own result, but cannot acquire the replacement's busy guard.
                    if (_disposed || statusGeneration != Volatile.Read(ref _confirmGeneration)
                        || !string.Equals(_snapshot?.MessageId, attempt.MessageId, StringComparison.Ordinal)) return;
                    object candidateOwner = new();
                    duplicateRead = Interlocked.CompareExchange(ref _statusReadOwner, candidateOwner, null) is not null;
                    if (!duplicateRead) statusReadOwner = candidateOwner;
                }).ConfigureAwait(false);
            }
            catch (ObjectDisposedException) when (_disposed) { }
            catch (InvalidOperationException) when (_disposed) { }
        }
        if (duplicateRead) return;''')
s=s.replace('        finally { Interlocked.CompareExchange(ref _statusReadOwner, null, statusReadOwner); }','''        finally
        {
            if (statusReadOwner is not null) Interlocked.CompareExchange(ref _statusReadOwner, null, statusReadOwner);
        }''')
p.write_bytes(s.replace('\n','\r\n').encode())
p=Path('tests/Hexalith.Tenants.UI.Tests/Components/CorrectionStartPanelTests.cs');s=p.read_text()
marker='    [Fact]\n    public async Task SameCallerResolutionRestoresAStillMountedCorrectionWithoutParentParameters()'
new='''    [Fact]
    public async Task LateDeliveryReconciliationCannotAcquireTheReplacementStatusGuard()
    {
        Services.AddLocalization();
        using TenantCorrectionAttemptTracker tracker = new();
        TenantAggregateCommandAdmissionGate gate = new();
        Services.AddSingleton(tracker);
        Services.AddSingleton(gate);
        TaskCompletionSource<TenantCommandSubmissionResult> delivery = new(TaskCreationOptions.RunContinuationsAsynchronously);
        TaskCompletionSource<TenantCommandStatusResult> originalStatus = new(TaskCreationOptions.RunContinuationsAsynchronously);
        TaskCompletionSource<TenantCommandStatusResult> successorStatus = new(TaskCreationOptions.RunContinuationsAsynchronously);
        TaskCompletionSource statusStarted = new(TaskCreationOptions.RunContinuationsAsynchronously);
        StubTenantCommandGateway commands = new() {
            AddUserResultTask = delivery.Task, StatusTask = originalStatus.Task,
            StatusReadStarted = () => statusStarted.TrySetResult(),
        };
        Services.AddSingleton<ITenantCommandGateway>(commands);
        TenantCorrectionStartIntent intent = TenantCorrectionStartIntent.Evaluate(Context(
            Row("UserRemovedFromTenant"), TenantRole.TenantReader));
        IRenderedComponent<CorrectionStartPanel> cut = Render<CorrectionStartPanel>(parameters => parameters
            .Add(p => p.Intent, intent)
            .Add(p => p.CurrentCaptureProvider, () => Task.FromResult(intent.CurrentProjection!)));
        Task submitting = cut.Find("[data-testid='tenants-correction-confirm']")
            .ClickAsync(new Microsoft.AspNetCore.Components.Web.MouseEventArgs());
        cut.WaitForAssertion(() => commands.AddUserRequests.ShouldHaveSingleItem());
        string originalId = tracker.Find(intent.TenantScope)!.MessageId;
        TenantCorrectionStartIntent replacement = intent with {
            OriginalAuditReference = "replacement-reference", TenantScope = "tenant.beta", TargetUserId = "replacement-user",
            CurrentProjection = intent.CurrentProjection! with { TenantId = "tenant.beta", TargetUserId = "replacement-user" },
        };
        TenantCorrectionAttempt replacementAttempt = BeginAcceptedCorrection(tracker, gate, replacement);
        cut.Render(parameters => parameters.Add(p => p.Intent, replacement));
        cut.Find("[data-testid='tenants-correction-refresh']").HasAttribute("disabled").ShouldBeFalse();

        delivery.SetResult(TenantCommandSubmissionResult.Accepted(originalId, "old-delivery-correlation"));
        await statusStarted.Task.WaitAsync(TimeSpan.FromSeconds(5));
        cut.Find("[data-testid='tenants-correction-refresh']").HasAttribute("disabled").ShouldBeFalse();
        commands.StatusTask = successorStatus.Task;
        Task refreshing = cut.Find("[data-testid='tenants-correction-refresh']")
            .ClickAsync(new Microsoft.AspNetCore.Components.Web.MouseEventArgs());
        cut.WaitForAssertion(() => commands.StatusHandles.Count.ShouldBe(2));
        originalStatus.SetResult(TenantCommandStatusResult.Pending("original pending"));
        await submitting.WaitAsync(TimeSpan.FromSeconds(5));
        cut.Find("[data-testid='tenants-correction-refresh']").HasAttribute("disabled").ShouldBeTrue();
        successorStatus.SetResult(TenantCommandStatusResult.Pending("successor pending"));
        await refreshing.WaitAsync(TimeSpan.FromSeconds(5));

        cut.Instance.Snapshot!.MessageId.ShouldBe(replacementAttempt.MessageId);
        commands.StatusHandles[0].MessageId.ShouldBe(originalId);
        commands.StatusHandles[1].MessageId.ShouldBe(replacementAttempt.MessageId);
        commands.AddUserRequests.ShouldHaveSingleItem();
        gate.IsLocked(TenantCommandAggregateLock.ForTenant(intent.TenantScope)).ShouldBeTrue();
        gate.IsLocked(TenantCommandAggregateLock.ForTenant(replacement.TenantScope)).ShouldBeTrue();
    }

'''
assert marker in s;s=s.replace(marker,new+marker,1)
p.write_bytes(s.replace('\n','\r\n').encode())
