from pathlib import Path
p=Path('src/Hexalith.Tenants.UI/Components/Tenants/Audit/CorrectionStartPanel.razor')
s=p.read_text()
s=s.replace('            RenderRetainedDeliveryOutcome(attempt, deliveryGeneration);','            await PublishRetainedSnapshotAsync(attempt, deliveryGeneration, focusTerminalState: true).ConfigureAwait(false);')
s=s.replace('        RenderRetainedDeliveryOutcome(attempt, deliveryGeneration);','        await PublishRetainedSnapshotAsync(attempt, deliveryGeneration, focusTerminalState: true).ConfigureAwait(false);')
s=s.replace('        PublishRetainedSnapshot(attempt, statusGeneration);','        await PublishRetainedSnapshotAsync(attempt, statusGeneration).ConfigureAwait(false);',1)
s=s.replace('SetRetainedSnapshot(attempt,','await SetRetainedSnapshotAsync(attempt,')
s=s.replace(')), statusGeneration);',')), statusGeneration).ConfigureAwait(false);')
s=s.replace('FocusTarget = TenantCommandFocusTarget.Refresh }, statusGeneration);','FocusTarget = TenantCommandFocusTarget.Refresh }, statusGeneration).ConfigureAwait(false);')
s=s.replace('}, statusGeneration, focusTerminalState: true);','}, statusGeneration, focusTerminalState: true).ConfigureAwait(false);')
s=s.replace('await SetRetainedSnapshotAsync(attempt, next, statusGeneration, focusTerminalState: true);','await SetRetainedSnapshotAsync(attempt, next, statusGeneration, focusTerminalState: true).ConfigureAwait(false);')
start=s.index('    private void RenderRetainedDeliveryOutcome(')
end=s.index('    private Task<TenantCorrectionProjection?> RefreshCaptureAsync()',start)
s=s[:start]+'''    private Task SetRetainedSnapshotAsync(TenantCorrectionAttempt attempt,
        TenantCorrectionPreviewSnapshot candidate, long statusGeneration, bool focusTerminalState = false)
    {
        _attemptTracker.TryUpdate(attempt.TenantId, attempt.MessageId, candidate);
        return PublishRetainedSnapshotAsync(attempt, statusGeneration, focusTerminalState);
    }

    private async Task PublishRetainedSnapshotAsync(TenantCorrectionAttempt attempt, long statusGeneration,
        bool focusTerminalState = false)
    {
        if (_disposed) return;
        try
        {
            await InvokeAsync(() =>
            {
                // Parameter replacement and visible publication share one renderer operation: a
                // continuation cannot pass its generation check and then overwrite a newer mount.
                if (_disposed || statusGeneration != Volatile.Read(ref _confirmGeneration)
                    || !string.Equals(_snapshot?.MessageId, attempt.MessageId, StringComparison.Ordinal)
                    || !string.Equals(_snapshot?.OriginalAuditReference, attempt.Snapshot.OriginalAuditReference, StringComparison.Ordinal))
                {
                    return;
                }

                TenantCorrectionAttempt? retained = _attemptTracker.Find(attempt.TenantId);
                if (string.Equals(retained?.MessageId, attempt.MessageId, StringComparison.Ordinal))
                {
                    // EndDelivery already publishes atomically. Rejected writes expose only retained truth.
                    SetSnapshot(retained!.Snapshot, focusTerminalState);
                    StateHasChanged();
                }
            }).ConfigureAwait(false);
        }
        catch (ObjectDisposedException) when (_disposed) { }
        catch (InvalidOperationException) when (_disposed) { }
    }

'''+s[end:]
p.write_bytes(s.replace('\n','\r\n').encode())
p=Path('tests/Hexalith.Tenants.UI.Tests/Components/CorrectionStartPanelTests.cs')
s=p.read_text().replace('        first.Dispose();\n        IRenderedComponent<CorrectionStartPanel> resumed', '        await first.InvokeAsync(originalPanel.Dispose);\n        first.Dispose();\n        IRenderedComponent<CorrectionStartPanel> resumed')
p.write_bytes(s.replace('\n','\r\n').encode())
