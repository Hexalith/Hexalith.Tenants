from pathlib import Path
import re
selected = {180,266,473,503,574}
evidence = '_bmad-output/implementation-artifacts/dw-180-266-473-503-574-validation-evidence.md'
assert Path(evidence).is_file()
shared = 'Independent review/recheck and the final Debug source build, focused cases and complete UI suite pass; exact commands, initial failures and limits are preserved in dw-180-266-473-503-574-validation-evidence.md.'
proofs = {
180: ('Replacement load generation retires before synchronous cancellation callbacks; the controlled old-load completion cannot replace confirmed evidence. '+shared, 'src/Hexalith.Tenants.UI/Components/Pages/TenantsWorkspace.razor; tests/Hexalith.Tenants.UI.Tests/TenantsWorkspaceTests.AsyncOwnership.cs'),
266: ('Causal parent callback reentry is suppressed while independent overlapping nudges retain catch-up work. AsyncLocal is the verified intentional policy; component-wide boolean negative controls fail for both flows. '+shared, 'src/Hexalith.Tenants.UI/Components/Tenants/Members/AddTenantMemberFlow.razor; src/Hexalith.Tenants.UI/Components/Tenants/Members/ChangeTenantMemberRoleFlow.razor; tests/Hexalith.Tenants.UI.Tests/Components/AddTenantMemberFlowTests.cs; tests/Hexalith.Tenants.UI.Tests/Components/ChangeTenantMemberRoleFlowTests.cs'),
473: ('Existing captured intent/generation checks drop late list/detail success and failure after callback-free dismissal. The real workspace host withholds dismissal throughout held proof and retains exact unresolved ownership. '+shared, 'src/Hexalith.Tenants.UI/Components/Tenants/CreateTenantFlow.razor; tests/Hexalith.Tenants.UI.Tests/Components/CreateTenantFlowTests.cs; tests/Hexalith.Tenants.UI.Tests/TenantsWorkspaceTests.AsyncOwnership.cs'),
503: ('Exact status/delivery snapshots and projection targets remain captured across replacement, expiry and remount. Renderer publication consumes retained truth, remounts receive notifications and obsolete operations cannot acquire or clear successor busy guards. '+shared, 'src/Hexalith.Tenants.UI/Components/Tenants/Audit/CorrectionStartPanel.razor; src/Hexalith.Tenants.UI/State/TenantCommands/TenantCorrectionAttemptTracker.cs; tests/Hexalith.Tenants.UI.Tests/Components/CorrectionStartPanelTests.cs'),
574: ('Production DI binds retained intent visibility to literal authenticated subjects; pending/faulted identity and replacement/sign-out hide prior facts. Controlled held delivery/status and authorized remounts retain exact unresolved leases and permit original-owner terminal recovery. '+shared, 'src/Hexalith.Tenants.UI/State/TenantCommands/TenantCorrectionAttemptTracker.cs; src/Hexalith.Tenants.UI/Extensions/TenantsUiServiceCollectionExtensions.cs; src/Hexalith.Tenants.UI/Components/Pages/TenantAuditPage.razor; tests/Hexalith.Tenants.UI.Tests/State/TenantCorrectionAttemptCallerTests.cs; tests/Hexalith.Tenants.UI.Tests/Components/TenantAuditPageTests.cs'),
}
summary = '**DW-180/DW-266/DW-473/DW-503/DW-574 closure (2026-10-23):** Generation retirement, causal callback isolation and captured correction ownership protect current state across cancellation, dismissal, remount and caller changes. Retention notifications and renderer-atomic guards preserve recovery without exposing another caller\'s intent or releasing unresolved admission. Exactly five records close: all 657 IDs remain, 535 done/122 open across 112 maintenance rows. Original findings, unrelated records, dependencies and release holds remain preserved.'
p=Path('_bmad-output/implementation-artifacts/deferred-work.md');s=p.read_text();blocks=re.split(r'(?=^### DW-)',s,flags=re.M)
for i,b in enumerate(blocks[1:],1):
 n=int(re.match(r'### DW-(\d+)',b)[1])
 if n not in selected: continue
 fields={'status':'done 2026-10-23','disposition':'done','verification-date':'2026-10-23','verification':proofs[n][0],'verification-files':proofs[n][1]+'; '+evidence,'evidence-kind':'verified-closure','dependencies':'none for this selected closure; independent release and authority holds remain tracked separately','next-action':'none; selected record closed with maintained behavioral evidence'}
 for key,value in fields.items():
  pattern=r'^'+re.escape(key)+r': (.*)$'
  if re.search(pattern,b,re.M):
   b=re.sub(pattern,lambda m:'pre-async-ownership-'+m.group(0)+'\n'+key+': '+value,b,count=1,flags=re.M)
  else:
   pos=b.find('\n\n## ')
   if pos<0: pos=len(b.rstrip())
   b=b[:pos]+'\n'+key+': '+value+b[pos:]
 blocks[i]=b
s=''.join(blocks).replace('# Deferred Work\n\n','# Deferred Work\n\n'+summary+' See [validation evidence](dw-180-266-473-503-574-validation-evidence.md).\n\n',1)
p.write_text(s)
p=Path('docs/maintenance-backlog.md');s=p.read_text();lines=s.splitlines(keepends=True)
s=''.join(line for line in lines if not(line.startswith('| DW-') and set(map(int,re.findall(r'DW-(\d+)',line.split('|')[1])))&selected))
for old,new in [('| done | 530 |','| done | 535 |'),('| actionable | 61 |','| actionable | 60 |'),('| uncertain | 22 |','| uncertain | 18 |'),('**Remaining: 127 open records across 117 index rows.**','**Remaining: 122 open records across 112 index rows.**')]:
 assert old in s; s=s.replace(old,new,1)
s=s.replace('\n\n','\n\n'+summary+' See [validation evidence](../_bmad-output/implementation-artifacts/dw-180-266-473-503-574-validation-evidence.md).\n\n',1)
p.write_text(s)
