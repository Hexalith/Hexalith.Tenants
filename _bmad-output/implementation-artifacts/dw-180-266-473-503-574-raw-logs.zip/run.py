import json, subprocess, sys
from pathlib import Path
name, *command = sys.argv[1:]
root = Path(__file__).parent
(root / (name + '.command.json')).write_text(json.dumps(command, indent=2) + '\n')
with (root / (name + '.log')).open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
(root / (name + '.exit')).write_text(str(result.returncode) + '\n')
print((root / (name + '.log')).read_text()[-4500:])
print('Exit:', result.returncode)
sys.exit(result.returncode)
