from pathlib import Path
import subprocess,json,hashlib,shlex,time
from snapshot import ROOT
TASK=Path(__file__).parent
records=[]
for project,name in [('tests/Hexalith.Tenants.UI.Tests/Hexalith.Tenants.UI.Tests.csproj','ui-dependency-properties'),('','sdk-version'),('tests/Hexalith.EventStore.Server.Tests/Hexalith.EventStore.Server.Tests.csproj','es-dependency-properties')]:
 cwd=ROOT/'references/Hexalith.EventStore' if name.startswith('es-') else ROOT
 command=['dotnet','--version'] if name=='sdk-version' else ['dotnet','msbuild',project,'-p:Configuration=Debug','-p:UseNuGetDeps=false','-getProperty:NETCoreSdkVersion,HexalithEventStoreRoot,HexalithCommonsRoot,HexalithFrontComposerRoot,HexalithMemoriesRoot,HexalithTenantsBasePath,UseHexalithProjectReferences,UseNuGetDeps','-getItem:ProjectReference']
 start=time.monotonic(); result=subprocess.run(command,cwd=cwd,capture_output=True,text=True)
 (TASK/(name+'.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0,(name,result.stdout,result.stderr)
 records.append({'cwd':str(cwd.relative_to(ROOT)),'command':shlex.join(command),'exit_code':result.returncode,'duration_seconds':round(time.monotonic()-start,3),'log':name+'.log'})
paths=['tests/Hexalith.Tenants.UI.Tests/obj/project.assets.json','src/Hexalith.Tenants.UI/obj/project.assets.json','references/Hexalith.EventStore/tests/Hexalith.EventStore.Server.Tests/obj/project.assets.json','references/Hexalith.EventStore/src/Hexalith.EventStore.Server/obj/project.assets.json']
resolution={}
for name in paths:
 path=ROOT/name; raw=path.read_bytes(); a=json.loads(raw); owner=Path(a['project']['restore']['projectPath']).parent
 resolution[name]={'sha256':hashlib.sha256(raw).hexdigest(),'restored_project_path':str(owner),'package_folders':list(a['packageFolders']),'project_references':{lib:str((owner/info['msbuildProject']).resolve()) for lib,info in a['libraries'].items() if info['type']=='project'},'restored_packages':sorted(lib for lib,info in a['libraries'].items() if info['type']=='package')}
(TASK/'dependency-resolution.json').write_text(json.dumps(resolution,indent=2)+'\n')
tracked=[]
for line in subprocess.check_output(['git','ls-tree','-r','HEAD','--','src','tests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=ROOT,text=True).splitlines():
 metadata,path=line.split('\t',1); mode,kind,sha=metadata.split()
 if kind=='blob':tracked.append((path,sha))
normalized=subprocess.check_output(['git','hash-object','--stdin-paths'],cwd=ROOT,input=''.join(path+'\n' for path,sha in tracked),text=True).splitlines()
protected=[{'path':path,'head_git_blob':sha,'current_filtered_git_blob':actual,'current_raw_sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()} for (path,sha),actual in zip(tracked,normalized,strict=True)]
assert all(p['head_git_blob']==p['current_filtered_git_blob'] for p in protected)
content={'before_after_fingerprints':'before.json and after.json record the raw-content fingerprint for all 613 protected tracked root files; this file provides final per-file raw SHA-256 and normalized HEAD comparisons.','method':'For every tracked blob under src/ and tests/, plus root Directory.Build.props/targets, Directory.Packages.props and global.json: compare HEAD Git blob identity to git hash-object --stdin-paths (respecting Git content/line-ending filters); also record current raw file SHA-256. Git text normalization means HEAD bytes need not equal working file line endings.','all_protected_files_match_head':True,'files':protected}
(TASK/'protected-root-content.json').write_text(json.dumps(content,indent=2)+'\n')
results=json.loads((TASK/'results.json').read_text());results=[r for r in results if r['log'] not in [x['log'] for x in records]]+records
(TASK/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(TASK/'README.txt').write_text('''This archive records one verification at root 57ee33ef2511eebdf15a401dc19787423696039e.
Logs are complete combined stdout/stderr. results.json records their commands and working directories; before.json and after.json record measured preservation invariants. dependency-resolution.json records resolved references and package lists after the lanes; protected-root-content.json compares final protected content to HEAD through Git content filters, with measured before/after raw-content fingerprints in the snapshots.
Python files are the historical capture code used in this workspace, with its original absolute path, not a maintained portable validation tool. Behavioral lanes were run serially: UI restore/build/tests/browser, then EventStore restore/build/tests, then documentation guards. Each behavioral lane ran once. To repeat verification elsewhere, use the exact recorded commands from your corresponding owning repository and save results in a fresh capture directory; do not treat these archived capture scripts as a rerunnable validation product.
''')
print('Captured SDK '+(TASK/'sdk-version.log').read_text().strip()+', evaluated source references, four restored graphs, and '+str(len(protected))+' protected files matching HEAD after Git filters.')
