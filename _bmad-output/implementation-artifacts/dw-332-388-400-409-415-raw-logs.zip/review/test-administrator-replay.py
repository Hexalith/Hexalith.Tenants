from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from contextlib import redirect_stdout
import builtins,io,os,subprocess
source=Path('/tmp/replay-administrator-baseline-reviewed.py').read_text()
for primary,restored,expected in [(0,0,0),(9,0,9),(0,7,7)]:
 with TemporaryDirectory(prefix='administrator-replay-control-') as folder:
  root=Path(folder);page=root/'src/Hexalith.Tenants.UI/Components/Pages/GlobalAdministratorsPage.razor'
  page.parent.mkdir(parents=True);page.write_bytes(b'repaired source')
  calls=[]
  def run(command,**kwargs):
   calls.append(command)
   builds=sum(c[1]=='build' for c in calls)
   return subprocess.CompletedProcess(command, (primary if builds==1 else restored) if command[1]=='build' else 2)
  real_open=builtins.open
  def redirected_open(file,*args,**kwargs):
   if isinstance(file,str) and file.startswith('/tmp/dw-administrator-'):
    file=root/Path(file).name
   return real_open(file,*args,**kwargs)
  cwd=os.getcwd();code=0
  try:
   os.chdir(root)
   with patch('subprocess.check_output',return_value=b'original baseline'),patch('subprocess.run',side_effect=run),patch('builtins.open',side_effect=redirected_open),redirect_stdout(io.StringIO()):
    try:exec(compile(source,'replay-administrator-baseline.py','exec'),{})
    except SystemExit as error:code=error.code
  finally:os.chdir(cwd)
  assert page.read_bytes()==b'repaired source'
  assert sum(c[1]=='build' for c in calls)==2
  assert calls[-1][1]=='build' and code==expected,(calls,code,expected)
  print(f'primary build {primary}, restored build {restored}: source restored, final rebuild observed, exit {code}')
