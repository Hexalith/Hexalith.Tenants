from pathlib import Path
import subprocess
page=Path('src/Hexalith.Tenants.UI/Components/Pages/GlobalAdministratorsPage.razor')
fixed=page.read_bytes()
try:
 page.write_bytes(subprocess.check_output(['git','show','d287099eaba0018e59d2f4474aa36fb9b1a037b5:'+str(page)]))
 with open('/tmp/dw-administrator-build-baseline-replay.log','w') as log:
  build=subprocess.run(['dotnet','build','tests/Hexalith.Tenants.UI.Tests/Hexalith.Tenants.UI.Tests.csproj','--configuration','Debug','-p:UseHexalithProjectReferences=true','-m:1','-nr:false'],stdout=log,stderr=subprocess.STDOUT)
 if build.returncode: raise SystemExit(build.returncode)
 for label,pattern,minimum in [('baseline-replay','*AsyncConsistency*','19'),('baseline-browser','*RealChromiumFocusValidatorStops*','2')]:
  with open('/tmp/dw-administrator-'+label+'.log','w') as log:
   result=subprocess.run(['dotnet','test','--project','tests/Hexalith.Tenants.UI.Tests/Hexalith.Tenants.UI.Tests.csproj','--configuration','Debug','--no-build','--no-restore','--filter-method',pattern,'--minimum-expected-tests',minimum],stdout=log,stderr=subprocess.STDOUT)
  print(label, 'exit',result.returncode,flush=True)
finally:
 page.write_bytes(fixed)
 with open('/tmp/dw-administrator-build-restored-source.log','w') as log:
  restored_build=subprocess.run(['dotnet','build','tests/Hexalith.Tenants.UI.Tests/Hexalith.Tenants.UI.Tests.csproj','--configuration','Debug','-p:UseHexalithProjectReferences=true','-m:1','-nr:false'],stdout=log,stderr=subprocess.STDOUT)
 if restored_build.returncode:
  raise SystemExit(restored_build.returncode)
 print('Restored repaired page bytes and rebuilt repaired binaries.',flush=True)
