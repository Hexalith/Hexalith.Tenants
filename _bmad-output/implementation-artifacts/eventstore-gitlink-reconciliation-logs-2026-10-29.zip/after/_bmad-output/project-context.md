---
project_name: 'Hexalith.Tenants'
user_name: 'Administrator'
date: '2026-10-08'
sections_completed:
  [
    'technology_stack',
    'language_rules',
    'domain_rules',
    'eventing_rules',
    'framework_rules',
    'identity_rules',
    'ui_rules',
    'testing_rules',
    'code_quality',
    'workflow_rules',
    'critical_rules',
  ]
status: 'complete'
rule_count: 119
optimized_for_llm: true
---

# Project Context for AI Agents

_This file contains critical rules and patterns that AI agents must follow when implementing code in this project. Focus on unobvious details that agents might otherwise miss._

---

## Technology Stack & Versions

- **.NET 10 / C#** — SDK pinned to `10.0.401` with `rollForward: latestPatch`; all owned projects target `net10.0`; `Nullable`, `ImplicitUsings`, `LangVersion=latest`, and `TreatWarningsAsErrors=true` are root defaults.
- **Solution/build** — `Hexalith.Tenants.slnx` only; `MSBuild.rsp` and `Directory.Solution.*` force single-node serialized builds (`-m:1`, `BuildInParallel=false`, `RestoreBuildInParallel=false`).
- **Hexalith platform dependencies (reconciled 2026-10-29)** — The root-pinned Builds catalog at `4775fb72e3ca3c05059830733e31a98995818cb6` selects EventStore `3.128.4` for all 13 family packages. Supported live incremental discovery on 2026-10-29 confirms all 13 are listed at their latest stable version, so no version change is needed. Both the existing committed audit and temporary live audit pass deterministic validation (307 packages, 151 families, one source). Default and standalone package-mode Release restore/builds pass with zero warnings/errors; 10,887 tests pass with zero failures/skips in the default package-reference lane, including the documented UI source exception. All 10 owned production asset files in each build capture resolve only EventStore `3.128.4` packages. See the [latest-package evidence](implementation-artifacts/dependency-refresh-eventstore-3.128.4-evidence-2026-10-29.json) for exact commands and scope; no full Aspire/browser qualification or isolated packaged Tenants consumer probe is claimed. The earlier `3.120.0` preparation and audit blockers are historical, and their evidence remains unchanged. This verification does not close other deferred governance items. The historical spec gitlink audit is reconciled from its restored original October 8 baseline, with all nine current range pointers explicitly inventoried and independent changes unclaimed; the default guard passes. See [reconciliation evidence](implementation-artifacts/eventstore-gitlink-reconciliation-2026-10-29.md); no dependency or gitlink movement is performed. Package-capable libraries default to NuGet references; intentional development source sessions set `UseHexalithProjectReferences=true` or `UseNuGetDeps=false`. The UI and UI tests retain their available-FrontComposer-source exception.
- **DAPR** — DAPR SDK packages `1.18.10`; shared `domain-ci` defaults install CLI `1.18.0` and runtime `1.18.2`. The `1.19.0-rc.2` SDK candidate is held because stable pins do not move to prerelease channels in a dependency refresh.
- **Aspire** — Aspire packages and AppHost SDK `13.6.1`; Keycloak/Kubernetes packages `13.6.1-preview.1.26506.6`; DAPR hosting `CommunityToolkit.Aspire.Hosting.Dapr` `13.6.0-preview.1.261001-0243`. The aligned family and SDK exceptions come from published Builds commit `520abb5898ad44b30c0744e707b53cd94741e6b1`. The historical 2026-10-10 pre-edit full package audit bound Builds `2cf00028bbe563d80d4d12b5fb2054914f14fcb6`, with post-edit acceptance pending at that time. Current audit validation is recorded in the EventStore paragraph above; these older Aspire version observations have not been refreshed here.
- **Backend stack** — MediatR `14.2.0`, FluentValidation `12.1.1`, JWT/OpenID Connect IdentityModel `8.23.0`, ASP.NET Core OpenAPI `10.0.12`, Swagger UI `10.3.0`, and OpenTelemetry `1.19.1` with ASP.NET/HTTP/Runtime instrumentation `1.19.0`. Microsoft.OpenApi stays on its compatible `2.12.2` catalog pin.
- **UI stack** — Blazor InteractiveServer, FrontComposer Shell/Contracts source references, Fluent UI Blazor V5 `5.0.0`, bUnit `2.11.3`.
- **Memories search** — Tenants UI uses `MemoriesClient.SearchAsync` as an index lookup only; rows are hydrated from Tenants REST query endpoints.
- **Testing** — xUnit v3 `4.0.1` / Visual Studio runner `4.0.0` on Microsoft.Testing.Platform, Shouldly `4.3.0`, NSubstitute `6.2.0`, Testcontainers `4.15.0`, Microsoft.Testing.Extensions.CodeCoverage `18.12.0`, Microsoft.NET.Test.Sdk `18.10.1`, and YamlDotNet `18.1.0`. Shouldly `5.0.0-preview.2` is held because stable pins do not move to prerelease channels in a dependency refresh.
- **Release tooling** — semantic-release `25.0.9`, commitlint `21.2.3`, `@semantic-release/changelog` `7.0.0`, `@semantic-release/git` `11.0.1`, and `@semantic-release/github` `12.0.10`; five NuGet packages are released: `Hexalith.Tenants.Contracts`, `.Client`, `.Server`, `.Testing`, `.Aspire`.
- **Framework family held at .NET 10.** `Microsoft.AspNetCore.*`, `Microsoft.Extensions.*`, `System.Text.Json`, and `System.Collections.Immutable` stay on .NET 10-compatible stable versions (`10.0.x` servicing; resilience/service-discovery extensions `10.10.0`). Their higher versions are .NET 11 prereleases, and several publish only `net11.0` assets that cannot restore against `net10.0` / SDK `10.0.401`. Do not update this family without an approved platform migration.

## Critical Implementation Rules

### C# Language & Contract Rules

- Commands, success events, and rejection events are plain `public record` primary-constructor types. Do not add `sealed` or XML parameter docs to these contract records.
- Query contracts are `sealed class : IQueryContract` with static `QueryType`, `Domain`, and `ProjectionType`; `QueryType`/`Domain` are kebab-case and unique. There are currently 6 query contracts.
- Query response DTOs are `sealed record` types with XML `<summary>` docs; keep response DTOs separate from query contract marker classes.
- Events implement `IEventPayload`; rejection events implement `IRejectionEvent`; commands have no marker interface.
- Rejection records must stay structured and support-safe: no prose `Message`/`Reason`/`Detail`, no stack trace, no raw payload, no token fields.
- Every event type has a string `TenantId`; tenant/global administrator domain identifiers are meaningful caller-supplied strings, not GUIDs or ULIDs.
- Enums use `Unknown = 0` plus JSON string serialization. `TenantStatus` uses the custom converter that maps unrecognized values to `Unknown`; `TenantRole.Unknown` is non-privileged and rejected by domain logic.
- Use file-scoped namespaces, namespace = folder path, `using` outside namespace, System directives first, Allman braces, `_camelCase` private fields, `I` interfaces, and `Async` suffix on async methods.
- Always use `ConfigureAwait(false)` on awaited calls in production code. `CA2007` is warning-level in `.editorconfig`, but warnings are build failures.
- Keep each `.cs` file focused on one C# type/object. Move extra records/classes/enums/interfaces/delegates to their own files named for the type.
- Validate public boundaries with `ArgumentNullException.ThrowIfNull` / `ArgumentException.ThrowIfNullOrWhiteSpace`; avoid nullable suppression as a substitute for validation.
- Do not add copyright/license headers to new files in this repo.

### Domain, Eventing & Framework Rules

- Aggregates are pure domain functions: static `Handle(command, state?, envelope) -> DomainResult` and state `Apply(event)`. No I/O, no async, no mutation inside `Handle`; state changes only through `Apply`.
- Business failures are rejection events, not exceptions. Same-state domain requests return `DomainResult.NoOp()` only where explicitly modeled, such as same-role change or identical configuration set.
- The two aggregate domains are `tenants` and `global-administrators`. `TenantAggregate` uses `[EventStoreDomain("tenants")]`; global administrator events publish on the shared `tenants.events` topic via AppHost gateway topic override.
- Never edit/delete/rewrite events, projections, or state-store data to fix business state. Use compensating commands through `POST /api/v1/commands`, then verify command status and projection evidence.
- The Tenants host is an EventStore domain service, not an EventStore server. Do not call `AddEventStoreServer`, host `AggregateActor`, or reintroduce `TenantsProjectionActor`.
- Host composition consumes shared platform services: `AddServiceDefaults`, `AddEventStoreDomainTelemetry("tenants")`, `AddEventStoreDataProtection`, `AddEventStoreReadModelStore`, `AddEventStoreQueryCursorCodec`, and `MapEventStoreDomainService`.
- Tenant reads are served by in-process `IDomainQueryHandler`s and the REST query controller (`GET /api/tenants*`, `GET /api/users/{id}/tenants`, `GET /api/global-administrators`). Do not route tenant reads through projection actors or the generic EventStore query gateway.
- Query cursors are opaque and DataProtection-backed; cursor scopes include authenticated user and query context. Do not parse, expose, or log cursor contents.
- Read-model freshness uses EventStore `IReadModelFreshness` and `ReadModelFreshnessState`. Server read models persist `ProjectedAt`; `ToQueryResponseMetadata` emits `current/stale/unknown` via `X-Hexalith-Is-Stale`. `Aging` is dormant on the wire; `Refreshing` is UI-only.
- `ProjectedAt` measures last projection write, not global lag. Defaults are intentionally conservative; `ServedAt` must not be used as projection age.
- DAPR pub/sub is at-least-once and unordered. Consumers and projection handlers must be idempotent; use EventStore `MessageId` for duplicate detection and never treat `SequenceNumber` as global ordering.
- The Client package owns domain-specific event handler registration and an in-memory projection default only. Consuming services supply durable projection storage and shared dedup when scaling beyond one instance.
- Tenant configuration keys are consumer-owned namespaced strings, usually dot-prefixed (`billing.*`, `sample.*`). Consumers filter by their namespace and ignore others.
- MediatR pipeline order in Tenants is `ValidationBehavior` then `AuthorizationBehavior`; do not reorder or add generic behaviors casually.
- Domain exceptions map to RFC 7807 through registered exception handlers, specific handlers before generic.
- AppHost is the allowed repository-specific technical component. It wires EventStore, Tenants, Tenants UI, Sample, Memories, DAPR components, Keycloak, topic overrides, and Debug child build edges.
- AppHost changes require restarting `aspire run`; the Aspire app model is built at startup.
- DAPR access control is deny-by-default. Any sidecar/app-id/topic change must update DAPR access-control YAML and route tests.

### Identity Rules

- Identity = **`AggregateIdentity(TenantId, Domain, AggregateId)`** — build via the `TenantIdentity` factory: `ForTenant(id)`, `ForGlobalAdministrators()`. Constants: `DefaultTenantId = "system"`, `Domain = "tenants"`
- **Tenant ids and user ids are meaningful caller-supplied strings — NOT ULIDs.** (EventStore envelope ids like `MessageId` may be ULIDs; domain identifiers are not.) Do not `Guid.TryParse`/`Ulid.TryParse` a `TenantId`/`UserId`

### UI / UX Rules

- Tenants UI must use FrontComposer and Fluent UI Blazor V5 components. Do not introduce raw interactive HTML controls (`button`, `input`, `select`, `textarea`), raw forms, or raw table markup in `.razor` components.
- Route pages compose through FrontComposer page primitives (`FcPageHeader`, `FcPageLayout`, `FcAggregateListPage`, `FcAggregateDetailPage`). Do not add Tenants-owned page-root `<main>` wrappers, direct `PageTitle`, or raw route-level `<h1>`.
- Multi-region domain pages and panels group sibling titled content sections with `FluentAccordion`, `AccordionExpandMode.Multi`, and an initially expanded primary item. Do not hide the only primary content region behind an accordion.
- Use `FluentDataGrid` or FrontComposer grid primitives for data surfaces. Tenants-specific grids are allowed where FrontComposer does not provide cursor pagination, safety-column pinning, or required non-collapsing states.
- Express layout with Fluent/FrontComposer primitives such as `FluentStack`, `FluentGrid`, and FrontComposer layout modes. Inline layout styles are forbidden.
- Component CSS must not own theme primitives, semantic colors, broad layout/spacing/typography, or native control selectors. Any unavoidable layout/typography CSS requires an immediately preceding `/* fc-css-exception: ... */` marker with a real reason.
- Use Fluent V5 component parameters and Fluent 2 tokens only. Do not use legacy Fluent v4/FAST tokens such as `--type-ramp-*`, `--neutral-*`, `--accent-*`, or `--palette-*`.
- Keep raw semantic HTML only where Fluent has no equivalent (`section`, `header`, `nav`, `dl`, `ul`, `ol`, `li`, inline `a`). Structural raw `div`/`span` usage is budgeted by governance tests and should ratchet down.
- Every UI state must remain support-safe: never render bearer tokens, decoded JWT payloads, internal correlation IDs, stack traces, raw EventStore metadata, raw payloads, or cursor/ETag internals.
- Command UI must preserve the non-collapse truth-state model: accepted, projection-confirmed, and audit-available are distinct. SignalR is only a freshness nudge, never proof of success.
- Command flows must confirm from projection evidence before showing success. Terminal non-success states cannot become confirmed merely because unrelated projection data appears.
- `ReadModelFreshnessState.Unknown` and `Stale` generally fail closed for mutation actions; first-tenant create is a documented exception where unknown list freshness remains creatable.
- Memories search is an index match-set only. Search results must be hydrated through Tenants detail/list query paths before display; stale Memories data must not become row truth.
- Approved 2026-10-28 read-safety supersession (DW-117/118/127/599/618): authoritative search backfills authorized rows and proves authorized lookahead before enabling Next. Each load examines at most 1,000 raw positions including replay/lookahead; budget exhaustion or any operational hydration gap discards incomplete search and uses the labelled authorized-list fallback. Privacy covers rendered rows/pager, excluding timing, work, fallback-mode independence and beyond-budget completeness. Preserve per-page sort and offset-mutation limits; do not claim snapshot isolation.
- Search continuations are versioned numeric fixed-window start plus consumed returned-result count, protected and caller/query-bound. Replay fixed-size windows; never reinterpret returned ordinals as raw offsets. Invalid/old continuation recovers to page one with named recovery, and continuations stay server-held. This supersedes Story 1.9's historical no-backfill rule without editing frozen stories.
- Nonfatal provider/programming read faults belong at workspace Error/Retry with fixed safe diagnostics and cancellation/scope/disposal guards; fatal failures propagate. Gateway null-versus-empty classification remains deliberate and wrappers require nonblank inputs. DW-118 is a qualified contract decision, not a reachable null-input production fix.
- FR-6 is a server-side UI display policy, not an API disclosure restriction. Authorized API consumers retain full tenant configuration. UI composition requires valid policy for all principals, exact display-safe keys and ordinal prefix grants; administrators bypass prefixes only. Missing/malformed policy fails UI configuration closed and raw entries never enter rendered state.
- UI localization uses `TenantsResources.resx` and `.fr.resx`; keep EN/FR key parity and use whole strings with placeholders, not runtime sentence fragments.
- Stable `data-testid` selectors and accessible names are part of the contract. Tests must not depend on row text, color alone, or incidental Fluent-generated markup.

### Testing Rules

- Use xUnit v3 and Shouldly (`ShouldBe`, `ShouldThrow`, `Should.ThrowAsync`); do not use raw `Assert.*` in new tests. A few old scaffolding smoke tests still exist and should not be copied.
- Use NSubstitute for mocks and bUnit for Blazor/Fluent components. Fluent component tests should derive from the local Fluent bUnit setup and use loose JS interop when rendering Fluent UI.
- Test classes/files use plural `{Class}Tests.cs`; behavior names should stay descriptive and scenario-focused.
- Run tests per project, matching CI. Use `.slnx` for restore/build only; do not make solution-level `dotnet test` the default.
- CI Tier 1 blocking tests: `Contracts.Tests`, `Client.Tests`, `Testing.Tests`, `UI.Tests`, and `Sample.Tests`.
- CI Tier 2 blocking tests: `AppHost.Tests` and `Server.Tests`, as declared in `.github/workflows/ci.yml` under `integration-test-projects`. AppHost model checks belong in this blocking tier alongside the Server tests; initialize DAPR for the Server runtime prerequisites.
- CI Tier 3 Aspire tests: `IntegrationTests` with `Category!=Performance`, non-blocking `continue-on-error`; `Category=Performance` runs only on nightly schedule.
- Integration tests must assert persisted state-store/read-model end state, headers, projection metadata, or topology behavior. HTTP status alone is only a smoke signal.
- Coverage gate uses unioned Cobertura reports. Overall line coverage is `>80%` scoped to four package projects: `Contracts`, `Client`, `Server`, `Testing`. The published `.Aspire` helper is not in the current line-coverage scope.
- Branch coverage gate is `100%` for isolation/auth files: `TenantAggregate.cs`, `GlobalAdministratorsAggregate.cs`, and `ChangeUserRoleValidator.cs`. Add new isolation/auth logic to the gate.
- Domain logic tests should prefer `Hexalith.Tenants.Testing`: `InMemoryTenantService`, `TenantTestHelpers`, `TenantIsolationTestHelpers`, and `InMemoryTenantProjection`.
- UI command tests must cover validation before submit, fail-closed availability, projection-confirmed success, non-collapse lifecycle states, SignalR nudge-only behavior, support-safe copy, EN/FR resource parity, and focus/live-region behavior where relevant.
- Query/freshness tests must cover `X-Hexalith-Is-Stale`, `X-Hexalith-Served-At`, `X-Hexalith-Projection-Version`, `304` with freshness headers, unknown freshness, stale freshness, and conservative threshold behavior.
- Run each test project with the repository-selected Microsoft.Testing.Platform path; direct-assembly fallback is not acceptance evidence for a maintained `dotnet test` lane.
- All configured tests relevant to a story must pass before completion; document any blocked validation with the exact blocker.

### Code Quality & Style Rules

- Use `Hexalith.Tenants.slnx` only. Do not create `.sln` files, and do not run solution-level `dotnet test` as the default validation path.
- Keep package versions centralized in `Directory.Packages.props`; `.csproj` files should use `<PackageReference Include="..." />` without `Version`.
- Respect intentional serialized builds from `MSBuild.rsp` and `Directory.Solution.*` (`-m:1`, `BuildInParallel=false`, `RestoreBuildInParallel=false`). Do not "fix" this into parallel restore/build.
- Root defaults make warnings build-breaking: `TreatWarningsAsErrors=true`, CI `-warnaserror`, nullable enabled, implicit usings enabled, latest language version. Fix analyzer findings instead of suppressing them casually.
- Analyzer policy is intentionally lightweight. Do not add SonarAnalyzer, StyleCop, Roslynator, or formatting packages unless explicitly requested.
- Containers use .NET SDK container support, not Dockerfiles. Only `src/Hexalith.Tenants` is the container app (`EnableContainer=true`, `ContainerRepository=tenants`); libraries ship as NuGet packages.
- Published package surface is exactly five packages: `Contracts`, `Client`, `Server`, `Testing`, and `Aspire`. `Hexalith.Tenants` and `Hexalith.Tenants.UI` are container/application projects, not NuGet packages.
- Debug builds may use source `ProjectReference`s for available Hexalith libraries; Release builds should consume package-capable shared libraries through NuGet package references.
- Source-only shared references are intentional where packages are not yet available, such as EventStore web host and FrontComposer Contracts/Shell. Do not convert them blindly.
- The host's `ErrorOnDuplicatePublishOutputFiles=false` is intentional while it references the EventStore web host; Tenants appsettings should win.
- Keep Tenants domain-focused. Do not add reusable hosting, serialization, persistence, UI scaffolding, test harness, or cross-domain boilerplate here when it belongs in `Hexalith.EventStore`, `Hexalith.FrontComposer`, `Hexalith.Commons`, `Hexalith.Builds`, or another shared module.
- Submodules are root-declared under `references/` only. Never use recursive submodule init, and do not modify submodule files without explicit approval.
- Use MSBuild root properties such as `$(HexalithEventStoreRoot)`, `$(HexalithFrontComposerRoot)`, and `$(HexalithMemoriesRoot)`; do not hardcode local absolute paths.
- Only call non-experimental Memories APIs from Tenants. `SearchAsync` is safe; experimental ingestion/tenant creation APIs should not be used from this repo.
- Do not add copyright/license headers to new files.

### Development Workflow Rules

- Use Conventional Commits. `feat` triggers a minor release and `fix` triggers a patch release. A major release requires the space-spelled `BREAKING CHANGE:` footer, and nothing else works — measured against the pinned `conventional-changelog-angular` parser: `feat!:` and `fix!:` → no release at all (no `breakingHeaderPattern`, so the `!` header fails `headerPattern` and the commit is unclassified); `BREAKING-CHANGE:` → patch, not major (the preset overrides `noteKeywords` to the space-spelled form only). Do not use `feat` for refactors or test-only work.
- Semantic Release derives the next version from the highest release tag reachable from `main`, while nuget.org keeps every version ever published. Deleted release tags can leave lineage unproven and risk collisions; the `verify-source` job checks the reachable tag floor against the declared packages' published stable versions before the release job runs. That guard does not compute the proposed version. Local inspection on 2026-10-18 found reachable history through `v5.8.0` (`032573384d3df4bc7a5bc0e69945ecca4e00967f`, 2026-10-08); this is repository evidence, not proof of current registry contents or release readiness. The unchanged preflight `minimum_release_version=4.0.0` is a static safety minimum, not the current release line.
- Use branch names like `feat/...`, `fix/...`, or `docs/...`; do not commit directly to `main`.
- CI runs on push/PR to `main`: restore, Release build with warnings as errors, package metadata/consumer validation, Tier 1 tests, DAPR init, Tier 2 tests, and coverage gates.
- Release is an explicit operator action through `workflow_dispatch` in `.github/workflows/release.yml`; merging or pushing to `main` runs CI without automatic publication. Before entering the protected `production` environment, `verify-source` requires dispatch from the current `main` tip, a successful push-event CI run for that exact SHA, and the registry/tag-floor proof. The protected job rechecks the source before publication and does not rerun the test tiers. Semantic-release derives the version from commit history, packs exactly five NuGet packages, validates packages and package-only consumers, publishes to NuGet, publishes the tenants container, and creates the GitHub Release; the final verification job requires its release tag at the exact dispatched source. `.releaserc.json` has no changelog/git plugins, so it generates GitHub release notes without updating the repository's historical `CHANGELOG.md`.
- Run local tests by project in the same shape as CI. Use `.slnx` for restore/build, then targeted `dotnet test <test-project>`.
- Initialize only the required root-declared submodules under `references/`; never use recursive submodule initialization.
- A story commit must not move a `references/` gitlink silently. Before completing a story run `python3 scripts/validate-story-gitlinks.py <story-file>`; declare each moved pointer as a File List entry with a reason, or revert it and commit the bump separately as `build(deps)`. Never state that `references/` was untouched without that check passing.
- For local distributed runs, use Aspire AppHost. Restart `aspire run` after AppHost, DAPR component, topic, or sidecar changes because the app model is built at startup.
- In slim/VM local mode, start DAPR `placement` and `scheduler` before `aspire run`; actor-backed dependencies can fail without them.
- The default local Tenants service URL is `http://localhost:8080`; when Keycloak is disabled, local auth falls back to symmetric-key JWT.
- AppHost topology changes must update DAPR access-control YAML, route/topic wiring, and tests together.
- Do not edit EventStore, projection, or state-store data during debugging. Reproduce with commands, inspect persisted envelopes/read models, and fix state through compensating commands.
- Before implementing UI work, read the Hexalith UX instructions and verify FrontComposer/Fluent conformance tests still represent the intended governance.
- Before changing persistence, projection freshness, or query behavior, read the relevant EventStore state/freshness conventions and preserve cursor opacity.
- Package or source-reference changes must preserve Release package-only consumer validation; Debug convenience references cannot leak into Release package consumers.
- Document any validation that cannot be run with the exact command and blocker, not a generic "not tested" note.

### Critical Don't-Miss Rules

- Never add `sealed` or XML parameter docs to command, success-event, or rejection-event records. Query response DTOs are the exception: use `sealed record` with XML summaries.
- Never throw exceptions for business failures inside aggregates. Return structured rejection events, or `DomainResult.NoOp()` only for explicitly modeled same-state requests.
- Never add I/O, async calls, service dependencies, or mutation to aggregate `Handle` methods. State changes come only from events applied through `Apply`.
- Never register `AddEventStoreServer`, `AggregateActor`, or a tenant projection actor in the Tenants host. Tenants is a domain service with in-process query handlers and REST read endpoints.
- Never reorder the MediatR pipeline. Validation runs before authorization.
- Never treat `TenantId` or `UserId` as GUIDs/ULIDs, and never treat `SequenceNumber` as global ordering. Domain identifiers are caller-supplied strings; deduplicate on EventStore `MessageId`.
- Never parse, expose, or log query cursors, ETags, JWT payloads, bearer tokens, raw EventStore metadata, raw event payload dumps, stack traces, or internal correlation data.
- Never edit/delete/rewrite events, projections, or state-store data to fix business state. Use compensating commands and verify projection evidence.
- Never use raw interactive HTML controls, raw forms, raw tables, route-level `PageTitle`, or page-root `<main>` wrappers in Tenants UI. Use FrontComposer and Fluent UI Blazor V5.
- Never treat SignalR notifications, HTTP 202/201, or command acceptance as proof of user-visible success. UI success requires projection-confirmed evidence.
- Never let stale Memories search data become tenant row truth. Search returns match candidates; hydrate rows through Tenants query endpoints.
- Never use `.sln`, solution-level `dotnet test`, package versions in `.csproj`, Dockerfiles for the Tenants container, or recursive submodule initialization.
- Never add cross-domain technical plumbing to Tenants when it belongs in shared Hexalith modules.
- Always keep DAPR consumers idempotent and topology/access-control YAML aligned with AppHost sidecars, app IDs, and topics.
- Always preserve Release package-only consumer validation when changing references, packaging, or shared dependency flow.
- Always run or document the relevant per-project tests before completing implementation work.

---

## Usage Guidelines

**For AI Agents:**

- Read this file before implementing any code in `Hexalith.Tenants`
- Follow ALL rules exactly as documented
- When in doubt, prefer the more restrictive option
- This file complements (does not replace) `CLAUDE.md` at the repo root and the domain docs under `docs/` (see `event-contract-reference.md`, `idempotent-event-processing.md`, `compensating-commands.md`, `cross-aggregate-timing.md`, `production-auth-claim-contract.md`)

**For Humans:**

- Keep this file lean and focused on agent needs
- Update when the technology stack, analyzer policy, MediatR pipeline, test tiers, or coverage gates change
- Remove rules that become obvious over time

Last Updated: 2026-10-08
