import os,json,subprocess,sys
from pathlib import Path
s=json.loads(Path('/tmp/tenants-dw-current-resources.json').read_text())
c=json.loads(Path('/tmp/tenants-dw-browser-credentials.json').read_text())
u=next(r for r in s['resources'] if r['name'].startswith('tenants-ui-'))
url=next(v['url'] for v in u['urls'] if v['name']=='https')
e=os.environ.copy();e.update(TENANTS_BROWSER_BASE_URL=url,TENANTS_BROWSER_SOURCE_UI_PID=str(u['properties']['executable.pid']),TENANTS_BROWSER_USERNAME=c['username'],TENANTS_BROWSER_PASSWORD=c['password'],TENANTS_BROWSER_PLAYWRIGHT_MODULE='/home/administrator/.npm/_npx/9833c18b2d85bc59/node_modules/playwright',CHROMIUM_BIN='/usr/bin/google-chrome-stable')
raise SystemExit(subprocess.run(['node',sys.argv[1],sys.argv[2]],env=e).returncode)
