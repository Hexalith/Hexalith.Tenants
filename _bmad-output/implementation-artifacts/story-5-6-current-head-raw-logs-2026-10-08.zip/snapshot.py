from pathlib import Path
import subprocess, hashlib, json
ROOT = Path('/home/administrator/projects/hexalith/tenants')
def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=cwd, text=True).strip()
def snapshot():
    submodules = {}
    for row in git('ls-tree', 'HEAD', 'references/').splitlines():
        mode, kind, sha, path = row.split(maxsplit=3)
        if mode != '160000':
            continue
        repo = ROOT/path
        index = Path(git('rev-parse', '--git-path', 'index', cwd=repo))
        index = index if index.is_absolute() else repo/index
        submodules[path] = {'gitlink': sha, 'head': git('rev-parse', 'HEAD', cwd=repo), 'index_sha256': hashlib.sha256(index.read_bytes()).hexdigest(), 'status': git('status', '--porcelain', cwd=repo)}
    index = Path(git('rev-parse', '--git-path', 'index'))
    index = index if index.is_absolute() else ROOT/index
    spec = ROOT/'_bmad-output/implementation-artifacts/spec-5-6-preview-confirm-and-link-a-tenant-correction.md'
    frozen = spec.read_bytes().split(b'<frozen-after-approval', 1)[1].split(b'</frozen-after-approval>', 1)[0]
    return {'root_head': git('rev-parse', 'HEAD'), 'root_index_sha256': hashlib.sha256(index.read_bytes()).hexdigest(), 'original_frozen_sha256': hashlib.sha256(frozen).hexdigest(), 'original_baseline_commit': git('rev-parse', '11e65e37f0fbf6649642a512052eebd37d50166d'), 'eventstore_baseline_commit': git('rev-parse', 'b51978dd1d2a3721ad239db2623e1560377c7583', cwd=ROOT/'references/Hexalith.EventStore'), 'submodules': submodules, 'package_configuration_sha256': {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['Directory.Build.props', 'Directory.Packages.props', 'global.json', 'references/Hexalith.Builds/Props/Directory.Packages.props']}}
if __name__ == '__main__':
    print(json.dumps(snapshot(), indent=2))
