from pathlib import Path
import subprocess,json,time,shlex,hashlib,zipfile,re,datetime
from snapshot import ROOT,snapshot,git
TASK=Path(__file__).parent
OUT=ROOT/'_bmad-output/implementation-artifacts'
results=json.loads((TASK/'results.json').read_text())
results=[r for r in results if r['log'] not in ['gitlinks-current.log','gitlinks-new-spec.log','diff-check.log']]
checks=[(['python3','scripts/validate-story-gitlinks.py','_bmad-output/implementation-artifacts/spec-5-6-preview-confirm-and-link-a-tenant-correction.md'],'gitlinks-current.log'),(['python3','scripts/validate-story-gitlinks.py','_bmad-output/implementation-artifacts/spec-5-6-preview-confirm-and-link-a-tenant-correction-3.md'],'gitlinks-new-spec.log'),(['git','diff','--check'],'diff-check.log')]
for command,log in checks:
 start=time.monotonic(); run=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
 (TASK/log).write_text(run.stdout+run.stderr)
 results.append({'cwd':'.','command':shlex.join(command),'exit_code':run.returncode,'duration_seconds':round(time.monotonic()-start,3),'log':log})
 if run.returncode:
  raise SystemExit(run.stdout+run.stderr)
(TASK/'results.json').write_text(json.dumps(results,indent=2)+'\n')
before=json.loads((TASK/'before.json').read_text()); after=snapshot()
assert before==after,'Preservation invariant changed'
(TASK/'after.json').write_text(json.dumps(after,indent=2)+'\n')
archive=OUT/'story-5-6-current-head-raw-logs-2026-10-08.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in sorted(TASK.iterdir()):
  if f.is_file() and f.suffix in ['.log','.json','.py']:
   z.write(f,f.name)
for r in results:
 raw=(TASK/r['log']).read_bytes(); r['log_sha256']=hashlib.sha256(raw).hexdigest()
 if r['log'] in ['ui-tests.log','es-tests.log']:
  log=raw.decode(); r['passed']=int(re.search(r'succeeded: (\d+)',log).group(1));r['failed']=int(re.search(r'failed: (\d+)',log).group(1));r['skipped']=int(re.search(r'skipped: (\d+)',log).group(1))
 if r['log'] in ['ui-build.log','es-build.log']:
  r['warnings']=int(re.search(r'(\d+) Warning',raw.decode()).group(1));r['errors']=int(re.search(r'(\d+) Error',raw.decode()).group(1))
 r['scope']={'ui-tests.log':'Complete Tenants UI project; Debug/source references','es-tests.log':'Five maintained EventStore command-proof classes only; Debug/source references','browser.log':'Rendered EN/FR component fixtures and static focus helpers: desktop, narrow viewport, forced colors and negative controls; no authenticated live-command egress assertion'}.get(r['log'],'Validation prerequisite or documentation guard')
initial=json.loads((TASK/'initial-guard.json').read_text())
initial['log_sha256']=hashlib.sha256((TASK/initial['log']).read_bytes()).hexdigest()
initial['scope']='Before documentation refresh: five stale targets; resolved by gitlinks-current.log'
report={'date':'2026-10-08','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'story_key':'5-6-preview-confirm-and-link-a-tenant-correction','verification_spec':'spec-5-6-preview-confirm-and-link-a-tenant-correction-3.md','source':'Fresh command results; complete stdout/stderr logs retained in the named archive. No new behavioral implementation.','hash_method':{'index':'SHA-256 of bytes at git rev-parse --git-path index for each owning repository; git --no-optional-locks prevents status index refresh','frozen_block':'SHA-256 of original_spec.read_bytes().split(b"<frozen-after-approval",1)[1].split(b"</frozen-after-approval>",1)[0]','log':'SHA-256 of complete combined stdout/stderr log bytes'},'invariants_before':before,'invariants_after':after,'all_invariants_equal':before==after,'tracked_changed_paths':git('diff','--name-only').splitlines(),'archive':{'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'contents':zipfile.ZipFile(archive).namelist()},'initial_guard':initial,'results':results,'limitations':['EventStore validation covers the five command-proof classes, not the entire Server project.','Browser validation covers rendered fixtures and shipped static helpers, not an authenticated live Aspire application or live command delivery.','Deterministic corrective audit association is absent from the existing audit DTO; the approved MissingSupport refusal remains covered.','Historical reverification spec -2 and its report remain records of earlier revisions; current guards were run on the original story and spec -3.']}
(OUT/'story-5-6-current-head-2026-10-08.json').write_text(json.dumps(report,indent=2)+'\n')
print('Recorded '+str(len(results))+' successful commands; archive SHA-256 '+report['archive']['sha256'])
print('All preservation invariants equal:',report['all_invariants_equal'])
