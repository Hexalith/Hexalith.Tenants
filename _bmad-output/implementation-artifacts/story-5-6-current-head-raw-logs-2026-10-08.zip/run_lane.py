import subprocess, pathlib, json, time, shlex, sys
root=pathlib.Path('/home/administrator/projects/hexalith/tenants')
task=pathlib.Path(__file__).parent
ui='tests/Hexalith.Tenants.UI.Tests/Hexalith.Tenants.UI.Tests.csproj'
es='tests/Hexalith.EventStore.Server.Tests/Hexalith.EventStore.Server.Tests.csproj'
lanes={
 'ui':[(root,['dotnet','restore',ui,'-p:UseNuGetDeps=false','-m:1','-v:q'],'ui-restore'),(root,['dotnet','build',ui,'-c','Debug','-p:UseNuGetDeps=false','-m:1','--no-restore','-v:q'],'ui-build'),(root,['dotnet','test','--project',ui,'-c','Debug','-p:UseNuGetDeps=false','--no-build','--no-restore'],'ui-tests'),(root,['env','TENANTS_BROWSER_BUILD_CONFIGURATION=Debug','bash','tests/Hexalith.Tenants.UI.Tests/Browser/validate-tenants-focus-browser.sh'],'browser')],
 'eventstore':[(root/'references/Hexalith.EventStore',['dotnet','restore',es,'-p:UseNuGetDeps=false','-m:1','-v:q'],'es-restore'),(root/'references/Hexalith.EventStore',['dotnet','build',es,'-c','Debug','-p:UseNuGetDeps=false','-m:1','--no-restore','-v:q'],'es-build'),(root/'references/Hexalith.EventStore',['dotnet','test','--project',es,'-c','Debug','-p:UseNuGetDeps=false','--no-build','--no-restore','--filter-class','*StateMachineIntegrationTests','--filter-class','*EventDrainRecoveryTests','--filter-class','*AggregateActorIdempotencyTests','--filter-class','*EventPublicationIntegrationTests','--filter-class','*CommandStatusControllerTests'],'es-tests')]
}
for cwd,command,name in lanes[sys.argv[1]]:
 print('Running '+name+': '+shlex.join(command),flush=True)
 start=time.monotonic()
 log=task/(name+'.log')
 with log.open('w') as stream:
  result=subprocess.run(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
 path=task/'results.json'
 records=json.loads(path.read_text()) if path.exists() else []
 records.append({'cwd':str(cwd.relative_to(root)),'command':shlex.join(command),'exit_code':result.returncode,'duration_seconds':round(time.monotonic()-start,3),'log':log.name})
 path.write_text(json.dumps(records,indent=2)+'\n')
 print(name+' exit '+str(result.returncode)+'\n'+log.read_text()[-5000:],flush=True)
 if result.returncode:
  sys.exit(result.returncode)
